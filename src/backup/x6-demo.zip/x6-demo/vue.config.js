/*
 * @Author: your name
 * @Date: 2021-07-22 09:58:47
 * @LastEditTime: 2021-07-22 09:59:25
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /x6-demo/vue.config.js
 */

module.exports = {
    runtimeCompiler: true
}