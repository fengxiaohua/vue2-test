/*
 * @Author: your name
 * @Date: 2021-07-20 15:45:30
 * @LastEditTime: 2021-09-07 16:56:34
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /x6-demo/src/main.js
 */
import Vue from 'vue/dist/vue.esm.js'
import App from './App.vue'
import Antd from 'ant-design-vue'

import 'ant-design-vue/dist/antd.css';

Vue.use(Antd)
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')