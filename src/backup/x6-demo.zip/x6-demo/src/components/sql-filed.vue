<!--
 * @Author: your name
 * @Date: 2021-07-22 15:31:15
 * @LastEditTime: 2021-07-22 16:45:50
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /x6-demo/src/components/sql-filed.vue
-->

<template>
    <div class="body">
            <div class="body-item" v-for="filed in fileds" :key="filed.propertyId">
                <div class="name">
                   <span v-if="filed.isPK" class="pk">PK</span>
                   <span v-if="filed.isFK" class="fk">FK</span>
                   <span :title="filed.name">{{filed.name}}</span>
                </div>
                <div class="type">{{filed.propertyType}}</div>
            </div>
    </div>
</template>

<script>
export default {
    name: 'sqlfiled'
}
</script>

<style lang="less" scoped>
    .body {
      width: calc(100% - 12px);
      height: calc(100% - 36px - 6px);
      margin-left: 6px;
      margin-bottom: 6px;
      background-color: white;
      overflow: auto;
      cursor: pointer;

      .body-item {
        width: 100%;
        height: 28px;
        font-size: 12px;
        color: #595959;
        border-bottom: 1px solid rgba(206, 212, 222, 0.2);
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;

        .name {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          margin-left: 6px;

          .pk,
          .fk {
            width: 12px;
            font-family: HelveticaNeue-CondensedBold;
            color: #ffd666;
            margin-right: 6px;
          }
        }

        .type {
          color: #bfbfbf;
          font-size: 8px;
          margin-right: 8px;
        }
      }
    }
</style>