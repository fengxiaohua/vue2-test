<!--
 * @Author: your name
 * @Date: 2021-07-20 15:45:30
 * @LastEditTime: 2021-07-20 15:58:02
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /x6-demo/src/components/HelloWorld.vue
-->
<template>
  <x-6/>
</template>

<script>
import x6 from './x6.vue'
export default {
  components: { x6 },
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
