<!--
 * @Author: your name
 * @Date: 2021-07-20 15:56:59
 * @LastEditTime: 2021-10-09 15:37:35
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /x6-demo/src/components/x6.vue
-->
<template>
<div class="g6-demo"> 
    <div class="er-editor-demo-container">
        <div id="container"/>
        <div id="minimap-container" class="minimap-container" />
        <div class="toolbar">
            <ul class="handler">
                <li class="item">
                    <a-tooltip placement="left">
                        <template slot="title">
                          放大
                        </template>
                        <a-icon @click="onHandleToolbar('in')" type="zoom-in" class="icons"/>
                    </a-tooltip>
                </li>
                <li class="item">
                    <a-tooltip placement="left">
                        <template slot="title">
                          缩小
                        </template>
                        <a-icon @click="onHandleToolbar('out')" type="zoom-out" class="icons"/>
                    </a-tooltip>
                </li>
                <li class="item">
                    <a-tooltip placement="left">
                        <template slot="title">
                          实际尺寸
                        </template>
                        <a-icon @click="onHandleToolbar('fit')" type="border-horizontal" class="icons"/>
                    </a-tooltip>
                </li>
                <li class="item">
                    <a-tooltip placement="left">
                        <template slot="title">
                          适应画布
                        </template>
                        <a-icon @click="onHandleToolbar('real')" type="drag" class="icons"/>
                    </a-tooltip>
                </li>
            </ul>
        </div>
    </div>
</div>
</template>

<script>
import { Graph } from '@antv/x6'
import '@antv/x6-vue-shape' //导入支持vue渲染节点的包

import sqltable from './sql-table.vue'   //导入测试的vue页面

const mockProperties = [
  {
    propertyId: 'propertyId1',
    name: '业务日期',
    propertyType: 'string',
    isPK: true,
  },
  {
    propertyId: 'propertyId2',
    name: '交易号',
    propertyType: 'bigint',
    isFK: true,
  },
  {
    propertyId: 'propertyId3',
    name: '最长的显示的字段名称啦啦啦啦啦啦',
    propertyType: 'string',
  },
  {
    propertyId: 'propertyId4',
    name: '交易支付外键',
    propertyType: 'string',
  },
  {
    propertyId: 'propertyId5',
    name: '卖家支付日期',
    propertyType: 'string',
  },
  {
    propertyId: 'propertyId6',
    name: '业务日期',
    propertyType: 'string',
  },
  {
    propertyId: 'propertyId7',
    name: '业务日期',
    propertyType: 'string',
  },
  {
    propertyId: 'propertyId8',
    name: '业务日期111',
    propertyType: 'string',
  },
  {
    propertyId: 'propertyId9',
    name: '业务日期222',
    propertyType: 'string',
  },
  {
    propertyId: 'propertyId10',
    name: '业务日期333',
    propertyType: 'string',
  }
];


/** ER图节点数据 */
const mockEntityData = [
  {
    shape: 'vue-shape',
    data: {
          entityId: 'dim_down',
          name: '维度表',
          entityType: 'DIM',
          properties: mockProperties,
    },
    id: 'dim_down',
    width: 100,
    height: 100,
    x: 100,
    y: 100,
    component: {
        template: `<sqltable :fileds="fileds" id="sql1"/>`,
        data() {
          return {
            fileds: mockProperties
          }
        },
        components: {
          sqltable,
        }
  }
  },
    
  {
    shape: 'vue-shape',
    data: {
        entityId: 'fact_down2',
        name: '事实表',
        entityType: 'FACT',
        properties: mockProperties,
    },
    id: 'fact_down2',
    x: 400,
    y: 100,
    width: 200,
    height: 100,
    component: {
        template: `<sqltable :fileds="fileds" id="sql2"/>`,
        data() {
          return {
            fileds: mockProperties
          }
        },
        components: {
          sqltable,
        }
  }
  },
];

// 边
const edges = [
    {
      source: 'dim_down', // String，必须，起始节点 id
      target: 'fact_down2', // String，必须，目标节点 id
      attrs: {
        line: { //配置边的 连接线
          stroke: '#ced4de',  //颜色
        },
      }
    },
  ]

// 画布
const graphConfig = {
    keyboard: {
      enabled: true,  //键鼠
    },
    clipboard: {
      enabled: true   //剪切
    },

    minimap: {
      enabled: false
    },

    /** 无限画布设置 */
    scroller: { //滚动
        enabled: true,
        pageBreak: false,   //分页符
        pageVisible: false, //分页
        pannable: true, //画布平移
    },

    /** 画布网格 */
      grid: {
        visible: false,
        size: 1,
        type: 'doubleMesh',
        args: [
          {
            color: '#888',
            // thickness: 1,
          },
          // {
          //   color: '#ddd',
          //   thickness: 1,
          //   factor: 4,
          // },
        ],
      },

      /** 全局连线配置 */
      connecting: {
        connector: {
          name: 'rounded',
        },
        router: {
          name: 'er',
          args: {
            direction: 'H',
          },
        },
      },

    snapline: { //对齐线
        enabled: true,
    },
}  


// const data = {
//   // 节点
//   nodes: [
//     {
//       id: 'node1', // String，可选，节点的唯一标识
//       x: 40,       // Number，必选，节点位置的 x 值
//       y: 40,       // Number，必选，节点位置的 y 值
//       width: 80,   // Number，可选，节点大小的 width 值
//       height: 40,  // Number，可选，节点大小的 height 值
//       label: 'hello', // String，节点标签
//     },
//     {
//       id: 'node2', // String，节点的唯一标识
//       x: 160,      // Number，必选，节点位置的 x 值
//       y: 180,      // Number，必选，节点位置的 y 值
//       width: 80,   // Number，可选，节点大小的 width 值
//       height: 40,  // Number，可选，节点大小的 height 值
//       label: 'world', // String，节点标签
//     },
//   ],
//   // 边
//   edges: [
//     {
//       source: 'node1', // String，必须，起始节点 id
//       target: 'node2', // String，必须，目标节点 id
//     },
//   ],
// };

export default {
  name: 'x6',
  data() {
      return {
          mockEntityData,
          mockProperties,
          edges,
          graphConfig,
          graph: null
      }
  },
  mounted() {
      this.init()
  },
  methods: {
      init() {
            const data = {nodes: this.mockEntityData, edges: this.edges}

            console.log(data)

            this.graph = new Graph({
                container: document.getElementById('container'),
                width: 900,
                height: 200,


                // 配置选项
                translating: {
                //      此处可以设置为不能移动
                //     restrict: {
                //         x: 0,   //起始位置X
                //         y: 0,   //起始位置Y
                //         width: 0,   //移动宽度
                //         height: 0,  //移动高度
                //         }
                restrict: true  //设置不能移动出画布
                },

                //小地图配置
                minimap: {
                    container: document.getElementById('minimap-container'), //指定元素，必要
                    enabled: true,  //是否可用
                    maxScale: 2,    //最小缩放比例
                    minScale: 0.5   //最大缩放比例
                },

                ...graphConfig
            
            });

            this.graph.fromJSON(data)
      },


      // toolbar 相关js操作

      /**
       * @param action 操作 in out fit real
       */
      onHandleToolbar(action) {
          switch (action) {
            case 'in':
                this.zoomGraph(0.1);
                break;
            case 'out':
                this.zoomGraph(-0.1);
                break;
            case 'fit':
                this.zoomGraph('fit');
                break;
            case 'real':
                this.zoomGraph('real');
                break;
            default:
            }
      },

     /**
      * 画布缩放
      * @param {number} factor 缩放比例尺
      */
      zoomGraph(factor) {
        if (typeof factor === 'number') {
            // 放大或者缩小
        this.graph.zoom(factor);
        } else if (factor === 'fit') {
        this.graph.zoomToFit({ padding: 12 });
        } else if (factor) {
        this.graph.scale(1);
        this.graph.centerContent();
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
.g6-demo {
width: 100%;
height: 200px;
overflow: hidden;

  .er-editor-demo-container {
  background-color: #fafafa;

  .minimap-container {
    position: absolute;
    top: 10px;
    right: 10px;

    /** X6推荐覆写样式 */
    .x6-widget-minimap {
      .x6-graph {
        box-shadow: 0 0 0 0 #ffffff;
      }

      .x6-widget-minimap-viewport {
        border: 1px solid rgba(0, 0, 0, 0.1);

        .x6-widget-minimap-viewport-zoom {
          border: 1px solid rgba(0, 0, 0, 0.1);
        }
      }
    }
  }
}

// toolbarList
.toolbar{
    position: absolute;
    bottom: 10px;
    right: 10px;

.handler {
    position: absolute;
    bottom: 10px;
    right: 14px;
    z-index: 99;
    width: 32px;
    margin: 0;
    padding: 8px 0;
    color: rgba(0, 0, 0, 0.45);
    font-size: 16px;
    list-style-type: none;
    background-color: #fff;
    border: 1px solid rgba(0, 0, 0, 0.04);
    border-radius: 3px;
    box-shadow: 0 0 20px rgb(0 0 0 / 1%);

  .item {
    text-align: center;
    cursor: pointer;

    .icons {
        display: inline-block;
        color: inherit;
        font-style: normal;
        line-height: 0;
        text-align: center;
        text-transform: none;
        vertical-align: -0.125em;
        text-rendering: optimizeLegibility;
        -webkit-font-smoothing: antialiased;
    }

    &:hover {
      color: #000;
      background-color: #e0e0e0;
    }
  }
}
}

.entity-container {
  // width: calc(100% - 2px);
  // height: calc(100% - 2px);
  border-radius: 2px;
  background-color: white;

  &.fact {
    border: 1px solid #ced4de;

    &:hover {
      border: 1px solid #1890ff;
    }
  }

  &.dim {
    border: 1px solid #cdddfd;

    &:hover {
      border: 1px solid #1890ff;
    }
  }

  &.other {
    border: 1px solid #decfea;

    &:hover {
      border: 1px solid #1890ff;
    }
  }

  .content {
    margin: 1px 1px;
    width: calc(100% - 2px);
    height: calc(100% - 2px);

    &.fact {
      background-color: #ced4de;
    }

    &.dim {
      background-color: #cdddfd;
    }

    &.other {
      background-color: #decfea;
    }

    .head {
      width: calc(100% - 12px);
      height: 38px;
      margin-left: 6px;
      font-size: 12px;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;

      .type {
        padding-right: 8px;
      }

      .more {
        cursor: pointer;
      }
    }

    .body {
      width: calc(100% - 12px);
      height: calc(100% - 36px - 6px);
      margin-left: 6px;
      margin-bottom: 6px;
      background-color: white;
      overflow: auto;
      cursor: pointer;

      .body-item {
        width: 100%;
        height: 28px;
        font-size: 12px;
        color: #595959;
        border-bottom: 1px solid rgba(206, 212, 222, 0.2);
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;

        .name {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          margin-left: 6px;

          .pk,
          .fk {
            width: 12px;
            font-family: HelveticaNeue-CondensedBold;
            color: #ffd666;
            margin-right: 6px;
          }
        }

        .type {
          color: #bfbfbf;
          font-size: 8px;
          margin-right: 8px;
        }
      }
    }
  }
}
}
</style>