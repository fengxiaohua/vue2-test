https://www.cnblogs.com/mq0036/p/10416717.html



1. keydown：当用户按下键盘上的任意键时触发，如果按住不放的话，会重复触发此事
2. keypress：当用户按下键盘上的**字符键**时触发，如果按住不放的话，会重复触发此事件；
3. keyup：当用户**释放**键盘上的字符键时触发。



触发顺序问题

keydown -> keypress ->keyup

