```
1. 查看原项目的remote
    git remote -v
2. 解除关联
    git remote rm “remote名称”
3. 取消git初始化
    rm -rf .git
```
