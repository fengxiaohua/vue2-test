## 一、常用快捷键

https://juejin.cn/post/6844904131434381319

## 二、插件

1. Code Spell Checker 检测代码英文单词错误
2. GitLens 增强git功能
3. Vue 2 Snippets 可自动生成Vue2模板

