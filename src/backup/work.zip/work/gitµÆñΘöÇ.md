1. 执行commit后，还没执行push时，想要撤销这次的commit，该怎么办？

`git reset --soft HEAD^`

2. 基于某分支 创建 新分支
   
   `git checkout -b feature/task-1 origin/master`
