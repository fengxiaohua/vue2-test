```
查看当前镜像
yarn config get registry

公司私服：
yarn config set registry http://mvn.senses-ai.com:8081/repository/npm-group/

设置淘宝镜像
yarn config set registry https://registry.npm.taobao.org


yarn config set registry http://192.168.10.87:8081/repository/npm-group/
```


