1. npm install ts-node -g
2. npm init -y 生成默认的package.json
3. npm install @types/node -D 安装声明文件
4. npm install express -S
5. npm install @types/express -D
6. npm install axios -S