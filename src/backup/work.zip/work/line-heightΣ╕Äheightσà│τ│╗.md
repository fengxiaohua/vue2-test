![image-20211213105828415](/Users/xiaohang/Library/Application Support/typora-user-images/image-20211213105828415.png)

**行高是指文本行基线间的垂直距离。** 基线（base line）并不是汉字文字的下端沿，而是英文字母“x”的下端沿。图中两条红线之间的距离就是行高，上行的底线和下一行顶线之间的距离就是行距，而同一行顶线和底线之间的距离是font-size的大小，行距的一半是半行距