```
在tsconfig.json的compilerOptions编译配置中
设置：
"checkJs": true,//检查js代码是否符合语法规范
"noEmit": true 	//生成js文件
```

