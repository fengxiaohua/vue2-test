## 一、绘制三角形

```css
.arrow {
          width: 0;
          height: 0;
          border-left: 8px solid #E0E0E0;
          border-top: 4px solid transparent;
          border-bottom: 4px solid transparent;
        }
```

原理：

![image-20220302094337637](/Users/xiaohang/Library/Application Support/typora-user-images/image-20220302094337637.png)