直接设置 resize:none

将背景颜色设置为默认禁用颜色 color: #8F8F8F;

