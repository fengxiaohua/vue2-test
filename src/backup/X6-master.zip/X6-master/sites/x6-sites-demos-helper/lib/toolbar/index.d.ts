import React from 'react';
import 'antd/dist/antd.css';
import './index.css';
export declare class Toolbar extends React.Component {
    render(): JSX.Element;
}
