import React from 'react';
import './content.css';
export declare class Content extends React.Component<Content.Props, Content.State> {
    private container;
    constructor(props: Content.Props);
    componentDidMount(): void;
    updateIframeSize(): void;
    refContainer: (container: HTMLDivElement) => void;
    render(): JSX.Element;
}
export declare namespace Content {
    interface Props {
    }
    interface State {
    }
}
export declare namespace Content {
    function saveIframeSize(): void;
    function restoreIframeSize(): void;
}
