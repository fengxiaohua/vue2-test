import React from 'react';
import 'antd/es/alert/style/index.css';
export declare const Wrap: React.FC;
