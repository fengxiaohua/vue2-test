## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-17)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))
* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-16)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))
* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-15)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-15)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-11)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-09)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-09)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-02)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-02)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-06-01)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-31)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-31)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-31)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-27)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-18)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-18)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-12)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-08)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-06)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-04)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-01)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-05-01)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-28)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-28)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-28)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-26)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-21)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-17)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-13)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-04-01)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-30)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-30)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-29)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-28)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-25)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-24)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-24)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-24)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-24)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-23)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-23)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-23)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-23)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-20)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-19)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-19)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-16)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-15)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

## @antv/x6-sites-demos-helper [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.2.0...@antv/x6-sites-demos-helper@1.2.1) (2021-03-15)


### Bug Fixes

* 🐛 temporarily disable stackblitz ([d454ba2](https://github.com/antvis/x6/commit/d454ba2d4ae3e45ad2fabc8074c79121abd5de6b))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-03-02)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-23)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-23)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-22)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-20)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-09)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-07)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-07)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-05)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-05)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-04)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-03)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

# @antv/x6-sites-demos-helper [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@1.1.2...@antv/x6-sites-demos-helper@1.2.0) (2021-02-03)


### Features

* ✨ add favicon for demos ([424662a](https://github.com/antvis/x6/commit/424662a9ccbbb21142b217bc256b9cc8242fb101))

## @antv/x6-sites-demos-helper [0.11.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.11.0...@antv/x6-sites-demos-helper@0.11.1) (2021-01-13)

# @antv/x6-sites-demos-helper [0.11.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.10.80...@antv/x6-sites-demos-helper@0.11.0) (2021-01-12)


### Features

* ✨ auto update dependencies in workspace ([c255b41](https://github.com/antvis/x6/commit/c255b410099c607f535fa359d66f61b4ddaf59d9))

# @antv/x6-sites-demos-helper [0.11.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.10.80...@antv/x6-sites-demos-helper@0.11.0) (2021-01-11)


### Features

* ✨ auto update dependencies in workspace ([c255b41](https://github.com/antvis/x6/commit/c255b410099c607f535fa359d66f61b4ddaf59d9))

## @antv/x6-sites-demos-helper [0.11.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.11.0...@antv/x6-sites-demos-helper@0.11.1) (2021-01-11)

# @antv/x6-sites-demos-helper [0.11.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.10.82...@antv/x6-sites-demos-helper@0.11.0) (2020-12-25)


### Features

* ✨ auto update dependencies in workspace ([c255b41](https://github.com/antvis/x6/commit/c255b410099c607f535fa359d66f61b4ddaf59d9))

## @antv/x6-sites-demos-helper [0.10.82](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.10.81...@antv/x6-sites-demos-helper@0.10.82) (2020-12-21)

## @antv/x6-sites-demos-helper [0.10.81](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.10.80...@antv/x6-sites-demos-helper@0.10.81) (2020-12-07)

## @antv/x6-sites-demos-helper [0.10.80](https://github.com/antvis/x6/compare/@antv/x6-sites-demos-helper@0.10.79...@antv/x6-sites-demos-helper@0.10.80) (2020-11-20)


### chore

* 🛠️ init changelog ([6c38b3c](https://github.com/antvis/x6/commit/6c38b3c74c0d603b4e8a50c7ad32e38292d2639b))


### BREAKING CHANGES

* force release 1.0
