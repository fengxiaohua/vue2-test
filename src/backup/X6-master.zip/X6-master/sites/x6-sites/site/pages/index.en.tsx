import Index from './index.zh'

export default Index
