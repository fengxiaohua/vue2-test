# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-31)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))





### Dependencies

* **@antv/x6:** upgraded to 1.26.1

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-24)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))





### Dependencies

* **@antv/x6:** upgraded to 1.26.0

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-18)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))

## @antv/x6-sites-demos [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.0...@antv/x6-sites-demos@1.2.1) (2021-08-18)





### Dependencies

* **@antv/x6:** upgraded to 1.25.5

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-17)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))





### Dependencies

* **@antv/x6:** upgraded to 1.25.4

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-16)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-06)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))





### Dependencies

* **@antv/x6:** upgraded to 1.25.3

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-06)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))





### Dependencies

* **@antv/x6:** upgraded to 1.25.2

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-08-03)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))





### Dependencies

* **@antv/x6:** upgraded to 1.25.1

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.2.0) (2021-07-27)


### Features

* ✨ add cell-editor tool ([#1202](https://github.com/antvis/x6/issues/1202)) ([2286097](https://github.com/antvis/x6/commit/228609783e1b3a3ff579ce9d38cf2e70dacd4931))





### Dependencies

* **@antv/x6:** upgraded to 1.25.0

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2021-07-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.8

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.7

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.6

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2021-07-10)

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2021-07-09)





### Dependencies

* **@antv/x6:** upgraded to 1.24.5

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-07-05)

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-23)

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-23)





### Dependencies

* **@antv/x6:** upgraded to 1.24.4

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.3

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-21)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.4.5

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.2

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-21)

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.1

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2021-06-20)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.4.4

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-19)





### Dependencies

* **@antv/x6:** upgraded to 1.24.0

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2021-06-19)





### Dependencies

* **@antv/x6:** upgraded to 1.23.13

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-18)

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-17)

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-17)





### Dependencies

* **@antv/x6:** upgraded to 1.23.12

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-17)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.11
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-16)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.10
* **@antv/x6-react-components:** upgraded to 1.1.13
* **@antv/x6-react-shape:** upgraded to 1.4.3
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-15)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-15)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.9
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-13)





### Dependencies

* **@antv/x6:** upgraded to 1.23.8

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-11)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.7
* **@antv/x6-react-components:** upgraded to 1.1.12
* **@antv/x6-react-shape:** upgraded to 1.4.2
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-06-09)





### Dependencies

* **@antv/x6:** upgraded to 1.23.6

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-09)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.5
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-09)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.4
* **@antv/x6-react-components:** upgraded to 1.1.11
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.3
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.2
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-02)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.1
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-02)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.23.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-06-01)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.22.1
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-31)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-31)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-31)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.10
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-27)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.22.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-18)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.21.7
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-18)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.21.6
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-05-14)





### Dependencies

* **@antv/x6:** upgraded to 1.21.5

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-12)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.21.4
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-08)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.21.3
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.21.2
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-07)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.21.1
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-06)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.21.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-04)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.20.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-01)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.19.6
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-05-01)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.19.5
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.19.4
* **@antv/x6-react-shape:** upgraded to 1.4.1
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-30)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-28)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.19.3
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-28)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.19.2
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-28)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.19.1
* **@antv/x6-react-shape:** upgraded to 1.4.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-26)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.19.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-21)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-04-20)





### Dependencies

* **@antv/x6:** upgraded to 1.18.5

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-17)


### Bug Fixes

* 🐛 fix lack of deps in demo ([a6232fc](https://github.com/antvis/x6/commit/a6232fc35934cb6b31e735af040fb8115813bb12))
* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.18.4
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-13)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.18.3
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-04-01)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.9
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-30)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.18.2
* **@antv/x6-react-components:** upgraded to 1.1.8
* **@antv/x6-react-shape:** upgraded to 1.3.5
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-30)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.18.1
* **@antv/x6-react-components:** upgraded to 1.1.7
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-29)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.6
* **@antv/x6-react-shape:** upgraded to 1.3.4
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-28)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-25)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-24)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.5
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-24)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-24)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.4
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-24)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.3
* **@antv/x6-react-shape:** upgraded to 1.3.3
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-23)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-23)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.18.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-23)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-23)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.7
* **@antv/x6-react-components:** upgraded to 1.1.2
* **@antv/x6-react-shape:** upgraded to 1.3.2
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-20)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.6
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-19)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.5
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-19)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.4
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-16)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-15)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-15)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-12)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-12)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-12)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.3

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-12)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.2

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-11)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-11)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.17.0

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.16.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-10)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.15.0

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-03-10)





### Dependencies

* **@antv/x6:** upgraded to 1.14.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-07)


### Bug Fixes

* 🐛 update layout version ([a37f640](https://github.com/antvis/x6/commit/a37f640c915e061d2fccc2ce2ae077e27c0bafd2))
* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-04)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-03)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.13.4

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-02)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.13.3

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-02)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-03-02)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-23)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.13.1
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-23)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.13.0
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-22)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-20)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.32
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-09)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.31
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-07)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-07)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.30
* **@antv/x6-react-shape:** upgraded to 1.3.1
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-05)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.29
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-05)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-04)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.28
* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-03)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-03)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-03)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.27

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-02)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.26

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-02)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)
* fix demo error in sites ([#641](https://github.com/antvis/x6/issues/641)) ([a8f90b1](https://github.com/antvis/x6/commit/a8f90b16a953ddb9970f9d6954d541d3f8375869))





### Dependencies

* **@antv/x6:** upgraded to 1.12.25

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-02)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.24

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-02)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-02-01)





### Dependencies

* **@antv/x6:** upgraded to 1.12.23

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-01)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.22

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-02-01)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-31)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-31)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.21

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-30)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-30)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-30)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-29)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.20

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-28)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.19

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-27)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.18

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-26)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.3.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-26)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.17

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-01-25)





### Dependencies

* **@antv/x6:** upgraded to 1.12.16

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-25)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.15

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-25)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-24)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.14

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-01-23)





### Dependencies

* **@antv/x6:** upgraded to 1.12.13

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-23)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.12

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-22)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.11
* **@antv/x6-react-shape:** upgraded to 1.2.5

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-22)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-22)


### Bug Fixes

* add `placeholder` and `notFoundText` for stencil component ([#574](https://github.com/antvis/x6/issues/574)) ([c9100ab](https://github.com/antvis/x6/commit/c9100abb8576eaf55c5a9b0c5496f63c1796af5a)), closes [#555](https://github.com/antvis/x6/issues/555)





### Dependencies

* **@antv/x6:** upgraded to 1.12.10

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-22)





### Dependencies

* **@antv/x6:** upgraded to 1.12.9

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.8

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-21)

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.7

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.6

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.5

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-20)





### Dependencies

* **@antv/x6:** upgraded to 1.12.4

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-20)





### Dependencies

* **@antv/x6:** upgraded to 1.12.3

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-20)





### Dependencies

* **@antv/x6:** upgraded to 1.12.2

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-19)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-19)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-18)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-15)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-14)





### Dependencies

* **@antv/x6:** upgraded to 1.12.1

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-13)

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.12.0

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.11.6

## @antv/x6-sites-demos [1.1.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.0...@antv/x6-sites-demos@1.1.1) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.8.3
* **@antv/x6-react-components:** upgraded to 1.0.3
* **@antv/x6-react-shape:** upgraded to 1.2.2
* **@antv/x6-sites-demos-helper:** upgraded to 0.11.1

# @antv/x6-sites-demos [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.0...@antv/x6-sites-demos@1.1.0) (2021-01-12)


### Bug Fixes

* 🐛 auto calc er router's direction ([9b9a727](https://github.com/antvis/x6/commit/9b9a727c9b168af80623be448d5ae389a21a72b0))
* 🐛 change component -> render ([b90c519](https://github.com/antvis/x6/commit/b90c519c98a5adf81f111fb3ea1d8781ce7996bc))
* 🐛 checkView should return a boolean ([8c309a7](https://github.com/antvis/x6/commit/8c309a7b84276a722c25c319088e00822d1fc381))
* 🐛 dnd node style ([17ae1f9](https://github.com/antvis/x6/commit/17ae1f9492c1f77e93ffa0a4cc1fb10614350547))
* 🐛 fix layout demo error in codesanbox ([63184b3](https://github.com/antvis/x6/commit/63184b3f21be82d9daa46f8921c62d778b85a9fe))
* 🐛 update intersectswith to intersectsWithRect ([fb0f144](https://github.com/antvis/x6/commit/fb0f144dc257a7a74ef5342f48359924c23b04a4))
* 🐛 use `graph.createNode` to create node ([9e38fdf](https://github.com/antvis/x6/commit/9e38fdf1b1f04bedf1d029037ed1a43a33fcfa15))


### Features

* ✨ add `animate` and `animateTransform` ([b2ebf69](https://github.com/antvis/x6/commit/b2ebf69f2c311b1b8056179005d8fafd0a7eb8e9))
* ✨ add connector demos ([929b691](https://github.com/antvis/x6/commit/929b6913dfd2637844ed4c133c8cb30efc2d4177))


### Performance Improvements

* ⚡️ add transition callbacks and events for animation lifecycle ([462abd0](https://github.com/antvis/x6/commit/462abd0aa06e28bbbabf96ffd0493af4a9af6e1a)), closes [#419](https://github.com/antvis/x6/issues/419) [#420](https://github.com/antvis/x6/issues/420)





### Dependencies

* **@antv/x6:** upgraded to 1.8.2
* **@antv/x6-react-components:** upgraded to 1.0.2
* **@antv/x6-react-shape:** upgraded to 1.2.1
* **@antv/x6-sites-demos-helper:** upgraded to 0.11.0

## @antv/x6-sites-demos [1.1.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.0...@antv/x6-sites-demos@1.1.1) (2021-01-12)





### Dependencies

* **@antv/x6:** upgraded to 1.8.1

# @antv/x6-sites-demos [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.0...@antv/x6-sites-demos@1.1.0) (2021-01-11)


### Bug Fixes

* 🐛 auto calc er router's direction ([9b9a727](https://github.com/antvis/x6/commit/9b9a727c9b168af80623be448d5ae389a21a72b0))
* 🐛 change component -> render ([b90c519](https://github.com/antvis/x6/commit/b90c519c98a5adf81f111fb3ea1d8781ce7996bc))
* 🐛 checkView should return a boolean ([8c309a7](https://github.com/antvis/x6/commit/8c309a7b84276a722c25c319088e00822d1fc381))
* 🐛 dnd node style ([17ae1f9](https://github.com/antvis/x6/commit/17ae1f9492c1f77e93ffa0a4cc1fb10614350547))
* 🐛 fix layout demo error in codesanbox ([63184b3](https://github.com/antvis/x6/commit/63184b3f21be82d9daa46f8921c62d778b85a9fe))
* 🐛 update intersectswith to intersectsWithRect ([fb0f144](https://github.com/antvis/x6/commit/fb0f144dc257a7a74ef5342f48359924c23b04a4))
* 🐛 use `graph.createNode` to create node ([9e38fdf](https://github.com/antvis/x6/commit/9e38fdf1b1f04bedf1d029037ed1a43a33fcfa15))


### Features

* ✨ add `animate` and `animateTransform` ([b2ebf69](https://github.com/antvis/x6/commit/b2ebf69f2c311b1b8056179005d8fafd0a7eb8e9))
* ✨ add connector demos ([929b691](https://github.com/antvis/x6/commit/929b6913dfd2637844ed4c133c8cb30efc2d4177))


### Performance Improvements

* ⚡️ add transition callbacks and events for animation lifecycle ([462abd0](https://github.com/antvis/x6/commit/462abd0aa06e28bbbabf96ffd0493af4a9af6e1a)), closes [#419](https://github.com/antvis/x6/issues/419) [#420](https://github.com/antvis/x6/issues/420)





### Dependencies

* **@antv/x6:** upgraded to 1.8.0
* **@antv/x6-react-components:** upgraded to 1.0.1
* **@antv/x6-react-shape:** upgraded to 1.2.0
* **@antv/x6-sites-demos-helper:** upgraded to 0.11.0

## @antv/x6-sites-demos [1.2.35](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.34...@antv/x6-sites-demos@1.2.35) (2021-01-11)





### Dependencies

* **@antv/x6:** upgraded to 1.11.2

## @antv/x6-sites-demos [1.2.34](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.33...@antv/x6-sites-demos@1.2.34) (2021-01-11)





### Dependencies

* **@antv/x6:** upgraded to 1.11.1
* **@antv/x6-react-shape:** upgraded to 1.2.2
* **@antv/x6-sites-demos-helper:** upgraded to 0.11.1

## @antv/x6-sites-demos [1.2.33](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.32...@antv/x6-sites-demos@1.2.33) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.11.0
* **@antv/x6-react-shape:** upgraded to 1.2.1

## @antv/x6-sites-demos [1.2.32](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.31...@antv/x6-sites-demos@1.2.32) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.2
* **@antv/x6-react-shape:** upgraded to 1.2.0

## @antv/x6-sites-demos [1.2.31](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.30...@antv/x6-sites-demos@1.2.31) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.1
* **@antv/x6-react-shape:** upgraded to 1.1.60

## @antv/x6-sites-demos [1.2.30](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.29...@antv/x6-sites-demos@1.2.30) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.0
* **@antv/x6-react-shape:** upgraded to 1.1.59

## @antv/x6-sites-demos [1.2.29](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.28...@antv/x6-sites-demos@1.2.29) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.3
* **@antv/x6-react-shape:** upgraded to 1.1.58

## @antv/x6-sites-demos [1.2.28](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.27...@antv/x6-sites-demos@1.2.28) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.2
* **@antv/x6-react-shape:** upgraded to 1.1.57

## @antv/x6-sites-demos [1.2.27](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.26...@antv/x6-sites-demos@1.2.27) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.1
* **@antv/x6-react-shape:** upgraded to 1.1.56

## @antv/x6-sites-demos [1.2.26](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.25...@antv/x6-sites-demos@1.2.26) (2021-01-04)





### Dependencies

* **@antv/x6:** upgraded to 1.9.0
* **@antv/x6-react-shape:** upgraded to 1.1.55

## @antv/x6-sites-demos [1.2.25](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.24...@antv/x6-sites-demos@1.2.25) (2021-01-04)





### Dependencies

* **@antv/x6:** upgraded to 1.8.0
* **@antv/x6-react-shape:** upgraded to 1.1.54

## @antv/x6-sites-demos [1.2.24](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.23...@antv/x6-sites-demos@1.2.24) (2021-01-04)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.1.53

## @antv/x6-sites-demos [1.2.23](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.22...@antv/x6-sites-demos@1.2.23) (2020-12-31)





### Dependencies

* **@antv/x6:** upgraded to 1.7.12
* **@antv/x6-react-shape:** upgraded to 1.1.52

## @antv/x6-sites-demos [1.2.22](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.21...@antv/x6-sites-demos@1.2.22) (2020-12-30)


### Bug Fixes

* 🐛 auto calc er router's direction ([9b9a727](https://github.com/antvis/x6/commit/9b9a727c9b168af80623be448d5ae389a21a72b0))





### Dependencies

* **@antv/x6:** upgraded to 1.7.11
* **@antv/x6-react-shape:** upgraded to 1.1.51

## @antv/x6-sites-demos [1.2.21](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.20...@antv/x6-sites-demos@1.2.21) (2020-12-29)





### Dependencies

* **@antv/x6:** upgraded to 1.7.10
* **@antv/x6-react-shape:** upgraded to 1.1.50

## @antv/x6-sites-demos [1.2.20](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.19...@antv/x6-sites-demos@1.2.20) (2020-12-29)





### Dependencies

* **@antv/x6:** upgraded to 1.7.9
* **@antv/x6-react-shape:** upgraded to 1.1.49

## @antv/x6-sites-demos [1.2.19](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.18...@antv/x6-sites-demos@1.2.19) (2020-12-28)





### Dependencies

* **@antv/x6:** upgraded to 1.7.8
* **@antv/x6-react-shape:** upgraded to 1.1.48

## @antv/x6-sites-demos [1.2.18](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.17...@antv/x6-sites-demos@1.2.18) (2020-12-28)


### Bug Fixes

* 🐛 fix layout demo error in codesanbox ([63184b3](https://github.com/antvis/x6/commit/63184b3f21be82d9daa46f8921c62d778b85a9fe))

## @antv/x6-sites-demos [1.2.17](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.16...@antv/x6-sites-demos@1.2.17) (2020-12-28)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.0.4

## @antv/x6-sites-demos [1.2.16](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.15...@antv/x6-sites-demos@1.2.16) (2020-12-26)





### Dependencies

* **@antv/x6:** upgraded to 1.7.7
* **@antv/x6-react-shape:** upgraded to 1.1.47

## @antv/x6-sites-demos [1.2.15](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.14...@antv/x6-sites-demos@1.2.15) (2020-12-25)





### Dependencies

* **@antv/x6:** upgraded to 1.7.6
* **@antv/x6-react-shape:** upgraded to 1.1.46

## @antv/x6-sites-demos [1.2.14](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.13...@antv/x6-sites-demos@1.2.14) (2020-12-25)





### Dependencies

* **@antv/x6:** upgraded to 1.7.5
* **@antv/x6-react-shape:** upgraded to 1.1.45
* **@antv/x6-sites-demos-helper:** upgraded to 0.11.0

## @antv/x6-sites-demos [1.2.13](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.12...@antv/x6-sites-demos@1.2.13) (2020-12-24)


### Bug Fixes

* 🐛 change component -> render ([b90c519](https://github.com/antvis/x6/commit/b90c519c98a5adf81f111fb3ea1d8781ce7996bc))





### Dependencies

* **@antv/x6:** upgraded to 1.7.4
* **@antv/x6-react-shape:** upgraded to 1.1.44

## @antv/x6-sites-demos [1.2.12](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.11...@antv/x6-sites-demos@1.2.12) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.3
* **@antv/x6-react-shape:** upgraded to 1.1.43

## @antv/x6-sites-demos [1.2.11](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.10...@antv/x6-sites-demos@1.2.11) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.2
* **@antv/x6-react-shape:** upgraded to 1.1.42

## @antv/x6-sites-demos [1.2.10](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.9...@antv/x6-sites-demos@1.2.10) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.1
* **@antv/x6-react-shape:** upgraded to 1.1.41

## @antv/x6-sites-demos [1.2.9](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.8...@antv/x6-sites-demos@1.2.9) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.0
* **@antv/x6-react-shape:** upgraded to 1.1.40

## @antv/x6-sites-demos [1.2.8](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.7...@antv/x6-sites-demos@1.2.8) (2020-12-23)





### Dependencies

* **@antv/x6:** upgraded to 1.6.4
* **@antv/x6-react-shape:** upgraded to 1.1.39

## @antv/x6-sites-demos [1.2.7](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.6...@antv/x6-sites-demos@1.2.7) (2020-12-22)





### Dependencies

* **@antv/x6:** upgraded to 1.6.3
* **@antv/x6-react-shape:** upgraded to 1.1.38

## @antv/x6-sites-demos [1.2.6](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.5...@antv/x6-sites-demos@1.2.6) (2020-12-22)





### Dependencies

* **@antv/x6:** upgraded to 1.6.2
* **@antv/x6-react-shape:** upgraded to 1.1.37

## @antv/x6-sites-demos [1.2.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.4...@antv/x6-sites-demos@1.2.5) (2020-12-21)





### Dependencies

* **@antv/x6:** upgraded to 1.6.1
* **@antv/x6-react-components:** upgraded to 1.0.3
* **@antv/x6-react-shape:** upgraded to 1.1.36
* **@antv/x6-sites-demos-helper:** upgraded to 0.10.82

## @antv/x6-sites-demos [1.2.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.3...@antv/x6-sites-demos@1.2.4) (2020-12-21)





### Dependencies

* **@antv/x6:** upgraded to 1.6.0
* **@antv/x6-react-shape:** upgraded to 1.1.35

## @antv/x6-sites-demos [1.2.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.2...@antv/x6-sites-demos@1.2.3) (2020-12-19)

## @antv/x6-sites-demos [1.2.2](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.1...@antv/x6-sites-demos@1.2.2) (2020-12-18)





### Dependencies

* **@antv/x6:** upgraded to 1.5.2
* **@antv/x6-react-shape:** upgraded to 1.1.34

## @antv/x6-sites-demos [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.2.0...@antv/x6-sites-demos@1.2.1) (2020-12-17)





### Dependencies

* **@antv/x6:** upgraded to 1.5.1
* **@antv/x6-react-shape:** upgraded to 1.1.33

# @antv/x6-sites-demos [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.31...@antv/x6-sites-demos@1.2.0) (2020-12-17)


### Features

* ✨ add `animate` and `animateTransform` ([b2ebf69](https://github.com/antvis/x6/commit/b2ebf69f2c311b1b8056179005d8fafd0a7eb8e9))


### Performance Improvements

* ⚡️ add transition callbacks and events for animation lifecycle ([462abd0](https://github.com/antvis/x6/commit/462abd0aa06e28bbbabf96ffd0493af4a9af6e1a)), closes [#419](https://github.com/antvis/x6/issues/419) [#420](https://github.com/antvis/x6/issues/420)





### Dependencies

* **@antv/x6:** upgraded to 1.5.0
* **@antv/x6-react-shape:** upgraded to 1.1.32

## @antv/x6-sites-demos [1.1.31](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.30...@antv/x6-sites-demos@1.1.31) (2020-12-17)


### Bug Fixes

* 🐛 dnd node style ([17ae1f9](https://github.com/antvis/x6/commit/17ae1f9492c1f77e93ffa0a4cc1fb10614350547))
* 🐛 use `graph.createNode` to create node ([9e38fdf](https://github.com/antvis/x6/commit/9e38fdf1b1f04bedf1d029037ed1a43a33fcfa15))

## @antv/x6-sites-demos [1.1.30](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.29...@antv/x6-sites-demos@1.1.30) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.2
* **@antv/x6-react-shape:** upgraded to 1.1.31

## @antv/x6-sites-demos [1.1.29](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.28...@antv/x6-sites-demos@1.1.29) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.1
* **@antv/x6-react-shape:** upgraded to 1.1.30

## @antv/x6-sites-demos [1.1.28](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.27...@antv/x6-sites-demos@1.1.28) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.0
* **@antv/x6-react-shape:** upgraded to 1.1.29

## @antv/x6-sites-demos [1.1.27](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.26...@antv/x6-sites-demos@1.1.27) (2020-12-13)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.0.2

## @antv/x6-sites-demos [1.1.26](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.25...@antv/x6-sites-demos@1.1.26) (2020-12-12)





### Dependencies

* **@antv/x6:** upgraded to 1.3.20
* **@antv/x6-react-shape:** upgraded to 1.1.28

## @antv/x6-sites-demos [1.1.25](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.24...@antv/x6-sites-demos@1.1.25) (2020-12-11)





### Dependencies

* **@antv/x6:** upgraded to 1.3.19
* **@antv/x6-react-shape:** upgraded to 1.1.27

## @antv/x6-sites-demos [1.1.24](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.23...@antv/x6-sites-demos@1.1.24) (2020-12-11)





### Dependencies

* **@antv/x6:** upgraded to 1.3.18
* **@antv/x6-react-shape:** upgraded to 1.1.26

## @antv/x6-sites-demos [1.1.23](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.22...@antv/x6-sites-demos@1.1.23) (2020-12-10)





### Dependencies

* **@antv/x6:** upgraded to 1.3.17
* **@antv/x6-react-shape:** upgraded to 1.1.25

## @antv/x6-sites-demos [1.1.22](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.21...@antv/x6-sites-demos@1.1.22) (2020-12-10)





### Dependencies

* **@antv/x6:** upgraded to 1.3.16
* **@antv/x6-react-shape:** upgraded to 1.1.24

## @antv/x6-sites-demos [1.1.21](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.20...@antv/x6-sites-demos@1.1.21) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.15
* **@antv/x6-react-shape:** upgraded to 1.1.23

## @antv/x6-sites-demos [1.1.20](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.19...@antv/x6-sites-demos@1.1.20) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.14
* **@antv/x6-react-shape:** upgraded to 1.1.22

## @antv/x6-sites-demos [1.1.19](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.18...@antv/x6-sites-demos@1.1.19) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.13
* **@antv/x6-react-shape:** upgraded to 1.1.21

## @antv/x6-sites-demos [1.1.18](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.17...@antv/x6-sites-demos@1.1.18) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.12
* **@antv/x6-react-shape:** upgraded to 1.1.20

## @antv/x6-sites-demos [1.1.17](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.16...@antv/x6-sites-demos@1.1.17) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.11
* **@antv/x6-react-shape:** upgraded to 1.1.19

## @antv/x6-sites-demos [1.1.16](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.15...@antv/x6-sites-demos@1.1.16) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.10
* **@antv/x6-react-shape:** upgraded to 1.1.18

## @antv/x6-sites-demos [1.1.15](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.14...@antv/x6-sites-demos@1.1.15) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.9
* **@antv/x6-react-shape:** upgraded to 1.1.17

## @antv/x6-sites-demos [1.1.14](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.13...@antv/x6-sites-demos@1.1.14) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.8
* **@antv/x6-react-shape:** upgraded to 1.1.16

## @antv/x6-sites-demos [1.1.13](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.12...@antv/x6-sites-demos@1.1.13) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.7
* **@antv/x6-react-shape:** upgraded to 1.1.15

## @antv/x6-sites-demos [1.1.12](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.11...@antv/x6-sites-demos@1.1.12) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.6
* **@antv/x6-react-shape:** upgraded to 1.1.14

## @antv/x6-sites-demos [1.1.11](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.10...@antv/x6-sites-demos@1.1.11) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.5
* **@antv/x6-react-shape:** upgraded to 1.1.13

## @antv/x6-sites-demos [1.1.10](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.9...@antv/x6-sites-demos@1.1.10) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.4
* **@antv/x6-react-components:** upgraded to 1.0.1
* **@antv/x6-react-shape:** upgraded to 1.1.12
* **@antv/x6-sites-demos-helper:** upgraded to 0.10.81

## @antv/x6-sites-demos [1.1.9](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.8...@antv/x6-sites-demos@1.1.9) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.3
* **@antv/x6-react-shape:** upgraded to 1.1.11

## @antv/x6-sites-demos [1.1.8](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.7...@antv/x6-sites-demos@1.1.8) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.2
* **@antv/x6-react-shape:** upgraded to 1.1.10

## @antv/x6-sites-demos [1.1.7](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.6...@antv/x6-sites-demos@1.1.7) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.1
* **@antv/x6-react-shape:** upgraded to 1.1.9

## @antv/x6-sites-demos [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.5...@antv/x6-sites-demos@1.1.6) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.0
* **@antv/x6-react-shape:** upgraded to 1.1.8

## @antv/x6-sites-demos [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.4...@antv/x6-sites-demos@1.1.5) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.3
* **@antv/x6-react-shape:** upgraded to 1.1.7

## @antv/x6-sites-demos [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.3...@antv/x6-sites-demos@1.1.4) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.2
* **@antv/x6-react-shape:** upgraded to 1.1.6

## @antv/x6-sites-demos [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.2...@antv/x6-sites-demos@1.1.3) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.1
* **@antv/x6-react-shape:** upgraded to 1.1.5

## @antv/x6-sites-demos [1.1.2](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.1...@antv/x6-sites-demos@1.1.2) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.2.0
* **@antv/x6-react-shape:** upgraded to 1.1.4

## @antv/x6-sites-demos [1.1.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.1.0...@antv/x6-sites-demos@1.1.1) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.1.3
* **@antv/x6-react-shape:** upgraded to 1.1.3

# @antv/x6-sites-demos [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.16...@antv/x6-sites-demos@1.1.0) (2020-12-02)


### Features

* ✨ add connector demos ([929b691](https://github.com/antvis/x6/commit/929b6913dfd2637844ed4c133c8cb30efc2d4177))





### Dependencies

* **@antv/x6:** upgraded to 1.1.2
* **@antv/x6-react-shape:** upgraded to 1.1.2

## @antv/x6-sites-demos [1.0.16](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.15...@antv/x6-sites-demos@1.0.16) (2020-11-30)





### Dependencies

* **@antv/x6:** upgraded to 1.1.1
* **@antv/x6-react-shape:** upgraded to 1.1.1

## @antv/x6-sites-demos [1.0.15](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.14...@antv/x6-sites-demos@1.0.15) (2020-11-27)





### Dependencies

* **@antv/x6:** upgraded to 1.1.0
* **@antv/x6-react-shape:** upgraded to 1.1.0

## @antv/x6-sites-demos [1.0.14](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.13...@antv/x6-sites-demos@1.0.14) (2020-11-27)





### Dependencies

* **@antv/x6:** upgraded to 1.0.9
* **@antv/x6-react-shape:** upgraded to 1.0.9

## @antv/x6-sites-demos [1.0.13](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.12...@antv/x6-sites-demos@1.0.13) (2020-11-25)





### Dependencies

* **@antv/x6:** upgraded to 1.0.8
* **@antv/x6-react-shape:** upgraded to 1.0.8

## @antv/x6-sites-demos [1.0.12](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.11...@antv/x6-sites-demos@1.0.12) (2020-11-25)





### Dependencies

* **@antv/x6:** upgraded to 1.0.7
* **@antv/x6-react-shape:** upgraded to 1.0.7

## @antv/x6-sites-demos [1.0.11](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.10...@antv/x6-sites-demos@1.0.11) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.6
* **@antv/x6-react-shape:** upgraded to 1.0.6

## @antv/x6-sites-demos [1.0.10](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.9...@antv/x6-sites-demos@1.0.10) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.5
* **@antv/x6-react-shape:** upgraded to 1.0.5

## @antv/x6-sites-demos [1.0.9](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.8...@antv/x6-sites-demos@1.0.9) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.4
* **@antv/x6-react-shape:** upgraded to 1.0.4

## @antv/x6-sites-demos [1.0.8](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.7...@antv/x6-sites-demos@1.0.8) (2020-11-20)





### Dependencies

* **@antv/x6:** upgraded to 1.0.3
* **@antv/x6-react-shape:** upgraded to 1.0.3

## @antv/x6-sites-demos [1.0.7](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.6...@antv/x6-sites-demos@1.0.7) (2020-11-20)





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 0.10.80

## @antv/x6-sites-demos [1.0.6](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.5...@antv/x6-sites-demos@1.0.6) (2020-11-19)





### Dependencies

* **@antv/x6:** upgraded to 1.0.2
* **@antv/x6-react-shape:** upgraded to 1.0.2

## @antv/x6-sites-demos [1.0.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.4...@antv/x6-sites-demos@1.0.5) (2020-11-19)





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 0.10.79

## @antv/x6-sites-demos [1.0.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.3...@antv/x6-sites-demos@1.0.4) (2020-11-19)


### Bug Fixes

* 🐛 checkView should return a boolean ([8c309a7](https://github.com/antvis/x6/commit/8c309a7b84276a722c25c319088e00822d1fc381))





### Dependencies

* **@antv/x6-sites-demos-helper:** upgraded to 0.10.78

## @antv/x6-sites-demos [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.2...@antv/x6-sites-demos@1.0.3) (2020-11-18)

## @antv/x6-sites-demos [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.1...@antv/x6-sites-demos@1.0.2) (2020-11-18)


### Bug Fixes

* 🐛 update intersectswith to intersectsWithRect ([fb0f144](https://github.com/antvis/x6/commit/fb0f144dc257a7a74ef5342f48359924c23b04a4))

## @antv/x6-sites-demos [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.0...@antv/x6-sites-demos@1.0.1) (2020-11-18)





### Dependencies

* **@antv/x6:** upgraded to 1.0.1
* **@antv/x6-react-shape:** upgraded to 1.0.1

## @antv/x6-sites-demos [0.10.97](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@0.10.96...@antv/x6-sites-demos@0.10.97) (2020-11-17)


### Bug Fixes

* 🐛 version error ([fd57688](https://github.com/antvis/x6/commit/fd5768861fedda32d341c774f6e80da67646426f))
* 🐛 version not found ([8166346](https://github.com/antvis/x6/commit/8166346771f11ef5997a6e1ed376987408e57cde))
* 🐛 x6 version ([f2e01c4](https://github.com/antvis/x6/commit/f2e01c44a1f1acd9390c9de0b5ade913cfd8b03b))
* 🐛 x6-react-shape version ([9426a89](https://github.com/antvis/x6/commit/9426a898003f041c22da55439f6b9715731f69f6))
* 🐛 x6-react-shape version ([482ce10](https://github.com/antvis/x6/commit/482ce10f1daeee1a154757c6009295d03363df56))





### Dependencies

* **@antv/x6:** upgraded to 0.13.7
* **@antv/x6-react-components:** upgraded to 0.10.20
* **@antv/x6-react-shape:** upgraded to 0.10.35

# @antv/x6-sites-demos [1.0.0-beta.5](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.0-beta.4...@antv/x6-sites-demos@1.0.0-beta.5) (2020-11-17)


### Bug Fixes

* 🐛 remove node from group ([f6326a0](https://github.com/antvis/x6/commit/f6326a0918e0c5181b63be0d6f10d47723e3aad2))





### Dependencies

* **@antv/x6:** upgraded to 1.0.0-beta.5
* **@antv/x6-react-components:** upgraded to 0.10.20-beta.1
* **@antv/x6-react-shape:** upgraded to 1.0.0-beta.5

# @antv/x6-sites-demos [1.0.0-beta.4](https://github.com/antvis/x6/compare/@antv/x6-sites-demos@1.0.0-beta.3...@antv/x6-sites-demos@1.0.0-beta.4) (2020-11-05)


### Bug Fixes

* 🐛 version error ([5c80d69](https://github.com/antvis/x6/commit/5c80d69f66217e131176fce89b95d30bd47e3c4c))





### Dependencies

* **@antv/x6:** upgraded to 1.0.0-beta.4
* **@antv/x6-react-shape:** upgraded to 1.0.0-beta.4
