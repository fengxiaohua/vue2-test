## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-31)





### Dependencies

* **@antv/x6:** upgraded to 1.26.1

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-24)





### Dependencies

* **@antv/x6:** upgraded to 1.26.0

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-18)

## @antv/x6-svg-to-shape [1.0.4](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.3...@antv/x6-svg-to-shape@1.0.4) (2021-08-18)





### Dependencies

* **@antv/x6:** upgraded to 1.25.5

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-17)





### Dependencies

* **@antv/x6:** upgraded to 1.25.4

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-16)

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-06)





### Dependencies

* **@antv/x6:** upgraded to 1.25.3

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-06)





### Dependencies

* **@antv/x6:** upgraded to 1.25.2

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-08-03)





### Dependencies

* **@antv/x6:** upgraded to 1.25.1

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-07-27)





### Dependencies

* **@antv/x6:** upgraded to 1.25.0

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-07-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.8

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.7

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.6

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-07-10)

## @antv/x6-svg-to-shape [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.2...@antv/x6-svg-to-shape@1.0.3) (2021-07-09)





### Dependencies

* **@antv/x6:** upgraded to 1.24.5

## @antv/x6-svg-to-shape [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.1...@antv/x6-svg-to-shape@1.0.2) (2021-07-05)

## @antv/x6-svg-to-shape [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.1...@antv/x6-svg-to-shape@1.0.2) (2021-06-23)

## @antv/x6-svg-to-shape [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.1...@antv/x6-svg-to-shape@1.0.2) (2021-06-23)





### Dependencies

* **@antv/x6:** upgraded to 1.24.4

## @antv/x6-svg-to-shape [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.1...@antv/x6-svg-to-shape@1.0.2) (2021-06-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.3

## @antv/x6-svg-to-shape [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.1...@antv/x6-svg-to-shape@1.0.2) (2021-06-21)

## @antv/x6-svg-to-shape [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.1...@antv/x6-svg-to-shape@1.0.2) (2021-06-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.2

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-21)

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.1

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-19)





### Dependencies

* **@antv/x6:** upgraded to 1.24.0

## @antv/x6-svg-to-shape [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.1...@antv/x6-svg-to-shape@1.0.2) (2021-06-19)





### Dependencies

* **@antv/x6:** upgraded to 1.23.13

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-18)

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-17)

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-17)





### Dependencies

* **@antv/x6:** upgraded to 1.23.12

# @antv/x6-svg-to-shape 1.0.0 (2021-06-17)


### Bug Fixes

* 🐛 alerts on lgtm.com ([#1104](https://github.com/antvis/x6/issues/1104)) ([6eb34b1](https://github.com/antvis/x6/commit/6eb34b1d9a25462593ba5e4a69995cca5211bc0c))
* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.11

# @antv/x6-svg-to-shape 1.0.0 (2021-06-16)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.10

# @antv/x6-svg-to-shape 1.0.0 (2021-06-15)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-06-15)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.9

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-13)





### Dependencies

* **@antv/x6:** upgraded to 1.23.8

# @antv/x6-svg-to-shape 1.0.0 (2021-06-11)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.7

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-06-09)





### Dependencies

* **@antv/x6:** upgraded to 1.23.6

# @antv/x6-svg-to-shape 1.0.0 (2021-06-09)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.5

# @antv/x6-svg-to-shape 1.0.0 (2021-06-09)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.4

# @antv/x6-svg-to-shape 1.0.0 (2021-06-07)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.3

# @antv/x6-svg-to-shape 1.0.0 (2021-06-07)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.2

# @antv/x6-svg-to-shape 1.0.0 (2021-06-02)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.1

# @antv/x6-svg-to-shape 1.0.0 (2021-06-02)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.23.0

# @antv/x6-svg-to-shape 1.0.0 (2021-06-01)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.22.1

# @antv/x6-svg-to-shape 1.0.0 (2021-05-31)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-05-31)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-05-31)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-05-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-05-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-05-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-05-27)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.22.0

# @antv/x6-svg-to-shape 1.0.0 (2021-05-18)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.21.7

# @antv/x6-svg-to-shape 1.0.0 (2021-05-18)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.21.6

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-05-14)





### Dependencies

* **@antv/x6:** upgraded to 1.21.5

# @antv/x6-svg-to-shape 1.0.0 (2021-05-12)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.21.4

# @antv/x6-svg-to-shape 1.0.0 (2021-05-08)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.21.3

# @antv/x6-svg-to-shape 1.0.0 (2021-05-07)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.21.2

# @antv/x6-svg-to-shape 1.0.0 (2021-05-07)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.21.1

# @antv/x6-svg-to-shape 1.0.0 (2021-05-06)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.21.0

# @antv/x6-svg-to-shape 1.0.0 (2021-05-04)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.20.0

# @antv/x6-svg-to-shape 1.0.0 (2021-05-01)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.19.6

# @antv/x6-svg-to-shape 1.0.0 (2021-05-01)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.19.5

# @antv/x6-svg-to-shape 1.0.0 (2021-04-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.19.4

# @antv/x6-svg-to-shape 1.0.0 (2021-04-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-04-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-04-28)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.19.3

# @antv/x6-svg-to-shape 1.0.0 (2021-04-28)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.19.2

# @antv/x6-svg-to-shape 1.0.0 (2021-04-28)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.19.1

# @antv/x6-svg-to-shape 1.0.0 (2021-04-26)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.19.0

# @antv/x6-svg-to-shape 1.0.0 (2021-04-21)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

## @antv/x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-svg-to-shape@1.0.0...@antv/x6-svg-to-shape@1.0.1) (2021-04-20)





### Dependencies

* **@antv/x6:** upgraded to 1.18.5

# @antv/x6-svg-to-shape 1.0.0 (2021-04-17)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.18.4

# @antv/x6-svg-to-shape 1.0.0 (2021-04-13)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.18.3

# @antv/x6-svg-to-shape 1.0.0 (2021-04-01)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.18.2

# @antv/x6-svg-to-shape 1.0.0 (2021-03-30)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.18.1

# @antv/x6-svg-to-shape 1.0.0 (2021-03-29)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-28)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-25)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-24)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-24)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-24)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-24)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-23)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-23)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.18.0

# @antv/x6-svg-to-shape 1.0.0 (2021-03-23)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# @antv/x6-svg-to-shape 1.0.0 (2021-03-23)


### Bug Fixes

* 🐛 fix package name ([1c034fe](https://github.com/antvis/x6/commit/1c034fe13ec2d0aed5cf24973370e0f3618ca697))
* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.7

# x6-svg-to-shape 1.0.0 (2021-03-20)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.6

# x6-svg-to-shape 1.0.0 (2021-03-19)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.5

# x6-svg-to-shape 1.0.0 (2021-03-19)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.4

# x6-svg-to-shape 1.0.0 (2021-03-16)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-15)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-15)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-12)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-12)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-12)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.3

# x6-svg-to-shape 1.0.0 (2021-03-12)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.2

# x6-svg-to-shape 1.0.0 (2021-03-11)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.1

# x6-svg-to-shape 1.0.0 (2021-03-11)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.17.0

## x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/x6-svg-to-shape@1.0.0...x6-svg-to-shape@1.0.1) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.16.0

# x6-svg-to-shape 1.0.0 (2021-03-10)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.15.0

## x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/x6-svg-to-shape@1.0.0...x6-svg-to-shape@1.0.1) (2021-03-10)





### Dependencies

* **@antv/x6:** upgraded to 1.14.0

# x6-svg-to-shape 1.0.0 (2021-03-07)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-04)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-03)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.13.4

# x6-svg-to-shape 1.0.0 (2021-03-02)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.13.3

# x6-svg-to-shape 1.0.0 (2021-03-02)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-03-02)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-02-23)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.13.1

# x6-svg-to-shape 1.0.0 (2021-02-23)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.13.0

# x6-svg-to-shape 1.0.0 (2021-02-22)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-02-20)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.32

# x6-svg-to-shape 1.0.0 (2021-02-09)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.31

# x6-svg-to-shape 1.0.0 (2021-02-07)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-02-07)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.30

# x6-svg-to-shape 1.0.0 (2021-02-05)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.29

# x6-svg-to-shape 1.0.0 (2021-02-05)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-02-04)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.28

# x6-svg-to-shape 1.0.0 (2021-02-03)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-02-03)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-02-03)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.27

# x6-svg-to-shape 1.0.0 (2021-02-02)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.26

# x6-svg-to-shape 1.0.0 (2021-02-02)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.25

# x6-svg-to-shape 1.0.0 (2021-02-02)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.24

# x6-svg-to-shape 1.0.0 (2021-02-02)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

## x6-svg-to-shape [1.0.1](https://github.com/antvis/x6/compare/x6-svg-to-shape@1.0.0...x6-svg-to-shape@1.0.1) (2021-02-01)





### Dependencies

* **@antv/x6:** upgraded to 1.12.23

# x6-svg-to-shape 1.0.0 (2021-02-01)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.22

# x6-svg-to-shape 1.0.0 (2021-02-01)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-01-31)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-01-31)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.21

# x6-svg-to-shape 1.0.0 (2021-01-30)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-01-30)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-01-30)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)

# x6-svg-to-shape 1.0.0 (2021-01-29)


### Bug Fixes

* change x6-svg-to-shape router ([3c5d11f](https://github.com/antvis/x6/commit/3c5d11f4b46d4843150ac3f294dc4ed0cf611c43))


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.20

# x6-svg-to-shape 1.0.0 (2021-01-28)


### Features

* ✨ add app to convert svg to render code ([bd76a91](https://github.com/antvis/x6/commit/bd76a91ed005acef1729ecb00933f3482ea9c567)), closes [#480](https://github.com/antvis/x6/issues/480)





### Dependencies

* **@antv/x6:** upgraded to 1.12.19
