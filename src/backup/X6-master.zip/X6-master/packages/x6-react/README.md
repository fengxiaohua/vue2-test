# @antv/x6-react

> Use X6 with react

## Installation

```shell
# npm
$ npm install @antv/x6-react --save

# yarn
$ yarn add @antv/x6-react
```

## Usage

```ts

```

