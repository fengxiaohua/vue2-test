import { ComponentType } from '@angular/cdk/portal';
import { Injector, TemplateRef } from '@angular/core';
import { Graph, Registry } from '@antv/x6';
export declare type Content = TemplateRef<any> | ComponentType<any>;
export declare type ContentArgs = {
    injector: Injector;
    content: Content;
};
export declare const registry: Registry.Registry<ContentArgs | ((this: Graph, node: Node) => ContentArgs), import("@antv/x6/lib/types").KeyValue<ContentArgs | ((this: Graph, node: Node) => ContentArgs)>, never>;
declare module '@antv/x6/lib/graph/graph' {
    namespace Graph {
        let registerAngularContent: typeof registry.register;
        let unregisterAngularContent: typeof registry.unregister;
    }
}
