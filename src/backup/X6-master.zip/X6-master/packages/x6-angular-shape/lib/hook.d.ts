import { Graph } from '@antv/x6';
import { ContentArgs } from './registry';
import { AngularShape } from './node';
declare module '@antv/x6/lib/graph/hook' {
    namespace Hook {
        interface IHook {
            getAngularContent(this: Graph, node: AngularShape): ContentArgs;
        }
    }
    interface Hook {
        getAngularContent(node: AngularShape): ContentArgs;
    }
}
