import { NodeView } from '@antv/x6';
import { AngularShape } from './node';
export declare class AngularShapeView extends NodeView<AngularShape> {
    protected init(): void;
    getContentContainer(): HTMLDivElement;
    confirmUpdate(flag: number): number;
    protected renderAngularContent(): void;
    protected unmountAngularContent(): HTMLDivElement;
    unmount(): this;
    dispose(): void;
}
export declare namespace AngularShapeView {
    const action: any;
}
