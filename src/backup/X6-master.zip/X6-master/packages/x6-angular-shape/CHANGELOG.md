# @antv/x6-angular-shape [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-angular-shape@1.0.0...@antv/x6-angular-shape@1.1.0) (2021-08-17)


### Features

* x6-angular-shape support pass arguments ([#1250](https://github.com/antvis/x6/issues/1250)) ([2a47d4a](https://github.com/antvis/x6/commit/2a47d4ad4ff313fc1e18e7327ba759ecf3f3867d))





### Dependencies

* **@antv/x6:** upgraded to 1.25.4

# @antv/x6-angular-shape [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-angular-shape@1.0.0...@antv/x6-angular-shape@1.1.0) (2021-08-16)


### Features

* x6-angular-shape support pass arguments ([#1250](https://github.com/antvis/x6/issues/1250)) ([2a47d4a](https://github.com/antvis/x6/commit/2a47d4ad4ff313fc1e18e7327ba759ecf3f3867d))

# @antv/x6-angular-shape 1.0.0 (2021-07-10)


### Bug Fixes

* fix angular typo ([#1154](https://github.com/antvis/x6/issues/1154)) ([a8533e9](https://github.com/antvis/x6/commit/a8533e9a04ea8e0188dafa6c172e44189ff84dea))


### Features

* add angualr shape ([#1141](https://github.com/antvis/x6/issues/1141)) ([698ecd7](https://github.com/antvis/x6/commit/698ecd75bd3a60ee6ebcd42129aa1a92b812fab2))

# @antv/x6-angular-shape 1.0.0 (2021-07-09)


### Bug Fixes

* fix angular typo ([#1154](https://github.com/antvis/x6/issues/1154)) ([a8533e9](https://github.com/antvis/x6/commit/a8533e9a04ea8e0188dafa6c172e44189ff84dea))


### Features

* add angualr shape ([#1141](https://github.com/antvis/x6/issues/1141)) ([698ecd7](https://github.com/antvis/x6/commit/698ecd75bd3a60ee6ebcd42129aa1a92b812fab2))





### Dependencies

* **@antv/x6:** upgraded to 1.24.5
