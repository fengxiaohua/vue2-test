# x6-vector

Lightweight library for manipulating and animating SVG.

<a href="/LICENSE"><img src="https://img.shields.io/github/license/antvis/x6?style=flat-square" alt="MIT License"></a>
<a href="https://www.typescriptlang.org"><img alt="Language" src="https://img.shields.io/badge/language-TypeScript-blue.svg?style=flat-square"></a>
<a href="https://github.com/antvis/x6/pulls"><img alt="PRs Welcome" src="https://img.shields.io/badge/PRs-Welcome-brightgreen.svg?style=flat-square"></a>
<a href="https://x6.antv.vision"><img alt="website" src="https://img.shields.io/static/v1?label=&labelColor=505050&message=website&color=0076D6&style=flat-square&logo=google-chrome&logoColor=0076D6"></a>
<a href="https://github.com/antvis/X6/actions/workflows/ci.yml"><img alt="build" src="https://img.shields.io/github/workflow/status/antvis/x6/%F0%9F%91%B7%E3%80%80CI/master?logo=github&style=flat-square"></a>
<a href="https://app.codecov.io/gh/antvis/x6"><img alt="coverage" src="https://img.shields.io/codecov/c/gh/antvis/x6?flag=x6-vector&logo=codecov&style=flat-square&token=15CO54WYUV"></a>
<a href="https://lgtm.com/projects/g/antvis/x6/context:javascript"><img alt="Language grade: JavaScript" src="https://img.shields.io/lgtm/grade/javascript/g/antvis/x6.svg?logo=lgtm&style=flat-square"></a>

<a href="https://www.npmjs.com/package/@antv/x6-vector"><img alt="NPM Package" src="https://img.shields.io/npm/v/@antv/x6-vector.svg?style=flat-square"></a>
<a href="https://www.npmjs.com/package/@antv/x6-vector"><img alt="NPM Downloads" src="https://img.shields.io/npm/dm/@antv/x6-vector?logo=npm&style=flat-square"></a>
<a href="https://david-dm.org/antvis/x6?path=packages/x6-vector"><img alt="Dependency Status" src="https://david-dm.org/antvis/x6.svg?style=flat-square&path=packages/x6-vector"></a>
<a href="https://david-dm.org/antvis/x6?type=dev&path=packages/x6-vector"><img alt="devDependencies Status" src="https://david-dm.org/antvis/x6/dev-status.svg?style=flat-square&path=packages/x6-vector" ></a>
