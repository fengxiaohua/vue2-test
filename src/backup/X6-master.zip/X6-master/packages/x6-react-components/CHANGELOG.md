## @antv/x6-react-components [1.1.13](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.12...@antv/x6-react-components@1.1.13) (2021-06-16)


### Bug Fixes

* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))

## @antv/x6-react-components [1.1.12](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.11...@antv/x6-react-components@1.1.12) (2021-06-11)

## @antv/x6-react-components [1.1.11](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.10...@antv/x6-react-components@1.1.11) (2021-06-09)

## @antv/x6-react-components [1.1.10](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.9...@antv/x6-react-components@1.1.10) (2021-05-30)


### Bug Fixes

* 🐛 fix x6-react-component release version ([508c959](https://github.com/antvis/x6/commit/508c9592e9c2dda5888713c5b69b470ac35697fa))

## @antv/x6-react-components [1.1.9](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.8...@antv/x6-react-components@1.1.9) (2021-04-01)


### Bug Fixes

* 🐛 fix x6-react-components rollup config ([66190e5](https://github.com/antvis/x6/commit/66190e5b980f6061d3219906e9dd200d20e61534))

## @antv/x6-react-components [1.1.8](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.7...@antv/x6-react-components@1.1.8) (2021-03-30)

## @antv/x6-react-components [1.1.7](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.6...@antv/x6-react-components@1.1.7) (2021-03-30)

## @antv/x6-react-components [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.5...@antv/x6-react-components@1.1.6) (2021-03-29)

## @antv/x6-react-components [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.4...@antv/x6-react-components@1.1.5) (2021-03-24)


### Bug Fixes

* 修复x6-react-component antd引入的问题 ([edf947d](https://github.com/antvis/x6/commit/edf947debc2d2ea22569a116c41c7af27d81d331))
* 修复x6-react-component antd引入的问题 ([b261160](https://github.com/antvis/x6/commit/b261160299a92a796cda8ca96710d7b3447aa815))

## @antv/x6-react-components [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.3...@antv/x6-react-components@1.1.4) (2021-03-24)


### Bug Fixes

* 🐛 release x6-react-components 1.1.3 ([e362ae2](https://github.com/antvis/x6/commit/e362ae273fce752f0ee18da604cd6d3723320feb))

## @antv/x6-react-components [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.2...@antv/x6-react-components@1.1.3) (2021-03-24)


### Bug Fixes

* 🐛 update .lock file ([5fe675c](https://github.com/antvis/x6/commit/5fe675cd1a68a8c50c1dc12fd22c8eb7c54e1e42))
* 🐛 update yarn.lock file ([22817d1](https://github.com/antvis/x6/commit/22817d1505e017b73fcc92896cd4032d42fe82b2))

## @antv/x6-react-components [1.1.2](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.1.1...@antv/x6-react-components@1.1.2) (2021-03-23)

## @antv/x6-react-components [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.0.2...@antv/x6-react-components@1.0.3) (2021-01-13)

## @antv/x6-react-components [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.0.1...@antv/x6-react-components@1.0.2) (2021-01-12)

## @antv/x6-react-components [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.0.0...@antv/x6-react-components@1.0.1) (2021-01-11)


### Bug Fixes

* 🐛 add x6-react-components umd build ([89421c8](https://github.com/antvis/x6/commit/89421c88afa141fe753cfca65a3c9132007057ce))
* 🐛 fast switch menubar-item lead to multiple popup ([#398](https://github.com/antvis/x6/issues/398)) ([8d4644f](https://github.com/antvis/x6/commit/8d4644f27c1f837a422703bcb1ef049c9c2794b8))

## @antv/x6-react-components [1.0.4](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.0.3...@antv/x6-react-components@1.0.4) (2020-12-28)


### Bug Fixes

* 🐛 add x6-react-components umd build ([89421c8](https://github.com/antvis/x6/commit/89421c88afa141fe753cfca65a3c9132007057ce))

## @antv/x6-react-components [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.0.2...@antv/x6-react-components@1.0.3) (2020-12-21)

## @antv/x6-react-components [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.0.1...@antv/x6-react-components@1.0.2) (2020-12-13)


### Bug Fixes

* 🐛 fast switch menubar-item lead to multiple popup ([#398](https://github.com/antvis/x6/issues/398)) ([8d4644f](https://github.com/antvis/x6/commit/8d4644f27c1f837a422703bcb1ef049c9c2794b8))

## @antv/x6-react-components [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-react-components@1.0.0...@antv/x6-react-components@1.0.1) (2020-12-07)

## @antv/x6-react-components [0.10.20](https://github.com/antvis/x6/compare/@antv/x6-react-components@0.10.19...@antv/x6-react-components@0.10.20) (2020-11-17)

## @antv/x6-react-components [0.10.20-beta.1](https://github.com/antvis/x6/compare/@antv/x6-react-components@0.10.19...@antv/x6-react-components@0.10.20-beta.1) (2020-11-17)

## @antv/x6-react-components [0.10.19](https://github.com/antvis/x6/compare/@antv/x6-react-components@0.10.18...@antv/x6-react-components@0.10.19) (2020-11-10)
