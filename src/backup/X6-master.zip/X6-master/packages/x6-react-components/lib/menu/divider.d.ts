import React from 'react';
export declare const MenuDivider: React.SFC;
