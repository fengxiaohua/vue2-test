import React from 'react';
import { MenuItem } from './item';
export declare const MenuSubMenu: React.SFC<MenuItem.Props>;
