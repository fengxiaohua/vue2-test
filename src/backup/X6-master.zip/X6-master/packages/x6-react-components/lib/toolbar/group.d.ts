import React from 'react';
export declare const ToolbarGroup: React.SFC<ToolbarGroup.Props>;
export declare namespace ToolbarGroup {
    interface Props {
        className?: string;
    }
}
