/* eslint-disable */

/**
 * Auto generated version file, do not modify it!
 */
const version = '1.0.8'
export { version }
