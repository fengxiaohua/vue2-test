## @antv/x6-geometry [1.0.8](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.7...@antv/x6-geometry@1.0.8) (2021-07-10)

## @antv/x6-geometry [1.0.7](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.6...@antv/x6-geometry@1.0.7) (2021-07-05)

## @antv/x6-geometry [1.0.6](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.5...@antv/x6-geometry@1.0.6) (2021-06-17)


### Bug Fixes

* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))

## @antv/x6-geometry [1.0.6](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.5...@antv/x6-geometry@1.0.6) (2021-06-16)


### Bug Fixes

* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))

## @antv/x6-geometry [1.0.5](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.4...@antv/x6-geometry@1.0.5) (2021-06-15)

## @antv/x6-geometry [1.0.5](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.4...@antv/x6-geometry@1.0.5) (2021-06-11)

## @antv/x6-geometry [1.0.4](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.3...@antv/x6-geometry@1.0.4) (2021-06-09)

## @antv/x6-geometry [1.0.4](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.3...@antv/x6-geometry@1.0.4) (2021-06-09)

## @antv/x6-geometry [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.2...@antv/x6-geometry@1.0.3) (2021-04-01)

## @antv/x6-geometry [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.2...@antv/x6-geometry@1.0.3) (2021-03-30)

## @antv/x6-geometry [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.1...@antv/x6-geometry@1.0.2) (2021-03-30)

## @antv/x6-geometry [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.1...@antv/x6-geometry@1.0.2) (2021-03-30)

## @antv/x6-geometry [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.0...@antv/x6-geometry@1.0.1) (2021-03-28)

## @antv/x6-geometry [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-geometry@1.0.0...@antv/x6-geometry@1.0.1) (2021-03-25)

# @antv/x6-geometry 1.0.0 (2021-03-24)


### Features

* ✨ add geometry library ([6502513](https://github.com/antvis/x6/commit/650251331c07de39da94b1058239d044f02c8aba))
* add some getters ([ff0273d](https://github.com/antvis/x6/commit/ff0273d119afd74b7233649308ba0035c737ca1a))
* equalPoints ([6a45c90](https://github.com/antvis/x6/commit/6a45c9027ab869a05c2f561cb7503078b0117264))
* rotate rectangle ([88a4fec](https://github.com/antvis/x6/commit/88a4fec7d1d3a49b6c1373f0641c8949474d7d83))
* round with default precision ([aef56f7](https://github.com/antvis/x6/commit/aef56f73f0627d620d36d116b74c828fa76c13f2))

# @antv/x6-geometry 1.0.0 (2021-03-23)


### Features

* ✨ add geometry library ([6502513](https://github.com/antvis/x6/commit/650251331c07de39da94b1058239d044f02c8aba))
* add some getters ([ff0273d](https://github.com/antvis/x6/commit/ff0273d119afd74b7233649308ba0035c737ca1a))
* equalPoints ([6a45c90](https://github.com/antvis/x6/commit/6a45c9027ab869a05c2f561cb7503078b0117264))
* rotate rectangle ([88a4fec](https://github.com/antvis/x6/commit/88a4fec7d1d3a49b6c1373f0641c8949474d7d83))
* round with default precision ([aef56f7](https://github.com/antvis/x6/commit/aef56f73f0627d620d36d116b74c828fa76c13f2))

# @antv/x6-geometry 1.0.0 (2021-03-23)


### Features

* ✨ add geometry library ([6502513](https://github.com/antvis/x6/commit/650251331c07de39da94b1058239d044f02c8aba))
* add some getters ([ff0273d](https://github.com/antvis/x6/commit/ff0273d119afd74b7233649308ba0035c737ca1a))
* equalPoints ([6a45c90](https://github.com/antvis/x6/commit/6a45c9027ab869a05c2f561cb7503078b0117264))
* rotate rectangle ([88a4fec](https://github.com/antvis/x6/commit/88a4fec7d1d3a49b6c1373f0641c8949474d7d83))
* round with default precision ([aef56f7](https://github.com/antvis/x6/commit/aef56f73f0627d620d36d116b74c828fa76c13f2))

# @antv/x6-geometry 1.0.0 (2021-03-23)


### Features

* ✨ add geometry library ([6502513](https://github.com/antvis/x6/commit/650251331c07de39da94b1058239d044f02c8aba))
* add some getters ([ff0273d](https://github.com/antvis/x6/commit/ff0273d119afd74b7233649308ba0035c737ca1a))
* equalPoints ([6a45c90](https://github.com/antvis/x6/commit/6a45c9027ab869a05c2f561cb7503078b0117264))
* rotate rectangle ([88a4fec](https://github.com/antvis/x6/commit/88a4fec7d1d3a49b6c1373f0641c8949474d7d83))
* round with default precision ([aef56f7](https://github.com/antvis/x6/commit/aef56f73f0627d620d36d116b74c828fa76c13f2))

# @antv/x6-geometry 1.0.0 (2021-03-23)


### Features

* ✨ add geometry library ([6502513](https://github.com/antvis/x6/commit/650251331c07de39da94b1058239d044f02c8aba))
* add some getters ([ff0273d](https://github.com/antvis/x6/commit/ff0273d119afd74b7233649308ba0035c737ca1a))
* equalPoints ([6a45c90](https://github.com/antvis/x6/commit/6a45c9027ab869a05c2f561cb7503078b0117264))
* rotate rectangle ([88a4fec](https://github.com/antvis/x6/commit/88a4fec7d1d3a49b6c1373f0641c8949474d7d83))
* round with default precision ([aef56f7](https://github.com/antvis/x6/commit/aef56f73f0627d620d36d116b74c828fa76c13f2))
