/**
 * Auto generated version file, do not modify it!
 */
declare const version = "1.0.8";
export { version };
