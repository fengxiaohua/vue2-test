import * as BasicShape from './basic';
import * as Shape from './standard';
export { BasicShape, Shape };
