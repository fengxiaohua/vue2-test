---
name: 💡 Feature request
about: Suggest an idea for this project
title: ''
labels: 'enhancement'
assignees: ''
---

<!--- Provide a general summary of the feature in the Title above. -->

### Expected Behavior

<!--- What should happen. -->

### Possible Solution

<!--- Any solutions you've considered. -->

### Additional Context

<!--- How has this issue affected you? -->
<!--- What are you trying to accomplish? -->
<!--- Provide screenshots if possible. -->

<!--- Providing context helps us come up with a -->
<!--- solution that is most useful in the real world. -->
