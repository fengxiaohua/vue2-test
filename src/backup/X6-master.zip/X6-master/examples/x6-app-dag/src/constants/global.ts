export const ANT_PREFIX = 'ant'
