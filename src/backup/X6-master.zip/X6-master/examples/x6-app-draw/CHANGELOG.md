## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-31)





### Dependencies

* **@antv/x6:** upgraded to 1.26.1

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-24)





### Dependencies

* **@antv/x6:** upgraded to 1.26.0

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-18)

## @antv/x6-app-draw [1.1.7](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.6...@antv/x6-app-draw@1.1.7) (2021-08-18)





### Dependencies

* **@antv/x6:** upgraded to 1.25.5

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-17)





### Dependencies

* **@antv/x6:** upgraded to 1.25.4

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-16)

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-06)





### Dependencies

* **@antv/x6:** upgraded to 1.25.3

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-06)





### Dependencies

* **@antv/x6:** upgraded to 1.25.2

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-08-03)





### Dependencies

* **@antv/x6:** upgraded to 1.25.1

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-07-27)





### Dependencies

* **@antv/x6:** upgraded to 1.25.0

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-07-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.8

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.7

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.6

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-07-10)

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-07-09)





### Dependencies

* **@antv/x6:** upgraded to 1.24.5

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-07-05)

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-06-23)

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-06-23)





### Dependencies

* **@antv/x6:** upgraded to 1.24.4

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-06-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.3

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-06-21)

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-06-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.2

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-21)


### Bug Fixes

* optimize flow chart demo ([#1110](https://github.com/antvis/x6/issues/1110)) ([c6093c4](https://github.com/antvis/x6/commit/c6093c40b150720e8b67e4eac8badd3c90ec2490))

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-21)


### Bug Fixes

* optimize flow chart demo ([#1110](https://github.com/antvis/x6/issues/1110)) ([c6093c4](https://github.com/antvis/x6/commit/c6093c40b150720e8b67e4eac8badd3c90ec2490))





### Dependencies

* **@antv/x6:** upgraded to 1.24.1

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-19)


### Bug Fixes

* optimize flow chart demo ([#1110](https://github.com/antvis/x6/issues/1110)) ([c6093c4](https://github.com/antvis/x6/commit/c6093c40b150720e8b67e4eac8badd3c90ec2490))





### Dependencies

* **@antv/x6:** upgraded to 1.24.0

## @antv/x6-app-draw [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.5...@antv/x6-app-draw@1.1.6) (2021-06-19)





### Dependencies

* **@antv/x6:** upgraded to 1.23.13

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-18)


### Bug Fixes

* optimize flow chart demo ([#1110](https://github.com/antvis/x6/issues/1110)) ([c6093c4](https://github.com/antvis/x6/commit/c6093c40b150720e8b67e4eac8badd3c90ec2490))

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-17)

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-17)





### Dependencies

* **@antv/x6:** upgraded to 1.23.12

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-17)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.11

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-16)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.10
* **@antv/x6-react-components:** upgraded to 1.1.13

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-15)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-15)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.9

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-13)





### Dependencies

* **@antv/x6:** upgraded to 1.23.8

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-11)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.7
* **@antv/x6-react-components:** upgraded to 1.1.12

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-06-09)





### Dependencies

* **@antv/x6:** upgraded to 1.23.6

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-09)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.5

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-09)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.4
* **@antv/x6-react-components:** upgraded to 1.1.11

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.3

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.2

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-02)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.1

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-02)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.23.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-06-01)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.22.1

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-31)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-31)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-31)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.10

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-27)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.22.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-18)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.21.7

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-18)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.21.6

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-05-14)





### Dependencies

* **@antv/x6:** upgraded to 1.21.5

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-12)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.21.4

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-08)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.21.3

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.21.2

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.21.1

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-06)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.21.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-04)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.20.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-01)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.19.6

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-05-01)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.19.5

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))
* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.19.4

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-30)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-30)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-28)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.19.3

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-28)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.19.2

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-28)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.19.1

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-26)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.19.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-21)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-04-20)





### Dependencies

* **@antv/x6:** upgraded to 1.18.5

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-17)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.18.4

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-13)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.18.3

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-04-01)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.9

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-30)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.18.2
* **@antv/x6-react-components:** upgraded to 1.1.8

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-30)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6:** upgraded to 1.18.1
* **@antv/x6-react-components:** upgraded to 1.1.7

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-29)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.6

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-28)


### Bug Fixes

* 🐛 x6-app-draw支持windows下ctrl组合快捷键 ([0253aaf](https://github.com/antvis/x6/commit/0253aaf7efc6a38739181f4d6315de73447e2017))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-25)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-24)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.5

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-24)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-24)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.4

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-24)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.3

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-23)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-23)





### Dependencies

* **@antv/x6:** upgraded to 1.18.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-23)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-23)





### Dependencies

* **@antv/x6:** upgraded to 1.17.7
* **@antv/x6-react-components:** upgraded to 1.1.2

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-20)





### Dependencies

* **@antv/x6:** upgraded to 1.17.6

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-19)





### Dependencies

* **@antv/x6:** upgraded to 1.17.5

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-19)





### Dependencies

* **@antv/x6:** upgraded to 1.17.4

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-16)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-15)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-15)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-12)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-12)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-12)





### Dependencies

* **@antv/x6:** upgraded to 1.17.3

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-12)





### Dependencies

* **@antv/x6:** upgraded to 1.17.2

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.17.1

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.17.0

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.16.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-10)





### Dependencies

* **@antv/x6:** upgraded to 1.15.0

## @antv/x6-app-draw [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.4...@antv/x6-app-draw@1.1.5) (2021-03-10)





### Dependencies

* **@antv/x6:** upgraded to 1.14.0

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-07)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-04)

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-03)





### Dependencies

* **@antv/x6:** upgraded to 1.13.4

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-03-02)





### Dependencies

* **@antv/x6:** upgraded to 1.13.3

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-03-02)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.13.2

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-23)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.13.1

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-23)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.13.0

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-22)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-20)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.32

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-09)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.31

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-07)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-07)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.30

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-05)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.29

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-05)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-04)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* fix text not wrap error ([f404a9a](https://github.com/antvis/x6/commit/f404a9a36ff08084f026cce76c3710d0183730ab))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.28

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-03)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* editableNode bugs of x6-app-draw ([4d33512](https://github.com/antvis/x6/commit/4d3351207736009cf5ee1ab7eee5991cc1ad2f84))
* editableNode bugs of x6-app-draw ([15589f5](https://github.com/antvis/x6/commit/15589f5bae3c0e304a5a2efa0f17514bc63f8f4b))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-03)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-03)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.27

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-02)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.26

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-02)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.25

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-02)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.24

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-02)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-02-01)





### Dependencies

* **@antv/x6:** upgraded to 1.12.23

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-01)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.22

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-02-01)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-31)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-31)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.21

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-30)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-30)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-30)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-29)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.20

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-28)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.19

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-27)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.18

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-26)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-26)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.17

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-01-25)





### Dependencies

* **@antv/x6:** upgraded to 1.12.16

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-25)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.15

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-25)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-24)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.14

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-01-23)





### Dependencies

* **@antv/x6:** upgraded to 1.12.13

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-23)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.12

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-22)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.11

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-22)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-22)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.10

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-22)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.9

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-21)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.8

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-21)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.3...@antv/x6-app-draw@1.1.4) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.7

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-21)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.6

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-21)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.5

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-20)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.4

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-20)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.3

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-20)


### Bug Fixes

* change $ to JQuery ([3c4d229](https://github.com/antvis/x6/commit/3c4d22952b33d592791cdead017d860833f51608))
* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.2

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-19)


### Bug Fixes

* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-19)


### Bug Fixes

* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-18)


### Bug Fixes

* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-15)


### Bug Fixes

* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-14)


### Bug Fixes

* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))





### Dependencies

* **@antv/x6:** upgraded to 1.12.1

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-13)


### Bug Fixes

* port can connect multiple lines ([908bff2](https://github.com/antvis/x6/commit/908bff246c2b518a89dc7d4cc6d53fea3e447ac9))

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.12.0

## @antv/x6-app-draw [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.1.2...@antv/x6-app-draw@1.1.3) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.11.6

## @antv/x6-app-draw [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.1...@antv/x6-app-draw@1.0.2) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.8.3
* **@antv/x6-react-components:** upgraded to 1.0.3

## @antv/x6-app-draw [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.0...@antv/x6-app-draw@1.0.1) (2021-01-12)


### Bug Fixes

* 🐛 add deps for x6-app-draw ([850192e](https://github.com/antvis/x6/commit/850192ef1424a0b26dd39f547896a8352046edad))
* 🐛 add design for demos ([6e849bc](https://github.com/antvis/x6/commit/6e849bc80fe1bc242a2efa7282a425c0835619fb))
* 🐛 add selecting for draw demo ([4f95511](https://github.com/antvis/x6/commit/4f95511639da853c0bf4f1f580bf6bdaea2fb28b))
* 🐛 add unregister for react/vue shape ([5937a01](https://github.com/antvis/x6/commit/5937a01ee7ebb85b1dd313510d5b9fa88c8c5f32))
* 🐛 change style of draw graph ([c69c3fe](https://github.com/antvis/x6/commit/c69c3fe21aa8ad573a78858818decfa0750bb456))
* 🐛 fix stylelint error ([55fd1eb](https://github.com/antvis/x6/commit/55fd1eb533e99f8dc52bb42dba139ef4375cc57b))
* 🐛 update yarn.lock ([14a1ee5](https://github.com/antvis/x6/commit/14a1ee5d7dd01d4235fbc34001219bba51b18c79))
* fix group could not be deleted ([b9e1020](https://github.com/antvis/x6/commit/b9e10200c48478a589439bb142f15b9a418e7dad))
* fix redo exception on group in demo ([1c893b0](https://github.com/antvis/x6/commit/1c893b0493f80e798173d98b461fa38458f9e07a))
* fix selection box style ([9090868](https://github.com/antvis/x6/commit/9090868fcbf9414b82e6b01faa70a4b98d160605))





### Dependencies

* **@antv/x6:** upgraded to 1.8.2
* **@antv/x6-react-components:** upgraded to 1.0.2

## @antv/x6-app-draw [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.1...@antv/x6-app-draw@1.0.2) (2021-01-12)





### Dependencies

* **@antv/x6:** upgraded to 1.8.1

## @antv/x6-app-draw [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.0...@antv/x6-app-draw@1.0.1) (2021-01-11)


### Bug Fixes

* 🐛 add deps for x6-app-draw ([850192e](https://github.com/antvis/x6/commit/850192ef1424a0b26dd39f547896a8352046edad))
* 🐛 add design for demos ([6e849bc](https://github.com/antvis/x6/commit/6e849bc80fe1bc242a2efa7282a425c0835619fb))
* 🐛 add selecting for draw demo ([4f95511](https://github.com/antvis/x6/commit/4f95511639da853c0bf4f1f580bf6bdaea2fb28b))
* 🐛 add unregister for react/vue shape ([5937a01](https://github.com/antvis/x6/commit/5937a01ee7ebb85b1dd313510d5b9fa88c8c5f32))
* 🐛 change style of draw graph ([c69c3fe](https://github.com/antvis/x6/commit/c69c3fe21aa8ad573a78858818decfa0750bb456))
* 🐛 fix stylelint error ([55fd1eb](https://github.com/antvis/x6/commit/55fd1eb533e99f8dc52bb42dba139ef4375cc57b))
* 🐛 update yarn.lock ([14a1ee5](https://github.com/antvis/x6/commit/14a1ee5d7dd01d4235fbc34001219bba51b18c79))
* fix group could not be deleted ([b9e1020](https://github.com/antvis/x6/commit/b9e10200c48478a589439bb142f15b9a418e7dad))
* fix redo exception on group in demo ([1c893b0](https://github.com/antvis/x6/commit/1c893b0493f80e798173d98b461fa38458f9e07a))
* fix selection box style ([9090868](https://github.com/antvis/x6/commit/9090868fcbf9414b82e6b01faa70a4b98d160605))





### Dependencies

* **@antv/x6:** upgraded to 1.8.0
* **@antv/x6-react-components:** upgraded to 1.0.1

## @antv/x6-app-draw [1.0.88](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.87...@antv/x6-app-draw@1.0.88) (2021-01-11)





### Dependencies

* **@antv/x6:** upgraded to 1.11.2

## @antv/x6-app-draw [1.0.87](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.86...@antv/x6-app-draw@1.0.87) (2021-01-11)





### Dependencies

* **@antv/x6:** upgraded to 1.11.1

## @antv/x6-app-draw [1.0.86](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.85...@antv/x6-app-draw@1.0.86) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.11.0

## @antv/x6-app-draw [1.0.85](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.84...@antv/x6-app-draw@1.0.85) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.2

## @antv/x6-app-draw [1.0.84](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.83...@antv/x6-app-draw@1.0.84) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.1

## @antv/x6-app-draw [1.0.83](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.82...@antv/x6-app-draw@1.0.83) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.0

## @antv/x6-app-draw [1.0.82](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.81...@antv/x6-app-draw@1.0.82) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.3

## @antv/x6-app-draw [1.0.81](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.80...@antv/x6-app-draw@1.0.81) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.2

## @antv/x6-app-draw [1.0.80](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.79...@antv/x6-app-draw@1.0.80) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.1

## @antv/x6-app-draw [1.0.79](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.78...@antv/x6-app-draw@1.0.79) (2021-01-04)





### Dependencies

* **@antv/x6:** upgraded to 1.9.0

## @antv/x6-app-draw [1.0.78](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.77...@antv/x6-app-draw@1.0.78) (2021-01-04)





### Dependencies

* **@antv/x6:** upgraded to 1.8.0

## @antv/x6-app-draw [1.0.77](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.76...@antv/x6-app-draw@1.0.77) (2021-01-04)


### Bug Fixes

* 🐛 add unregister for react/vue shape ([5937a01](https://github.com/antvis/x6/commit/5937a01ee7ebb85b1dd313510d5b9fa88c8c5f32))

## @antv/x6-app-draw [1.0.76](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.75...@antv/x6-app-draw@1.0.76) (2020-12-31)





### Dependencies

* **@antv/x6:** upgraded to 1.7.12

## @antv/x6-app-draw [1.0.75](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.74...@antv/x6-app-draw@1.0.75) (2020-12-30)





### Dependencies

* **@antv/x6:** upgraded to 1.7.11

## @antv/x6-app-draw [1.0.74](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.73...@antv/x6-app-draw@1.0.74) (2020-12-29)





### Dependencies

* **@antv/x6:** upgraded to 1.7.10

## @antv/x6-app-draw [1.0.73](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.72...@antv/x6-app-draw@1.0.73) (2020-12-29)





### Dependencies

* **@antv/x6:** upgraded to 1.7.9

## @antv/x6-app-draw [1.0.72](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.71...@antv/x6-app-draw@1.0.72) (2020-12-28)





### Dependencies

* **@antv/x6:** upgraded to 1.7.8

## @antv/x6-app-draw [1.0.71](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.70...@antv/x6-app-draw@1.0.71) (2020-12-28)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.0.4

## @antv/x6-app-draw [1.0.70](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.69...@antv/x6-app-draw@1.0.70) (2020-12-26)





### Dependencies

* **@antv/x6:** upgraded to 1.7.7

## @antv/x6-app-draw [1.0.69](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.68...@antv/x6-app-draw@1.0.69) (2020-12-25)





### Dependencies

* **@antv/x6:** upgraded to 1.7.6

## @antv/x6-app-draw [1.0.68](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.67...@antv/x6-app-draw@1.0.68) (2020-12-25)





### Dependencies

* **@antv/x6:** upgraded to 1.7.5

## @antv/x6-app-draw [1.0.67](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.66...@antv/x6-app-draw@1.0.67) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.4

## @antv/x6-app-draw [1.0.66](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.65...@antv/x6-app-draw@1.0.66) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.3

## @antv/x6-app-draw [1.0.65](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.64...@antv/x6-app-draw@1.0.65) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.2

## @antv/x6-app-draw [1.0.64](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.63...@antv/x6-app-draw@1.0.64) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.1

## @antv/x6-app-draw [1.0.63](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.62...@antv/x6-app-draw@1.0.63) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.0

## @antv/x6-app-draw [1.0.62](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.61...@antv/x6-app-draw@1.0.62) (2020-12-23)





### Dependencies

* **@antv/x6:** upgraded to 1.6.4

## @antv/x6-app-draw [1.0.61](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.60...@antv/x6-app-draw@1.0.61) (2020-12-22)





### Dependencies

* **@antv/x6:** upgraded to 1.6.3

## @antv/x6-app-draw [1.0.60](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.59...@antv/x6-app-draw@1.0.60) (2020-12-22)





### Dependencies

* **@antv/x6:** upgraded to 1.6.2

## @antv/x6-app-draw [1.0.59](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.58...@antv/x6-app-draw@1.0.59) (2020-12-21)





### Dependencies

* **@antv/x6:** upgraded to 1.6.1
* **@antv/x6-react-components:** upgraded to 1.0.3

## @antv/x6-app-draw [1.0.58](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.57...@antv/x6-app-draw@1.0.58) (2020-12-21)





### Dependencies

* **@antv/x6:** upgraded to 1.6.0

## @antv/x6-app-draw [1.0.57](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.56...@antv/x6-app-draw@1.0.57) (2020-12-21)


### Bug Fixes

* fix redo exception on group in demo ([1c893b0](https://github.com/antvis/x6/commit/1c893b0493f80e798173d98b461fa38458f9e07a))
* fix selection box style ([9090868](https://github.com/antvis/x6/commit/9090868fcbf9414b82e6b01faa70a4b98d160605))

## @antv/x6-app-draw [1.0.56](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.55...@antv/x6-app-draw@1.0.56) (2020-12-19)


### Bug Fixes

* fix group could not be deleted ([b9e1020](https://github.com/antvis/x6/commit/b9e10200c48478a589439bb142f15b9a418e7dad))

## @antv/x6-app-draw [1.0.55](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.54...@antv/x6-app-draw@1.0.55) (2020-12-18)





### Dependencies

* **@antv/x6:** upgraded to 1.5.2

## @antv/x6-app-draw [1.0.54](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.53...@antv/x6-app-draw@1.0.54) (2020-12-17)





### Dependencies

* **@antv/x6:** upgraded to 1.5.1

## @antv/x6-app-draw [1.0.53](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.52...@antv/x6-app-draw@1.0.53) (2020-12-17)





### Dependencies

* **@antv/x6:** upgraded to 1.5.0

## @antv/x6-app-draw [1.0.52](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.51...@antv/x6-app-draw@1.0.52) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.2

## @antv/x6-app-draw [1.0.51](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.50...@antv/x6-app-draw@1.0.51) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.1

## @antv/x6-app-draw [1.0.50](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.49...@antv/x6-app-draw@1.0.50) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.0

## @antv/x6-app-draw [1.0.49](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.48...@antv/x6-app-draw@1.0.49) (2020-12-13)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.0.2

## @antv/x6-app-draw [1.0.48](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.47...@antv/x6-app-draw@1.0.48) (2020-12-12)





### Dependencies

* **@antv/x6:** upgraded to 1.3.20

## @antv/x6-app-draw [1.0.47](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.46...@antv/x6-app-draw@1.0.47) (2020-12-11)





### Dependencies

* **@antv/x6:** upgraded to 1.3.19

## @antv/x6-app-draw [1.0.46](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.45...@antv/x6-app-draw@1.0.46) (2020-12-11)





### Dependencies

* **@antv/x6:** upgraded to 1.3.18

## @antv/x6-app-draw [1.0.45](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.44...@antv/x6-app-draw@1.0.45) (2020-12-11)

## @antv/x6-app-draw [1.0.44](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.43...@antv/x6-app-draw@1.0.44) (2020-12-10)





### Dependencies

* **@antv/x6:** upgraded to 1.3.17

## @antv/x6-app-draw [1.0.43](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.42...@antv/x6-app-draw@1.0.43) (2020-12-10)





### Dependencies

* **@antv/x6:** upgraded to 1.3.16

## @antv/x6-app-draw [1.0.42](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.41...@antv/x6-app-draw@1.0.42) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.15

## @antv/x6-app-draw [1.0.41](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.40...@antv/x6-app-draw@1.0.41) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.14

## @antv/x6-app-draw [1.0.40](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.39...@antv/x6-app-draw@1.0.40) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.13

## @antv/x6-app-draw [1.0.39](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.38...@antv/x6-app-draw@1.0.39) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.12

## @antv/x6-app-draw [1.0.38](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.37...@antv/x6-app-draw@1.0.38) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.11

## @antv/x6-app-draw [1.0.37](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.36...@antv/x6-app-draw@1.0.37) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.10

## @antv/x6-app-draw [1.0.36](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.35...@antv/x6-app-draw@1.0.36) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.9

## @antv/x6-app-draw [1.0.35](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.34...@antv/x6-app-draw@1.0.35) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.8

## @antv/x6-app-draw [1.0.34](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.33...@antv/x6-app-draw@1.0.34) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.7

## @antv/x6-app-draw [1.0.33](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.32...@antv/x6-app-draw@1.0.33) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.6

## @antv/x6-app-draw [1.0.32](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.31...@antv/x6-app-draw@1.0.32) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.5

## @antv/x6-app-draw [1.0.31](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.30...@antv/x6-app-draw@1.0.31) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.4
* **@antv/x6-react-components:** upgraded to 1.0.1

## @antv/x6-app-draw [1.0.30](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.29...@antv/x6-app-draw@1.0.30) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.3

## @antv/x6-app-draw [1.0.29](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.28...@antv/x6-app-draw@1.0.29) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.2

## @antv/x6-app-draw [1.0.28](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.27...@antv/x6-app-draw@1.0.28) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.1

## @antv/x6-app-draw [1.0.27](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.26...@antv/x6-app-draw@1.0.27) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.0

## @antv/x6-app-draw [1.0.26](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.25...@antv/x6-app-draw@1.0.26) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.3

## @antv/x6-app-draw [1.0.25](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.24...@antv/x6-app-draw@1.0.25) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.2

## @antv/x6-app-draw [1.0.24](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.23...@antv/x6-app-draw@1.0.24) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.1

## @antv/x6-app-draw [1.0.23](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.22...@antv/x6-app-draw@1.0.23) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.2.0

## @antv/x6-app-draw [1.0.22](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.21...@antv/x6-app-draw@1.0.22) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.1.3

## @antv/x6-app-draw [1.0.21](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.20...@antv/x6-app-draw@1.0.21) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.1.2

## @antv/x6-app-draw [1.0.20](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.19...@antv/x6-app-draw@1.0.20) (2020-11-30)





### Dependencies

* **@antv/x6:** upgraded to 1.1.1

## @antv/x6-app-draw [1.0.19](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.18...@antv/x6-app-draw@1.0.19) (2020-11-27)





### Dependencies

* **@antv/x6:** upgraded to 1.1.0

## @antv/x6-app-draw [1.0.18](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.17...@antv/x6-app-draw@1.0.18) (2020-11-27)


### Bug Fixes

* 🐛 add deps for x6-app-draw ([850192e](https://github.com/antvis/x6/commit/850192ef1424a0b26dd39f547896a8352046edad))

## @antv/x6-app-draw [1.0.17](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.16...@antv/x6-app-draw@1.0.17) (2020-11-27)





### Dependencies

* **@antv/x6:** upgraded to 1.0.9

## @antv/x6-app-draw [1.0.16](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.15...@antv/x6-app-draw@1.0.16) (2020-11-25)





### Dependencies

* **@antv/x6:** upgraded to 1.0.8

## @antv/x6-app-draw [1.0.15](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.14...@antv/x6-app-draw@1.0.15) (2020-11-25)





### Dependencies

* **@antv/x6:** upgraded to 1.0.7

## @antv/x6-app-draw [1.0.14](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.13...@antv/x6-app-draw@1.0.14) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.6

## @antv/x6-app-draw [1.0.13](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.12...@antv/x6-app-draw@1.0.13) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.5

## @antv/x6-app-draw [1.0.12](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.11...@antv/x6-app-draw@1.0.12) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.4

## @antv/x6-app-draw [1.0.11](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.10...@antv/x6-app-draw@1.0.11) (2020-11-21)


### Bug Fixes

* 🐛 update yarn.lock ([14a1ee5](https://github.com/antvis/x6/commit/14a1ee5d7dd01d4235fbc34001219bba51b18c79))

## @antv/x6-app-draw [1.0.10](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.9...@antv/x6-app-draw@1.0.10) (2020-11-20)


### Bug Fixes

* 🐛 add design for demos ([6e849bc](https://github.com/antvis/x6/commit/6e849bc80fe1bc242a2efa7282a425c0835619fb))

## @antv/x6-app-draw [1.0.9](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.8...@antv/x6-app-draw@1.0.9) (2020-11-20)





### Dependencies

* **@antv/x6:** upgraded to 1.0.3

## @antv/x6-app-draw [1.0.8](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.7...@antv/x6-app-draw@1.0.8) (2020-11-20)


### Bug Fixes

* 🐛 change style of draw graph ([c69c3fe](https://github.com/antvis/x6/commit/c69c3fe21aa8ad573a78858818decfa0750bb456))

## @antv/x6-app-draw [1.0.7](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.6...@antv/x6-app-draw@1.0.7) (2020-11-19)





### Dependencies

* **@antv/x6:** upgraded to 1.0.2

## @antv/x6-app-draw [1.0.6](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.5...@antv/x6-app-draw@1.0.6) (2020-11-19)

## @antv/x6-app-draw [1.0.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.4...@antv/x6-app-draw@1.0.5) (2020-11-19)

## @antv/x6-app-draw [1.0.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.3...@antv/x6-app-draw@1.0.4) (2020-11-19)

## @antv/x6-app-draw [1.0.3](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.2...@antv/x6-app-draw@1.0.3) (2020-11-18)

## @antv/x6-app-draw [1.0.2](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.1...@antv/x6-app-draw@1.0.2) (2020-11-18)


### Bug Fixes

* 🐛 add selecting for draw demo ([4f95511](https://github.com/antvis/x6/commit/4f95511639da853c0bf4f1f580bf6bdaea2fb28b))
* 🐛 fix stylelint error ([55fd1eb](https://github.com/antvis/x6/commit/55fd1eb533e99f8dc52bb42dba139ef4375cc57b))

## @antv/x6-app-draw [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.0...@antv/x6-app-draw@1.0.1) (2020-11-18)





### Dependencies

* **@antv/x6:** upgraded to 1.0.1

## @antv/x6-app-draw [0.10.98](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.97...@antv/x6-app-draw@0.10.98) (2020-11-17)


### Bug Fixes

* 🐛 version error ([fd57688](https://github.com/antvis/x6/commit/fd5768861fedda32d341c774f6e80da67646426f))
* 🐛 version not found ([8166346](https://github.com/antvis/x6/commit/8166346771f11ef5997a6e1ed376987408e57cde))
* 🐛 x6 version ([f2e01c4](https://github.com/antvis/x6/commit/f2e01c44a1f1acd9390c9de0b5ade913cfd8b03b))





### Dependencies

* **@antv/x6:** upgraded to 0.13.7

# @antv/x6-app-draw [1.0.0-beta.5](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.0-beta.4...@antv/x6-app-draw@1.0.0-beta.5) (2020-11-17)


### Bug Fixes

* 🐛 apps router ([8324eaa](https://github.com/antvis/x6/commit/8324eaa0a85cb14873f5095fe8d2695d80b5215a))
* 🐛 chagne shape attrs for draw demo ([cf30fb3](https://github.com/antvis/x6/commit/cf30fb37841a4f44b1352d31d5ce7e3700f0fe85))





### Dependencies

* **@antv/x6:** upgraded to 1.0.0-beta.5

# @antv/x6-app-draw [1.0.0-beta.4](https://github.com/antvis/x6/compare/@antv/x6-app-draw@1.0.0-beta.3...@antv/x6-app-draw@1.0.0-beta.4) (2020-11-05)
## @antv/x6-app-draw [0.10.97](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.96...@antv/x6-app-draw@0.10.97) (2020-11-17)





### Dependencies

* **@antv/x6:** upgraded to 0.13.6

## @antv/x6-app-draw [0.10.96](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.95...@antv/x6-app-draw@0.10.96) (2020-11-17)





### Dependencies

* **@antv/x6:** upgraded to 0.13.5

## @antv/x6-app-draw [0.10.95](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.94...@antv/x6-app-draw@0.10.95) (2020-11-13)


### Bug Fixes

* 🐛 chagne shape attrs for draw demo ([cf30fb3](https://github.com/antvis/x6/commit/cf30fb37841a4f44b1352d31d5ce7e3700f0fe85))

## @antv/x6-app-draw [0.10.94](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.93...@antv/x6-app-draw@0.10.94) (2020-11-13)





### Dependencies

* **@antv/x6:** upgraded to 0.13.4

## @antv/x6-app-draw [0.10.93](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.92...@antv/x6-app-draw@0.10.93) (2020-11-13)

## @antv/x6-app-draw [0.10.92](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.91...@antv/x6-app-draw@0.10.92) (2020-11-12)





### Dependencies

* **@antv/x6:** upgraded to 0.13.3

## @antv/x6-app-draw [0.10.91](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.90...@antv/x6-app-draw@0.10.91) (2020-11-12)





### Dependencies

* **@antv/x6:** upgraded to 0.13.2

## @antv/x6-app-draw [0.10.90](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.89...@antv/x6-app-draw@0.10.90) (2020-11-11)





### Dependencies

* **@antv/x6:** upgraded to 0.13.1

## @antv/x6-app-draw [0.10.89](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.88...@antv/x6-app-draw@0.10.89) (2020-11-10)





### Dependencies

* **@antv/x6:** upgraded to 0.13.0

## @antv/x6-app-draw [0.10.88](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.87...@antv/x6-app-draw@0.10.88) (2020-11-10)





### Dependencies

* **@antv/x6:** upgraded to 0.12.1

## @antv/x6-app-draw [0.10.87](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.86...@antv/x6-app-draw@0.10.87) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.12.0

## @antv/x6-app-draw [0.10.86](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.85...@antv/x6-app-draw@0.10.86) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.11.2

## @antv/x6-app-draw [0.10.85](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.84...@antv/x6-app-draw@0.10.85) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.11.1

## @antv/x6-app-draw [0.10.84](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.83...@antv/x6-app-draw@0.10.84) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.11.0

## @antv/x6-app-draw [0.10.83](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.82...@antv/x6-app-draw@0.10.83) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.10.81

## @antv/x6-app-draw [0.10.82](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.81...@antv/x6-app-draw@0.10.82) (2020-11-06)





### Dependencies

* **@antv/x6:** upgraded to 0.10.80

## @antv/x6-app-draw [0.10.81](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.80...@antv/x6-app-draw@0.10.81) (2020-11-05)


### Bug Fixes

* 🐛 apps router ([8324eaa](https://github.com/antvis/x6/commit/8324eaa0a85cb14873f5095fe8d2695d80b5215a))





### Dependencies

* **@antv/x6:** upgraded to 0.10.79

## @antv/x6-app-draw [0.10.79](https://github.com/antvis/x6/compare/@antv/x6-app-draw@0.10.78...@antv/x6-app-draw@0.10.79) (2020-11-05)


### Bug Fixes

* 🐛 version error ([5c80d69](https://github.com/antvis/x6/commit/5c80d69f66217e131176fce89b95d30bd47e3c4c))





### Dependencies

* **@antv/x6:** upgraded to 1.0.0-beta.4
