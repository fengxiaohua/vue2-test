## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-31)





### Dependencies

* **@antv/x6:** upgraded to 1.26.1

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-24)





### Dependencies

* **@antv/x6:** upgraded to 1.26.0

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-18)

## @antv/x6-app-er [1.1.7](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.6...@antv/x6-app-er@1.1.7) (2021-08-18)





### Dependencies

* **@antv/x6:** upgraded to 1.25.5

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-17)





### Dependencies

* **@antv/x6:** upgraded to 1.25.4

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-16)

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-06)





### Dependencies

* **@antv/x6:** upgraded to 1.25.3

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-06)





### Dependencies

* **@antv/x6:** upgraded to 1.25.2

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-08-03)





### Dependencies

* **@antv/x6:** upgraded to 1.25.1

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-07-27)





### Dependencies

* **@antv/x6:** upgraded to 1.25.0

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-07-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.8

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.7

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-07-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.6

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-07-10)

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-07-09)





### Dependencies

* **@antv/x6:** upgraded to 1.24.5

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-07-05)

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-23)

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-23)





### Dependencies

* **@antv/x6:** upgraded to 1.24.4

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-22)





### Dependencies

* **@antv/x6:** upgraded to 1.24.3

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-21)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.4.5

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.2

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-21)

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-21)





### Dependencies

* **@antv/x6:** upgraded to 1.24.1

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-06-20)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.4.4

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-19)





### Dependencies

* **@antv/x6:** upgraded to 1.24.0

## @antv/x6-app-er [1.1.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.5...@antv/x6-app-er@1.1.6) (2021-06-19)





### Dependencies

* **@antv/x6:** upgraded to 1.23.13

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-18)

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-17)

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-17)





### Dependencies

* **@antv/x6:** upgraded to 1.23.12

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-17)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.11

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-16)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.10
* **@antv/x6-react-components:** upgraded to 1.1.13
* **@antv/x6-react-shape:** upgraded to 1.4.3

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-15)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-15)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.9

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-13)





### Dependencies

* **@antv/x6:** upgraded to 1.23.8

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-11)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.7
* **@antv/x6-react-components:** upgraded to 1.1.12
* **@antv/x6-react-shape:** upgraded to 1.4.2

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-06-09)





### Dependencies

* **@antv/x6:** upgraded to 1.23.6

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-09)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.5

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-09)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.4
* **@antv/x6-react-components:** upgraded to 1.1.11

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.3

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.2

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-02)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.1

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-02)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.23.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-06-01)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.22.1

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-31)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-31)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-31)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.10

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-27)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.22.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-18)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.21.7

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-18)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.21.6

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-05-14)





### Dependencies

* **@antv/x6:** upgraded to 1.21.5

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-12)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.21.4

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-08)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.21.3

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.21.2

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-07)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.21.1

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-06)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.21.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-04)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.20.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-01)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.19.6

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-05-01)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.19.5

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-30)


### Bug Fixes

* 🐛 fix x6-react-components version in demo ([085ffab](https://github.com/antvis/x6/commit/085ffabe84e89e12bf47c3c8680c5cf1eb929593))





### Dependencies

* **@antv/x6:** upgraded to 1.19.4
* **@antv/x6-react-shape:** upgraded to 1.4.1

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-30)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-30)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-28)





### Dependencies

* **@antv/x6:** upgraded to 1.19.3

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-28)





### Dependencies

* **@antv/x6:** upgraded to 1.19.2

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-28)





### Dependencies

* **@antv/x6:** upgraded to 1.19.1
* **@antv/x6-react-shape:** upgraded to 1.4.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-26)





### Dependencies

* **@antv/x6:** upgraded to 1.19.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-21)

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-04-20)





### Dependencies

* **@antv/x6:** upgraded to 1.18.5

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-17)





### Dependencies

* **@antv/x6:** upgraded to 1.18.4

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-13)





### Dependencies

* **@antv/x6:** upgraded to 1.18.3

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-04-01)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.9

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-30)





### Dependencies

* **@antv/x6:** upgraded to 1.18.2
* **@antv/x6-react-components:** upgraded to 1.1.8
* **@antv/x6-react-shape:** upgraded to 1.3.5

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-30)





### Dependencies

* **@antv/x6:** upgraded to 1.18.1
* **@antv/x6-react-components:** upgraded to 1.1.7

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-29)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.6
* **@antv/x6-react-shape:** upgraded to 1.3.4

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-28)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-25)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-24)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.5

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-24)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-24)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.4

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-24)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.1.3
* **@antv/x6-react-shape:** upgraded to 1.3.3

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-23)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-23)





### Dependencies

* **@antv/x6:** upgraded to 1.18.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-23)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-23)





### Dependencies

* **@antv/x6:** upgraded to 1.17.7
* **@antv/x6-react-components:** upgraded to 1.1.2
* **@antv/x6-react-shape:** upgraded to 1.3.2

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-20)





### Dependencies

* **@antv/x6:** upgraded to 1.17.6

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-19)





### Dependencies

* **@antv/x6:** upgraded to 1.17.5

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-19)





### Dependencies

* **@antv/x6:** upgraded to 1.17.4

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-16)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-15)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-15)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-12)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-12)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-12)





### Dependencies

* **@antv/x6:** upgraded to 1.17.3

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-12)





### Dependencies

* **@antv/x6:** upgraded to 1.17.2

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.17.1

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.17.0

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-03-11)





### Dependencies

* **@antv/x6:** upgraded to 1.16.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-10)





### Dependencies

* **@antv/x6:** upgraded to 1.15.0

## @antv/x6-app-er [1.1.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.4...@antv/x6-app-er@1.1.5) (2021-03-10)





### Dependencies

* **@antv/x6:** upgraded to 1.14.0

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-07)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-04)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-03)





### Dependencies

* **@antv/x6:** upgraded to 1.13.4

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-03-02)





### Dependencies

* **@antv/x6:** upgraded to 1.13.3

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-03-02)





### Dependencies

* **@antv/x6:** upgraded to 1.13.2

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-23)





### Dependencies

* **@antv/x6:** upgraded to 1.13.1

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-23)





### Dependencies

* **@antv/x6:** upgraded to 1.13.0

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-22)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-20)





### Dependencies

* **@antv/x6:** upgraded to 1.12.32

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-09)





### Dependencies

* **@antv/x6:** upgraded to 1.12.31

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-07)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-07)





### Dependencies

* **@antv/x6:** upgraded to 1.12.30
* **@antv/x6-react-shape:** upgraded to 1.3.1

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-05)





### Dependencies

* **@antv/x6:** upgraded to 1.12.29

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-05)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-04)





### Dependencies

* **@antv/x6:** upgraded to 1.12.28

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-03)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-03)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-03)





### Dependencies

* **@antv/x6:** upgraded to 1.12.27

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-02)





### Dependencies

* **@antv/x6:** upgraded to 1.12.26

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-02)





### Dependencies

* **@antv/x6:** upgraded to 1.12.25

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-02)





### Dependencies

* **@antv/x6:** upgraded to 1.12.24

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-02)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-02-01)





### Dependencies

* **@antv/x6:** upgraded to 1.12.23

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-01)





### Dependencies

* **@antv/x6:** upgraded to 1.12.22

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-02-01)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-31)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-31)





### Dependencies

* **@antv/x6:** upgraded to 1.12.21

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-30)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-30)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-30)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-29)





### Dependencies

* **@antv/x6:** upgraded to 1.12.20

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-28)





### Dependencies

* **@antv/x6:** upgraded to 1.12.19

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-27)





### Dependencies

* **@antv/x6:** upgraded to 1.12.18

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-26)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.3.0

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-26)





### Dependencies

* **@antv/x6:** upgraded to 1.12.17

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-01-25)





### Dependencies

* **@antv/x6:** upgraded to 1.12.16

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-25)





### Dependencies

* **@antv/x6:** upgraded to 1.12.15

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-25)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-24)





### Dependencies

* **@antv/x6:** upgraded to 1.12.14

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-01-23)





### Dependencies

* **@antv/x6:** upgraded to 1.12.13

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-23)





### Dependencies

* **@antv/x6:** upgraded to 1.12.12

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-22)





### Dependencies

* **@antv/x6:** upgraded to 1.12.11
* **@antv/x6-react-shape:** upgraded to 1.2.5

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-22)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-22)





### Dependencies

* **@antv/x6:** upgraded to 1.12.10

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-22)





### Dependencies

* **@antv/x6:** upgraded to 1.12.9

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.8

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-21)

## @antv/x6-app-er [1.1.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.3...@antv/x6-app-er@1.1.4) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.7

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.6

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-21)





### Dependencies

* **@antv/x6:** upgraded to 1.12.5

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-20)





### Dependencies

* **@antv/x6:** upgraded to 1.12.4

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-20)





### Dependencies

* **@antv/x6:** upgraded to 1.12.3

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-20)





### Dependencies

* **@antv/x6:** upgraded to 1.12.2

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-19)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-19)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-18)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-15)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-14)





### Dependencies

* **@antv/x6:** upgraded to 1.12.1

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-13)

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.12.0

## @antv/x6-app-er [1.1.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.2...@antv/x6-app-er@1.1.3) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.11.6

## @antv/x6-app-er [1.1.1](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.0...@antv/x6-app-er@1.1.1) (2021-01-13)





### Dependencies

* **@antv/x6:** upgraded to 1.8.3
* **@antv/x6-react-components:** upgraded to 1.0.3
* **@antv/x6-react-shape:** upgraded to 1.2.2

# @antv/x6-app-er [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.0.0...@antv/x6-app-er@1.1.0) (2021-01-12)


### Bug Fixes

* 🐛 add design for demos ([6e849bc](https://github.com/antvis/x6/commit/6e849bc80fe1bc242a2efa7282a425c0835619fb))
* 🐛 change mock data ([1ed8d57](https://github.com/antvis/x6/commit/1ed8d57b8193e481985205ad6c92858e063bed95))
* 🐛 fix lint error ([7240cfc](https://github.com/antvis/x6/commit/7240cfc8e0cc6b9a4eec7fd7a0f56666cc727cae))


### Features

* ✨ add github source link ([83c4c08](https://github.com/antvis/x6/commit/83c4c080d0c2e22dc8deb960319f646bf4c80a64))
* ✨ ERGraphDemo 初步完成 ([ffbea86](https://github.com/antvis/x6/commit/ffbea86751f5c7ed008c4deaaffee908fc434622))
* ✨ er图demo优化 ([fe9798b](https://github.com/antvis/x6/commit/fe9798bd50457b09595d299d586545e0e3d76b17))
* ✨ 修复warning ([bc9f69a](https://github.com/antvis/x6/commit/bc9f69a9ce48e10af2aca3716fd71b063bc77126))





### Dependencies

* **@antv/x6:** upgraded to 1.8.2
* **@antv/x6-react-components:** upgraded to 1.0.2
* **@antv/x6-react-shape:** upgraded to 1.2.1

## @antv/x6-app-er [1.1.1](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.0...@antv/x6-app-er@1.1.1) (2021-01-12)





### Dependencies

* **@antv/x6:** upgraded to 1.8.1

# @antv/x6-app-er [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.0.0...@antv/x6-app-er@1.1.0) (2021-01-11)


### Bug Fixes

* 🐛 add design for demos ([6e849bc](https://github.com/antvis/x6/commit/6e849bc80fe1bc242a2efa7282a425c0835619fb))
* 🐛 change mock data ([1ed8d57](https://github.com/antvis/x6/commit/1ed8d57b8193e481985205ad6c92858e063bed95))
* 🐛 fix lint error ([7240cfc](https://github.com/antvis/x6/commit/7240cfc8e0cc6b9a4eec7fd7a0f56666cc727cae))


### Features

* ✨ add github source link ([83c4c08](https://github.com/antvis/x6/commit/83c4c080d0c2e22dc8deb960319f646bf4c80a64))
* ✨ ERGraphDemo 初步完成 ([ffbea86](https://github.com/antvis/x6/commit/ffbea86751f5c7ed008c4deaaffee908fc434622))
* ✨ er图demo优化 ([fe9798b](https://github.com/antvis/x6/commit/fe9798bd50457b09595d299d586545e0e3d76b17))
* ✨ 修复warning ([bc9f69a](https://github.com/antvis/x6/commit/bc9f69a9ce48e10af2aca3716fd71b063bc77126))





### Dependencies

* **@antv/x6:** upgraded to 1.8.0
* **@antv/x6-react-components:** upgraded to 1.0.1
* **@antv/x6-react-shape:** upgraded to 1.2.0

## @antv/x6-app-er [1.2.78](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.77...@antv/x6-app-er@1.2.78) (2021-01-11)





### Dependencies

* **@antv/x6:** upgraded to 1.11.2

## @antv/x6-app-er [1.2.77](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.76...@antv/x6-app-er@1.2.77) (2021-01-11)





### Dependencies

* **@antv/x6:** upgraded to 1.11.1
* **@antv/x6-react-shape:** upgraded to 1.2.2

## @antv/x6-app-er [1.2.76](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.75...@antv/x6-app-er@1.2.76) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.11.0
* **@antv/x6-react-shape:** upgraded to 1.2.1

## @antv/x6-app-er [1.2.75](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.74...@antv/x6-app-er@1.2.75) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.2
* **@antv/x6-react-shape:** upgraded to 1.2.0

## @antv/x6-app-er [1.2.74](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.73...@antv/x6-app-er@1.2.74) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.1
* **@antv/x6-react-shape:** upgraded to 1.1.60

## @antv/x6-app-er [1.2.73](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.72...@antv/x6-app-er@1.2.73) (2021-01-08)





### Dependencies

* **@antv/x6:** upgraded to 1.10.0
* **@antv/x6-react-shape:** upgraded to 1.1.59

## @antv/x6-app-er [1.2.72](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.71...@antv/x6-app-er@1.2.72) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.3
* **@antv/x6-react-shape:** upgraded to 1.1.58

## @antv/x6-app-er [1.2.71](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.70...@antv/x6-app-er@1.2.71) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.2
* **@antv/x6-react-shape:** upgraded to 1.1.57

## @antv/x6-app-er [1.2.70](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.69...@antv/x6-app-er@1.2.70) (2021-01-05)





### Dependencies

* **@antv/x6:** upgraded to 1.9.1
* **@antv/x6-react-shape:** upgraded to 1.1.56

## @antv/x6-app-er [1.2.69](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.68...@antv/x6-app-er@1.2.69) (2021-01-04)





### Dependencies

* **@antv/x6:** upgraded to 1.9.0
* **@antv/x6-react-shape:** upgraded to 1.1.55

## @antv/x6-app-er [1.2.68](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.67...@antv/x6-app-er@1.2.68) (2021-01-04)





### Dependencies

* **@antv/x6:** upgraded to 1.8.0
* **@antv/x6-react-shape:** upgraded to 1.1.54

## @antv/x6-app-er [1.2.67](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.66...@antv/x6-app-er@1.2.67) (2021-01-04)





### Dependencies

* **@antv/x6-react-shape:** upgraded to 1.1.53

## @antv/x6-app-er [1.2.66](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.65...@antv/x6-app-er@1.2.66) (2020-12-31)





### Dependencies

* **@antv/x6:** upgraded to 1.7.12
* **@antv/x6-react-shape:** upgraded to 1.1.52

## @antv/x6-app-er [1.2.65](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.64...@antv/x6-app-er@1.2.65) (2020-12-30)





### Dependencies

* **@antv/x6:** upgraded to 1.7.11
* **@antv/x6-react-shape:** upgraded to 1.1.51

## @antv/x6-app-er [1.2.64](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.63...@antv/x6-app-er@1.2.64) (2020-12-29)





### Dependencies

* **@antv/x6:** upgraded to 1.7.10
* **@antv/x6-react-shape:** upgraded to 1.1.50

## @antv/x6-app-er [1.2.63](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.62...@antv/x6-app-er@1.2.63) (2020-12-29)





### Dependencies

* **@antv/x6:** upgraded to 1.7.9
* **@antv/x6-react-shape:** upgraded to 1.1.49

## @antv/x6-app-er [1.2.62](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.61...@antv/x6-app-er@1.2.62) (2020-12-28)





### Dependencies

* **@antv/x6:** upgraded to 1.7.8
* **@antv/x6-react-shape:** upgraded to 1.1.48

## @antv/x6-app-er [1.2.61](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.60...@antv/x6-app-er@1.2.61) (2020-12-28)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.0.4

## @antv/x6-app-er [1.2.60](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.59...@antv/x6-app-er@1.2.60) (2020-12-26)





### Dependencies

* **@antv/x6:** upgraded to 1.7.7
* **@antv/x6-react-shape:** upgraded to 1.1.47

## @antv/x6-app-er [1.2.59](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.58...@antv/x6-app-er@1.2.59) (2020-12-25)





### Dependencies

* **@antv/x6:** upgraded to 1.7.6
* **@antv/x6-react-shape:** upgraded to 1.1.46

## @antv/x6-app-er [1.2.58](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.57...@antv/x6-app-er@1.2.58) (2020-12-25)





### Dependencies

* **@antv/x6:** upgraded to 1.7.5
* **@antv/x6-react-shape:** upgraded to 1.1.45

## @antv/x6-app-er [1.2.57](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.56...@antv/x6-app-er@1.2.57) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.4
* **@antv/x6-react-shape:** upgraded to 1.1.44

## @antv/x6-app-er [1.2.56](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.55...@antv/x6-app-er@1.2.56) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.3
* **@antv/x6-react-shape:** upgraded to 1.1.43

## @antv/x6-app-er [1.2.55](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.54...@antv/x6-app-er@1.2.55) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.2
* **@antv/x6-react-shape:** upgraded to 1.1.42

## @antv/x6-app-er [1.2.54](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.53...@antv/x6-app-er@1.2.54) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.1
* **@antv/x6-react-shape:** upgraded to 1.1.41

## @antv/x6-app-er [1.2.53](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.52...@antv/x6-app-er@1.2.53) (2020-12-24)





### Dependencies

* **@antv/x6:** upgraded to 1.7.0
* **@antv/x6-react-shape:** upgraded to 1.1.40

## @antv/x6-app-er [1.2.52](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.51...@antv/x6-app-er@1.2.52) (2020-12-23)





### Dependencies

* **@antv/x6:** upgraded to 1.6.4
* **@antv/x6-react-shape:** upgraded to 1.1.39

## @antv/x6-app-er [1.2.51](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.50...@antv/x6-app-er@1.2.51) (2020-12-22)





### Dependencies

* **@antv/x6:** upgraded to 1.6.3
* **@antv/x6-react-shape:** upgraded to 1.1.38

## @antv/x6-app-er [1.2.50](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.49...@antv/x6-app-er@1.2.50) (2020-12-22)





### Dependencies

* **@antv/x6:** upgraded to 1.6.2
* **@antv/x6-react-shape:** upgraded to 1.1.37

## @antv/x6-app-er [1.2.49](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.48...@antv/x6-app-er@1.2.49) (2020-12-21)





### Dependencies

* **@antv/x6:** upgraded to 1.6.1
* **@antv/x6-react-components:** upgraded to 1.0.3
* **@antv/x6-react-shape:** upgraded to 1.1.36

## @antv/x6-app-er [1.2.48](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.47...@antv/x6-app-er@1.2.48) (2020-12-21)





### Dependencies

* **@antv/x6:** upgraded to 1.6.0
* **@antv/x6-react-shape:** upgraded to 1.1.35

## @antv/x6-app-er [1.2.47](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.46...@antv/x6-app-er@1.2.47) (2020-12-18)





### Dependencies

* **@antv/x6:** upgraded to 1.5.2
* **@antv/x6-react-shape:** upgraded to 1.1.34

## @antv/x6-app-er [1.2.46](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.45...@antv/x6-app-er@1.2.46) (2020-12-17)





### Dependencies

* **@antv/x6:** upgraded to 1.5.1
* **@antv/x6-react-shape:** upgraded to 1.1.33

## @antv/x6-app-er [1.2.45](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.44...@antv/x6-app-er@1.2.45) (2020-12-17)





### Dependencies

* **@antv/x6:** upgraded to 1.5.0
* **@antv/x6-react-shape:** upgraded to 1.1.32

## @antv/x6-app-er [1.2.44](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.43...@antv/x6-app-er@1.2.44) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.2
* **@antv/x6-react-shape:** upgraded to 1.1.31

## @antv/x6-app-er [1.2.43](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.42...@antv/x6-app-er@1.2.43) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.1
* **@antv/x6-react-shape:** upgraded to 1.1.30

## @antv/x6-app-er [1.2.42](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.41...@antv/x6-app-er@1.2.42) (2020-12-16)





### Dependencies

* **@antv/x6:** upgraded to 1.4.0
* **@antv/x6-react-shape:** upgraded to 1.1.29

## @antv/x6-app-er [1.2.41](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.40...@antv/x6-app-er@1.2.41) (2020-12-13)





### Dependencies

* **@antv/x6-react-components:** upgraded to 1.0.2

## @antv/x6-app-er [1.2.40](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.39...@antv/x6-app-er@1.2.40) (2020-12-12)





### Dependencies

* **@antv/x6:** upgraded to 1.3.20
* **@antv/x6-react-shape:** upgraded to 1.1.28

## @antv/x6-app-er [1.2.39](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.38...@antv/x6-app-er@1.2.39) (2020-12-11)





### Dependencies

* **@antv/x6:** upgraded to 1.3.19
* **@antv/x6-react-shape:** upgraded to 1.1.27

## @antv/x6-app-er [1.2.38](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.37...@antv/x6-app-er@1.2.38) (2020-12-11)





### Dependencies

* **@antv/x6:** upgraded to 1.3.18
* **@antv/x6-react-shape:** upgraded to 1.1.26

## @antv/x6-app-er [1.2.37](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.36...@antv/x6-app-er@1.2.37) (2020-12-10)





### Dependencies

* **@antv/x6:** upgraded to 1.3.17
* **@antv/x6-react-shape:** upgraded to 1.1.25

## @antv/x6-app-er [1.2.36](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.35...@antv/x6-app-er@1.2.36) (2020-12-10)





### Dependencies

* **@antv/x6:** upgraded to 1.3.16
* **@antv/x6-react-shape:** upgraded to 1.1.24

## @antv/x6-app-er [1.2.35](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.34...@antv/x6-app-er@1.2.35) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.15
* **@antv/x6-react-shape:** upgraded to 1.1.23

## @antv/x6-app-er [1.2.34](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.33...@antv/x6-app-er@1.2.34) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.14
* **@antv/x6-react-shape:** upgraded to 1.1.22

## @antv/x6-app-er [1.2.33](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.32...@antv/x6-app-er@1.2.33) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.13
* **@antv/x6-react-shape:** upgraded to 1.1.21

## @antv/x6-app-er [1.2.32](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.31...@antv/x6-app-er@1.2.32) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.12
* **@antv/x6-react-shape:** upgraded to 1.1.20

## @antv/x6-app-er [1.2.31](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.30...@antv/x6-app-er@1.2.31) (2020-12-09)





### Dependencies

* **@antv/x6:** upgraded to 1.3.11
* **@antv/x6-react-shape:** upgraded to 1.1.19

## @antv/x6-app-er [1.2.30](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.29...@antv/x6-app-er@1.2.30) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.10
* **@antv/x6-react-shape:** upgraded to 1.1.18

## @antv/x6-app-er [1.2.29](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.28...@antv/x6-app-er@1.2.29) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.9
* **@antv/x6-react-shape:** upgraded to 1.1.17

## @antv/x6-app-er [1.2.28](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.27...@antv/x6-app-er@1.2.28) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.8
* **@antv/x6-react-shape:** upgraded to 1.1.16

## @antv/x6-app-er [1.2.27](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.26...@antv/x6-app-er@1.2.27) (2020-12-08)





### Dependencies

* **@antv/x6:** upgraded to 1.3.7
* **@antv/x6-react-shape:** upgraded to 1.1.15

## @antv/x6-app-er [1.2.26](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.25...@antv/x6-app-er@1.2.26) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.6
* **@antv/x6-react-shape:** upgraded to 1.1.14

## @antv/x6-app-er [1.2.25](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.24...@antv/x6-app-er@1.2.25) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.5
* **@antv/x6-react-shape:** upgraded to 1.1.13

## @antv/x6-app-er [1.2.24](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.23...@antv/x6-app-er@1.2.24) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.4
* **@antv/x6-react-components:** upgraded to 1.0.1
* **@antv/x6-react-shape:** upgraded to 1.1.12

## @antv/x6-app-er [1.2.23](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.22...@antv/x6-app-er@1.2.23) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.3
* **@antv/x6-react-shape:** upgraded to 1.1.11

## @antv/x6-app-er [1.2.22](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.21...@antv/x6-app-er@1.2.22) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.2
* **@antv/x6-react-shape:** upgraded to 1.1.10

## @antv/x6-app-er [1.2.21](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.20...@antv/x6-app-er@1.2.21) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.1
* **@antv/x6-react-shape:** upgraded to 1.1.9

## @antv/x6-app-er [1.2.20](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.19...@antv/x6-app-er@1.2.20) (2020-12-07)





### Dependencies

* **@antv/x6:** upgraded to 1.3.0
* **@antv/x6-react-shape:** upgraded to 1.1.8

## @antv/x6-app-er [1.2.19](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.18...@antv/x6-app-er@1.2.19) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.3
* **@antv/x6-react-shape:** upgraded to 1.1.7

## @antv/x6-app-er [1.2.18](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.17...@antv/x6-app-er@1.2.18) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.2
* **@antv/x6-react-shape:** upgraded to 1.1.6

## @antv/x6-app-er [1.2.17](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.16...@antv/x6-app-er@1.2.17) (2020-12-04)





### Dependencies

* **@antv/x6:** upgraded to 1.2.1
* **@antv/x6-react-shape:** upgraded to 1.1.5

## @antv/x6-app-er [1.2.16](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.15...@antv/x6-app-er@1.2.16) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.2.0
* **@antv/x6-react-shape:** upgraded to 1.1.4

## @antv/x6-app-er [1.2.15](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.14...@antv/x6-app-er@1.2.15) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.1.3
* **@antv/x6-react-shape:** upgraded to 1.1.3

## @antv/x6-app-er [1.2.14](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.13...@antv/x6-app-er@1.2.14) (2020-12-02)





### Dependencies

* **@antv/x6:** upgraded to 1.1.2
* **@antv/x6-react-shape:** upgraded to 1.1.2

## @antv/x6-app-er [1.2.13](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.12...@antv/x6-app-er@1.2.13) (2020-11-30)





### Dependencies

* **@antv/x6:** upgraded to 1.1.1
* **@antv/x6-react-shape:** upgraded to 1.1.1

## @antv/x6-app-er [1.2.12](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.11...@antv/x6-app-er@1.2.12) (2020-11-27)





### Dependencies

* **@antv/x6:** upgraded to 1.1.0
* **@antv/x6-react-shape:** upgraded to 1.1.0

## @antv/x6-app-er [1.2.11](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.10...@antv/x6-app-er@1.2.11) (2020-11-27)





### Dependencies

* **@antv/x6:** upgraded to 1.0.9
* **@antv/x6-react-shape:** upgraded to 1.0.9

## @antv/x6-app-er [1.2.10](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.9...@antv/x6-app-er@1.2.10) (2020-11-25)





### Dependencies

* **@antv/x6:** upgraded to 1.0.8
* **@antv/x6-react-shape:** upgraded to 1.0.8

## @antv/x6-app-er [1.2.9](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.8...@antv/x6-app-er@1.2.9) (2020-11-25)





### Dependencies

* **@antv/x6:** upgraded to 1.0.7
* **@antv/x6-react-shape:** upgraded to 1.0.7

## @antv/x6-app-er [1.2.8](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.7...@antv/x6-app-er@1.2.8) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.6
* **@antv/x6-react-shape:** upgraded to 1.0.6

## @antv/x6-app-er [1.2.7](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.6...@antv/x6-app-er@1.2.7) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.5
* **@antv/x6-react-shape:** upgraded to 1.0.5

## @antv/x6-app-er [1.2.6](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.5...@antv/x6-app-er@1.2.6) (2020-11-24)





### Dependencies

* **@antv/x6:** upgraded to 1.0.4
* **@antv/x6-react-shape:** upgraded to 1.0.4

## @antv/x6-app-er [1.2.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.4...@antv/x6-app-er@1.2.5) (2020-11-20)


### Bug Fixes

* 🐛 add design for demos ([6e849bc](https://github.com/antvis/x6/commit/6e849bc80fe1bc242a2efa7282a425c0835619fb))

## @antv/x6-app-er [1.2.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.3...@antv/x6-app-er@1.2.4) (2020-11-20)





### Dependencies

* **@antv/x6:** upgraded to 1.0.3
* **@antv/x6-react-shape:** upgraded to 1.0.3

## @antv/x6-app-er [1.2.3](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.2...@antv/x6-app-er@1.2.3) (2020-11-20)


### Bug Fixes

* 🐛 fix lint error ([7240cfc](https://github.com/antvis/x6/commit/7240cfc8e0cc6b9a4eec7fd7a0f56666cc727cae))

## @antv/x6-app-er [1.2.2](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.1...@antv/x6-app-er@1.2.2) (2020-11-19)





### Dependencies

* **@antv/x6:** upgraded to 1.0.2
* **@antv/x6-react-shape:** upgraded to 1.0.2

## @antv/x6-app-er [1.2.1](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.2.0...@antv/x6-app-er@1.2.1) (2020-11-19)

# @antv/x6-app-er [1.2.0](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.1...@antv/x6-app-er@1.2.0) (2020-11-19)


### Features

* ✨ add github source link ([83c4c08](https://github.com/antvis/x6/commit/83c4c080d0c2e22dc8deb960319f646bf4c80a64))

## @antv/x6-app-er [1.1.1](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.1.0...@antv/x6-app-er@1.1.1) (2020-11-18)

# @antv/x6-app-er [1.1.0](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.0.1...@antv/x6-app-er@1.1.0) (2020-11-18)


### Bug Fixes

* 🐛 change mock data ([1ed8d57](https://github.com/antvis/x6/commit/1ed8d57b8193e481985205ad6c92858e063bed95))


### Features

* ✨ ERGraphDemo 初步完成 ([ffbea86](https://github.com/antvis/x6/commit/ffbea86751f5c7ed008c4deaaffee908fc434622))
* ✨ er图demo优化 ([fe9798b](https://github.com/antvis/x6/commit/fe9798bd50457b09595d299d586545e0e3d76b17))
* ✨ 修复warning ([bc9f69a](https://github.com/antvis/x6/commit/bc9f69a9ce48e10af2aca3716fd71b063bc77126))

## @antv/x6-app-er [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.0.0...@antv/x6-app-er@1.0.1) (2020-11-18)





### Dependencies

* **@antv/x6:** upgraded to 1.0.1
* **@antv/x6-react-shape:** upgraded to 1.0.1

## @antv/x6-app-er [0.10.97](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.96...@antv/x6-app-er@0.10.97) (2020-11-17)


### Bug Fixes

* 🐛 version error ([fd57688](https://github.com/antvis/x6/commit/fd5768861fedda32d341c774f6e80da67646426f))
* 🐛 version not found ([8166346](https://github.com/antvis/x6/commit/8166346771f11ef5997a6e1ed376987408e57cde))
* 🐛 x6 version ([f2e01c4](https://github.com/antvis/x6/commit/f2e01c44a1f1acd9390c9de0b5ade913cfd8b03b))
* 🐛 x6-react-shape version ([9426a89](https://github.com/antvis/x6/commit/9426a898003f041c22da55439f6b9715731f69f6))
* 🐛 x6-react-shape version ([482ce10](https://github.com/antvis/x6/commit/482ce10f1daeee1a154757c6009295d03363df56))





### Dependencies

* **@antv/x6:** upgraded to 0.13.7
* **@antv/x6-react-components:** upgraded to 0.10.20
* **@antv/x6-react-shape:** upgraded to 0.10.35

# @antv/x6-app-er [1.0.0-beta.5](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.0.0-beta.4...@antv/x6-app-er@1.0.0-beta.5) (2020-11-17)


### Bug Fixes

* 🐛 apps router ([8324eaa](https://github.com/antvis/x6/commit/8324eaa0a85cb14873f5095fe8d2695d80b5215a))





### Dependencies

* **@antv/x6:** upgraded to 1.0.0-beta.5
* **@antv/x6-react-components:** upgraded to 0.10.20-beta.1
* **@antv/x6-react-shape:** upgraded to 1.0.0-beta.5

# @antv/x6-app-er [1.0.0-beta.4](https://github.com/antvis/x6/compare/@antv/x6-app-er@1.0.0-beta.3...@antv/x6-app-er@1.0.0-beta.4) (2020-11-05)
## @antv/x6-app-er [0.10.96](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.95...@antv/x6-app-er@0.10.96) (2020-11-17)





### Dependencies

* **@antv/x6:** upgraded to 0.13.6
* **@antv/x6-react-shape:** upgraded to 0.10.34

## @antv/x6-app-er [0.10.95](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.94...@antv/x6-app-er@0.10.95) (2020-11-17)





### Dependencies

* **@antv/x6:** upgraded to 0.13.5
* **@antv/x6-react-shape:** upgraded to 0.10.33

## @antv/x6-app-er [0.10.94](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.93...@antv/x6-app-er@0.10.94) (2020-11-13)





### Dependencies

* **@antv/x6:** upgraded to 0.13.4
* **@antv/x6-react-shape:** upgraded to 0.10.32

## @antv/x6-app-er [0.10.93](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.92...@antv/x6-app-er@0.10.93) (2020-11-12)





### Dependencies

* **@antv/x6:** upgraded to 0.13.3
* **@antv/x6-react-shape:** upgraded to 0.10.31

## @antv/x6-app-er [0.10.92](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.91...@antv/x6-app-er@0.10.92) (2020-11-12)





### Dependencies

* **@antv/x6:** upgraded to 0.13.2
* **@antv/x6-react-shape:** upgraded to 0.10.30

## @antv/x6-app-er [0.10.91](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.90...@antv/x6-app-er@0.10.91) (2020-11-11)





### Dependencies

* **@antv/x6:** upgraded to 0.13.1
* **@antv/x6-react-shape:** upgraded to 0.10.29

## @antv/x6-app-er [0.10.90](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.89...@antv/x6-app-er@0.10.90) (2020-11-10)





### Dependencies

* **@antv/x6-react-components:** upgraded to 0.10.19

## @antv/x6-app-er [0.10.89](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.88...@antv/x6-app-er@0.10.89) (2020-11-10)





### Dependencies

* **@antv/x6:** upgraded to 0.13.0
* **@antv/x6-react-shape:** upgraded to 0.10.28

## @antv/x6-app-er [0.10.88](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.87...@antv/x6-app-er@0.10.88) (2020-11-10)





### Dependencies

* **@antv/x6:** upgraded to 0.12.1
* **@antv/x6-react-shape:** upgraded to 0.10.27

## @antv/x6-app-er [0.10.87](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.86...@antv/x6-app-er@0.10.87) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.12.0
* **@antv/x6-react-shape:** upgraded to 0.10.26

## @antv/x6-app-er [0.10.86](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.85...@antv/x6-app-er@0.10.86) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.11.2
* **@antv/x6-react-components:** upgraded to 0.10.18
* **@antv/x6-react-shape:** upgraded to 0.10.25

## @antv/x6-app-er [0.10.85](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.84...@antv/x6-app-er@0.10.85) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.11.1
* **@antv/x6-react-shape:** upgraded to 0.10.24

## @antv/x6-app-er [0.10.84](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.83...@antv/x6-app-er@0.10.84) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.11.0
* **@antv/x6-react-shape:** upgraded to 0.10.23

## @antv/x6-app-er [0.10.83](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.82...@antv/x6-app-er@0.10.83) (2020-11-09)





### Dependencies

* **@antv/x6:** upgraded to 0.10.81
* **@antv/x6-react-shape:** upgraded to 0.10.22

## @antv/x6-app-er [0.10.82](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.81...@antv/x6-app-er@0.10.82) (2020-11-06)





### Dependencies

* **@antv/x6:** upgraded to 0.10.80
* **@antv/x6-react-shape:** upgraded to 0.10.21

## @antv/x6-app-er [0.10.81](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.80...@antv/x6-app-er@0.10.81) (2020-11-05)


### Bug Fixes

* 🐛 apps router ([8324eaa](https://github.com/antvis/x6/commit/8324eaa0a85cb14873f5095fe8d2695d80b5215a))





### Dependencies

* **@antv/x6:** upgraded to 0.10.79
* **@antv/x6-react-shape:** upgraded to 0.10.20

## @antv/x6-app-er [0.10.79](https://github.com/antvis/x6/compare/@antv/x6-app-er@0.10.78...@antv/x6-app-er@0.10.79) (2020-11-05)


### Bug Fixes

* 🐛 version error ([5c80d69](https://github.com/antvis/x6/commit/5c80d69f66217e131176fce89b95d30bd47e3c4c))





### Dependencies

* **@antv/x6:** upgraded to 1.0.0-beta.4
* **@antv/x6-react-shape:** upgraded to 1.0.0-beta.4
