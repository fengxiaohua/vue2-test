declare module '*.less'
