import React from 'react'

export default function() {
  return (
    <div>
      <h1>Feature List</h1>
    </div>
  )
}
