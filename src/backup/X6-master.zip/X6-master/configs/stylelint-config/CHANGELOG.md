# @antv/stylelint-config 1.0.0 (2021-06-17)


### Bug Fixes

* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))


### Features

* ✨ sharing stylelint configurations ([5061c5d](https://github.com/antvis/x6/commit/5061c5ddf875f43578e8f0f81801151f80c51ee9))

# @antv/stylelint-config 1.0.0 (2021-06-16)


### Bug Fixes

* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))


### Features

* ✨ sharing stylelint configurations ([5061c5d](https://github.com/antvis/x6/commit/5061c5ddf875f43578e8f0f81801151f80c51ee9))

# @antv/stylelint-config 1.0.0 (2021-06-15)


### Features

* ✨ sharing stylelint configurations ([5061c5d](https://github.com/antvis/x6/commit/5061c5ddf875f43578e8f0f81801151f80c51ee9))

# @antv/stylelint-config 1.0.0 (2021-06-15)


### Features

* ✨ sharing stylelint configurations ([5061c5d](https://github.com/antvis/x6/commit/5061c5ddf875f43578e8f0f81801151f80c51ee9))

# @antv/stylelint-config 1.0.0 (2021-06-11)


### Features

* ✨ sharing stylelint configurations ([5061c5d](https://github.com/antvis/x6/commit/5061c5ddf875f43578e8f0f81801151f80c51ee9))
