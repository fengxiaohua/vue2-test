## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-31)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-24)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-18)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-17)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-16)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-06)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-06)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-08-03)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-07-27)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-07-22)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-07-21)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-07-21)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-07-10)

## @antv/x6-package-json [1.0.1](https://github.com/antvis/x6/compare/@antv/x6-package-json@1.0.0...@antv/x6-package-json@1.0.1) (2021-07-09)

# @antv/x6-package-json 1.0.0 (2021-06-17)


### Bug Fixes

* 🐛 fix karma can not process lodash-es ([f7ae6b1](https://github.com/antvis/x6/commit/f7ae6b1f6b961a01c58d8827a9aaa2d5a984a6e0))
* 🐛 should only read json files ([af9d87f](https://github.com/antvis/x6/commit/af9d87fedccf4ba791db5570ca73228520107e2a))
* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))


### Features

* ✨ add deps for jest ([4c831b8](https://github.com/antvis/x6/commit/4c831b84d032cc92f1c914143f4182772202620d))
* ✨ add package inherit, compare commands ([d494b9f](https://github.com/antvis/x6/commit/d494b9f92e4e98816fb00acc02296bf5aa63f1b4))
* ✨ sharing partial(devDependencies, peerDependencies, dependencies, scripts) package.json ([95c1112](https://github.com/antvis/x6/commit/95c1112c4e226c060dd94019f6ce5530a922a92f))
* ✨ update vue deps ([37eae0b](https://github.com/antvis/x6/commit/37eae0b12502fba373d30153e0d1ac2085e843e8))

# @antv/x6-package-json 1.0.0 (2021-06-16)


### Bug Fixes

* 🐛 fix karma can not process lodash-es ([f7ae6b1](https://github.com/antvis/x6/commit/f7ae6b1f6b961a01c58d8827a9aaa2d5a984a6e0))
* 🐛 should only read json files ([af9d87f](https://github.com/antvis/x6/commit/af9d87fedccf4ba791db5570ca73228520107e2a))
* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))


### Features

* ✨ add deps for jest ([4c831b8](https://github.com/antvis/x6/commit/4c831b84d032cc92f1c914143f4182772202620d))
* ✨ add package inherit, compare commands ([d494b9f](https://github.com/antvis/x6/commit/d494b9f92e4e98816fb00acc02296bf5aa63f1b4))
* ✨ sharing partial(devDependencies, peerDependencies, dependencies, scripts) package.json ([95c1112](https://github.com/antvis/x6/commit/95c1112c4e226c060dd94019f6ce5530a922a92f))
* ✨ update vue deps ([37eae0b](https://github.com/antvis/x6/commit/37eae0b12502fba373d30153e0d1ac2085e843e8))

# @antv/x6-package-json 1.0.0 (2021-06-15)


### Bug Fixes

* 🐛 fix karma can not process lodash-es ([f7ae6b1](https://github.com/antvis/x6/commit/f7ae6b1f6b961a01c58d8827a9aaa2d5a984a6e0))
* 🐛 should only read json files ([af9d87f](https://github.com/antvis/x6/commit/af9d87fedccf4ba791db5570ca73228520107e2a))


### Features

* ✨ add deps for jest ([4c831b8](https://github.com/antvis/x6/commit/4c831b84d032cc92f1c914143f4182772202620d))
* ✨ add package inherit, compare commands ([d494b9f](https://github.com/antvis/x6/commit/d494b9f92e4e98816fb00acc02296bf5aa63f1b4))
* ✨ sharing partial(devDependencies, peerDependencies, dependencies, scripts) package.json ([95c1112](https://github.com/antvis/x6/commit/95c1112c4e226c060dd94019f6ce5530a922a92f))
* ✨ update vue deps ([37eae0b](https://github.com/antvis/x6/commit/37eae0b12502fba373d30153e0d1ac2085e843e8))

# @antv/x6-package-json 1.0.0 (2021-06-15)


### Bug Fixes

* 🐛 fix karma can not process lodash-es ([f7ae6b1](https://github.com/antvis/x6/commit/f7ae6b1f6b961a01c58d8827a9aaa2d5a984a6e0))
* 🐛 should only read json files ([af9d87f](https://github.com/antvis/x6/commit/af9d87fedccf4ba791db5570ca73228520107e2a))


### Features

* ✨ add deps for jest ([4c831b8](https://github.com/antvis/x6/commit/4c831b84d032cc92f1c914143f4182772202620d))
* ✨ add package inherit, compare commands ([d494b9f](https://github.com/antvis/x6/commit/d494b9f92e4e98816fb00acc02296bf5aa63f1b4))
* ✨ sharing partial(devDependencies, peerDependencies, dependencies, scripts) package.json ([95c1112](https://github.com/antvis/x6/commit/95c1112c4e226c060dd94019f6ce5530a922a92f))
* ✨ update vue deps ([37eae0b](https://github.com/antvis/x6/commit/37eae0b12502fba373d30153e0d1ac2085e843e8))

# @antv/x6-package-json 1.0.0 (2021-06-11)


### Bug Fixes

* 🐛 fix karma can not process lodash-es ([f7ae6b1](https://github.com/antvis/x6/commit/f7ae6b1f6b961a01c58d8827a9aaa2d5a984a6e0))
* 🐛 should only read json files ([af9d87f](https://github.com/antvis/x6/commit/af9d87fedccf4ba791db5570ca73228520107e2a))


### Features

* ✨ add deps for jest ([4c831b8](https://github.com/antvis/x6/commit/4c831b84d032cc92f1c914143f4182772202620d))
* ✨ add package inherit, compare commands ([d494b9f](https://github.com/antvis/x6/commit/d494b9f92e4e98816fb00acc02296bf5aa63f1b4))
* ✨ sharing partial(devDependencies, peerDependencies, dependencies, scripts) package.json ([95c1112](https://github.com/antvis/x6/commit/95c1112c4e226c060dd94019f6ce5530a922a92f))
* ✨ update vue deps ([37eae0b](https://github.com/antvis/x6/commit/37eae0b12502fba373d30153e0d1ac2085e843e8))
