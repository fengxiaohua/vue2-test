export declare function check(cwd: string, args: any): void;
