export declare function update(cwd: string): void;
