import { PackageInfos } from 'workspace-tools/lib/types/PackageInfo';
export declare function collect(cwd: string): {
    allPackages: PackageInfos;
    modifiedPackages: string[];
};
