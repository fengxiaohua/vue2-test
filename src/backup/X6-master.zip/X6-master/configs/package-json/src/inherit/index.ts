// Please see: https://github.com/microsoft/package-inherit

import { update } from './update'
import { check } from './check'

export { update, check }
