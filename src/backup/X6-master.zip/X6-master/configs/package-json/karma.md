保持下面两个模块的版本，不然 x6 主包的测试跑步起来
- "karma-typescript": "^5.3.0"
- "karma-typescript-es6-transform": "^5.3.0"
