# @antv/eslint-config 1.0.0 (2021-06-17)


### Bug Fixes

* 🐛 fix eslint errors ([06ba121](https://github.com/antvis/x6/commit/06ba121e3b937c5aeebbbe2b24e6db67fc141cb9))
* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))


### Features

* ✨ add lint rules for *.js files ([21f5436](https://github.com/antvis/x6/commit/21f54366776a304e8abb9df087c645653fb22ed5))
* ✨ add unicorn plugin ([3e8515b](https://github.com/antvis/x6/commit/3e8515bedf0da8ca10119c8a00ffd972f3a1e3aa))
* ✨ support bitwise ([d9bc9d9](https://github.com/antvis/x6/commit/d9bc9d92e8bec74e780a44364f9e21da5f34096b))

# @antv/eslint-config 1.0.0 (2021-06-16)


### Bug Fixes

* 🐛 fix eslint errors ([06ba121](https://github.com/antvis/x6/commit/06ba121e3b937c5aeebbbe2b24e6db67fc141cb9))
* update dependencies and fix type errors ([#1103](https://github.com/antvis/x6/issues/1103)) ([056b862](https://github.com/antvis/x6/commit/056b862b4efe7dbdc559cac7194c2453996acc07))


### Features

* ✨ add lint rules for *.js files ([21f5436](https://github.com/antvis/x6/commit/21f54366776a304e8abb9df087c645653fb22ed5))
* ✨ add unicorn plugin ([3e8515b](https://github.com/antvis/x6/commit/3e8515bedf0da8ca10119c8a00ffd972f3a1e3aa))
* ✨ support bitwise ([d9bc9d9](https://github.com/antvis/x6/commit/d9bc9d92e8bec74e780a44364f9e21da5f34096b))

# @antv/eslint-config 1.0.0 (2021-06-15)


### Bug Fixes

* 🐛 fix eslint errors ([06ba121](https://github.com/antvis/x6/commit/06ba121e3b937c5aeebbbe2b24e6db67fc141cb9))


### Features

* ✨ add lint rules for *.js files ([21f5436](https://github.com/antvis/x6/commit/21f54366776a304e8abb9df087c645653fb22ed5))
* ✨ add unicorn plugin ([3e8515b](https://github.com/antvis/x6/commit/3e8515bedf0da8ca10119c8a00ffd972f3a1e3aa))
* ✨ support bitwise ([d9bc9d9](https://github.com/antvis/x6/commit/d9bc9d92e8bec74e780a44364f9e21da5f34096b))

# @antv/eslint-config 1.0.0 (2021-06-15)


### Bug Fixes

* 🐛 fix eslint errors ([06ba121](https://github.com/antvis/x6/commit/06ba121e3b937c5aeebbbe2b24e6db67fc141cb9))


### Features

* ✨ add lint rules for *.js files ([21f5436](https://github.com/antvis/x6/commit/21f54366776a304e8abb9df087c645653fb22ed5))
* ✨ add unicorn plugin ([3e8515b](https://github.com/antvis/x6/commit/3e8515bedf0da8ca10119c8a00ffd972f3a1e3aa))
* ✨ support bitwise ([d9bc9d9](https://github.com/antvis/x6/commit/d9bc9d92e8bec74e780a44364f9e21da5f34096b))

# @antv/eslint-config 1.0.0 (2021-06-11)


### Bug Fixes

* 🐛 fix eslint errors ([06ba121](https://github.com/antvis/x6/commit/06ba121e3b937c5aeebbbe2b24e6db67fc141cb9))


### Features

* ✨ add lint rules for *.js files ([21f5436](https://github.com/antvis/x6/commit/21f54366776a304e8abb9df087c645653fb22ed5))
* ✨ add unicorn plugin ([3e8515b](https://github.com/antvis/x6/commit/3e8515bedf0da8ca10119c8a00ffd972f3a1e3aa))
* ✨ support bitwise ([d9bc9d9](https://github.com/antvis/x6/commit/d9bc9d92e8bec74e780a44364f9e21da5f34096b))
