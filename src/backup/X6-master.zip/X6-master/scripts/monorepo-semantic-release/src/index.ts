import { release } from './runner'

release({ debug: true })
