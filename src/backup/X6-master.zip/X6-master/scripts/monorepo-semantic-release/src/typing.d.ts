declare module 'bash-path'
declare module 'semantic-release/lib/get-config'
declare module 'promise-events'
declare module 'git-log-parser'
