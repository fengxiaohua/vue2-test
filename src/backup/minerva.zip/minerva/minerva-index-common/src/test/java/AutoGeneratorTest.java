import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.TemplateConfig;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.sensesai.minerva.common.entity.BaseEntity;

import java.io.File;

/**
 * 自动代码生成器.
 *
 * @author yinkaifeng
 * @since 2021-10-15 11:23 上午
 */
public class AutoGeneratorTest {

    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://192.168.10.83:13306/stelladp";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "123456";

    public static void main(String[] args) {
        String modelName = "minerva-index-execute/minerva-index-execute-provider";
        //作者
        String author = "yinkaifeng";
        //表名
        String table = "minerva_login_score";
        //文件包路径
        String basePackage = "com.sensesai.minerva.execute";

        String basePath = System.getProperty("user.dir");
        String projectPath = basePath + File.separator + modelName;
        GlobalConfig globalConfig = new GlobalConfig();
        globalConfig
                .setDateType(DateType.ONLY_DATE)
                //作者
                .setAuthor(author)
                //生成路径
                .setOutputDir(projectPath + "/src/main/java")
                //文件覆盖
                .setFileOverride(false)
                //设置生成的service接口名 首字母是否为I
                .setServiceName("I%sService");

        DataSourceConfig dsConfig = new DataSourceConfig();
        dsConfig.setDbType(DbType.MYSQL)
                .setDriverName(DRIVER)
                .setUrl(URL)
                .setUsername(USERNAME)
                .setPassword(PASSWORD);

        PackageConfig pkConfig = new PackageConfig();
        pkConfig.setParent(basePackage);

        StrategyConfig stConfig = new StrategyConfig();
        stConfig.setCapitalMode(true)
                .setEntityLombokModel(true)
                .setNaming(NamingStrategy.underline_to_camel)
                .setSuperEntityClass(BaseEntity.class)
                .setInclude(table)
                .setRestControllerStyle(true);

        TemplateConfig templateConfig = new TemplateConfig();
        //设置不生成controller
        /*templateConfig.setController("");
        templateConfig.setService("templates/service.java.vm");
        templateConfig.setServiceImpl("templates/serviceImpl.java.vm");
        templateConfig.setEntity("templates/entity.java.vm");
        templateConfig.setEntityKt("templates/entity.kt.vm");
        templateConfig.setMapper("templates/mapper.java.vm");
        templateConfig.setXml("templates/mapper.xml.vm");*/

        templateConfig.setController(null);
        templateConfig.setService(null);
        templateConfig.setServiceImpl(null);
        //templateConfig.setXml(null);



        MyAutoGenerator generator = new MyAutoGenerator();
        generator.setExcludeFields("create_user", "create_time", "update_user", "update_time");
        generator.setGlobalConfig(globalConfig);
        generator.setDataSource(dsConfig);
        generator.setPackageInfo(pkConfig);
        generator.setStrategy(stConfig);
        generator.setTemplate(templateConfig);
        generator.execute();
    }
}
