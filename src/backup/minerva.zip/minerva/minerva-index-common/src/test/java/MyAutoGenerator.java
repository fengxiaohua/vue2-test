import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.builder.ConfigBuilder;
import com.baomidou.mybatisplus.generator.config.po.TableField;
import com.baomidou.mybatisplus.generator.config.po.TableInfo;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * 自动代码生成器.
 *
 * @author yinkaifeng
 * @since 2022-06-24 5:53 下午
 */
public class MyAutoGenerator extends AutoGenerator {

    private final Set<String> excludeFields = new HashSet<>();

    @Override
    protected List<TableInfo> getAllTableInfoList(ConfigBuilder config) {
        List<TableInfo> list = super.getAllTableInfoList(config);
        if (!CollectionUtils.isEmpty(list)) {
            for (TableInfo tableInfo : list) {
                Iterator<TableField> it = tableInfo.getFields().iterator();
                while (it.hasNext()) {
                    TableField next = it.next();
                    if (excludeFields.contains(next.getName().toLowerCase())) {
                        it.remove();
                    }
                }
            }
        }
        return list;
    }

    public void setExcludeFields(String... fieldNames) {
        if (Objects.nonNull(fieldNames) && fieldNames.length > 0) {
            for (String name : fieldNames) {
                excludeFields.add(name.toLowerCase());
            }
        }
    }
}
