import mitt, { Emitter } from 'mitt'

type Events = {
  'on-step-finish': any
}

const mitter: Emitter<Events> = mitt()
export default mitter
