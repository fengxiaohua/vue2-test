import mitt, { Emitter } from 'mitt'

type Events = {
  'on-tag-drag': any
  'on-tag-drag-finish': any
  'on-tag-change': any
  'on-tag-click': any
}

const mitter: Emitter<Events> = mitt()
export default mitter
