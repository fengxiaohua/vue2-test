<template>
  <div class="edit-data-modal page-container">
    <!-- 面包屑模式 -->
    <PageTitle>
      <template #breadcrumb>
        <router-link to="/model/dataModel">数据模型</router-link>
        <router-link to="">{{ title }}</router-link>
      </template>
    </PageTitle>

    <FormDetail class="mt-2.5" :can-edit="false" max-height="600px" @on-edit="onEdit(1)">
      <template #content>
        <a-form
          :model="basicForm"
          name="basicInfo"
          autocomplete="off"
          :label-col="{ span: 8 }"
          :wrapper-col="{ span: 16 }"
        >
          <a-col :span="8">
            <a-form-item label="模型名称" name="name">
              <span>{{ basicForm.name }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="模型编号" name="code">
              <span>{{ basicForm.code }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="状态" name="status">
              <span>{{ basicForm.status === 'T' ? '启用' : '禁用' }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="展示顺序" name="sortIndex">
              <span>{{ basicForm.sortIndex }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="备注" name="remark">
              <span>{{ basicForm.remark }}</span>
            </a-form-item>
          </a-col>
        </a-form>
      </template>
    </FormDetail>
    <FormDetail :showExpand="false" :can-edit="false" class="mt-2.5" @on-edit="onEdit(2)">
      <template #content>
        <a-form
          :model="basicSourceInfoForm"
          name="basicSourceInfo"
          autocomplete="off"
          :label-col="{ span: 2 }"
          :wrapper-col="{ span: 22 }"
        >
          <a-col :span="24">
            <a-form-item :title="basicSourceInfoForm.sourceInfo" label="来源信息" name="sourceInfo">
              <span>{{ basicSourceInfoForm.sourceInfo }}</span>
            </a-form-item>
          </a-col>
        </a-form>
      </template>
    </FormDetail>
    <FormDetail :can-edit="false" class="mt-2.5" max-height="600px" @on-edit="onEdit(4)">
      <template #content>
        <a-form
          :model="basicAdvanceInfoForm"
          name="basicAdvanceInfoInfo"
          autocomplete="off"
          :label-col="{ span: 8 }"
          :wrapper-col="{ span: 16 }"
        >
          <a-col :span="8">
            <a-form-item label="模型日期信息项" name="modelDateField">
              <span>{{ basicAdvanceInfoForm.modelDateField }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="日期格式" name="dateFormat">
              <span>{{ basicAdvanceInfoForm.dateFormat }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="模型存储算法" name="saveType">
              <span>{{ basicAdvanceInfoForm.saveType }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="分区字段" name="partitionFiled">
              <span>{{ basicAdvanceInfoForm.partitionFiled }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="数据更新频率" name="frequency">
              <span>{{ basicAdvanceInfoForm.frequency }}</span>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="数据保留策略" name="dataRetainedStrategy">
              <span>{{ basicAdvanceInfoForm.dataRetainedStrategy }}</span>
            </a-form-item>
          </a-col>
        </a-form>
      </template>
    </FormDetail>
    <AddDataModalStep3 class="mt-2.5" />
  </div>
</template>

<script lang="ts" setup>
  // 导入步骤条信息
  import { DataModalType, dataModalDetailTitle } from './components/const'
  import { FormDetail } from '/@/components/FormDetail/index'

  import type { DataModalBaseInfo } from '/@/api/data-model/model/dataModalLibraryModel'
  import type { DataModalAdvanceInfo } from '/@/api/data-model/model/dataModalLibraryModel'

  import { getDictOptions } from '/@/api/util/dict'

  import { getDataSources } from '/@/api/datasource'

  // 使用缓存
  import { useDataModalLibraryWithOut } from '/@/store/modules/dataModalLibrary'
  import AddDataModalStep3 from './components/components/add-data-modal-step3.vue'

  const dataModalLibraryStore = useDataModalLibraryWithOut()

  // 设置面包屑title
  const title = ref<string>(DataModalType.AssetPack)

  const basicForm = reactive<DataModalBaseInfo>({
    name: '',
    code: '',
    status: '',
    sortIndex: 0,
    remark: '',
  })

  const basicSourceInfoForm = reactive<any>({
    sourceInfo: '',
  })

  const basicAdvanceInfoForm = reactive<DataModalAdvanceInfo>({
    modelDateField: '',
    dateFormat: '',
    saveType: '',
    partitionFiled: '',
    frequency: '',
    dataRetainedStrategy: '',
  })

  // 获取路由参数信息
  const router = useRouter()
  const { type } = router.currentRoute.value.query

  // 下拉数据
  // 模型存储算法下拉数据
  let saveTypeOptions
  // 更新评率下拉数据
  let frequencyOptions
  // 数据保留策略
  let dataRetainedStrategyOptions

  // 是否是根据资产包引入
  const isAssetPack = ref<boolean>(false)

  onMounted(async () => {
    title.value = dataModalDetailTitle[type as DataModalType]
    getBaseInfo()
    getSourceInfo()
    getDictSelectOptions()
  })

  watch(
    () => type,
    (val) => {
      isAssetPack.value = val === DataModalType.AssetPack
    },
    { immediate: true },
  )

  const getBaseInfo = () => {
    Object.assign(basicForm, dataModalLibraryStore.getDataModalBaseInfo)
  }

  // 获取来源信息，如果是资产包，那么是 文件夹 => 包
  const getSourceInfo = () => {
    const sourceInfo = dataModalLibraryStore.getDataModalSourceInfo
    basicSourceInfoForm.sourceInfo = sourceInfo?.path || ''
    if (type === DataModalType.SQL) {
      getDataSources({}).then((res) => {
        sourceInfo.dsType = res.content?.find(
          (item) => item.datasourceId === sourceInfo.dataSourceName,
        )?.dsType
      })
    }
  }

  const onEdit = (step) => {
    console.log('查看基本信息')
    router.push(`/model/addDataModal?step=${step}&code=${basicForm.code}&type=${type}`)
  }

  const getDictSelectOptions = () => {
    const storeData = dataModalLibraryStore.getDataModalAdvanceInfo
    getDictOptions({ dictType: 'ALGORITHMS_REQUIRE_MODEL' }).then((res) => {
      saveTypeOptions = res.content
      const value = getOptionsValue(storeData.saveType, saveTypeOptions)
      basicAdvanceInfoForm.saveType = value
      storeData.saveTypeValue = value
    })
    getDictOptions({ dictType: 'UPDATE_FREQUENCY_MODEL' }).then((res) => {
      frequencyOptions = res.content
      const value = getOptionsValue(storeData.frequency, frequencyOptions)
      basicAdvanceInfoForm.frequency = value
      storeData.frequencyValue = value
    })
    getDictOptions({ dictType: 'RETENTION_STRATEGY' }).then((res) => {
      dataRetainedStrategyOptions = res.content
      const value = getOptionsValue(storeData.dataRetainedStrategy, dataRetainedStrategyOptions)
      basicAdvanceInfoForm.dataRetainedStrategy = value
      storeData.dataRetainedStrategyValue = value
    })
    basicAdvanceInfoForm.modelDateField = storeData.modelDateField
    basicAdvanceInfoForm.dateFormat = storeData.dateFormat
    basicAdvanceInfoForm.partitionFiled = storeData.partitionFiled
  }

  const getOptionsValue = (value, options) => {
    return options?.find((item) => item.dictCode === value)?.dictValue || value
  }
</script>
<style lang="less" scoped>
  .edit-data-modal {
    :deep(.ant-form) {
      .ant-form-item {
        width: auto !important;

        .ant-form-item-control-input-content {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
    }

    :deep(.form-detail) {
      justify-content: space-between;

      .content {
        max-width: 85% !important;
      }
    }

    :deep(.page-title__action) {
      display: flex;

      button {
        display: flex;
        align-items: center;
        justify-content: center;
        padding-right: 10px;
        padding-left: 10px;
        min-width: 70px;
        height: 26px;
        border-color: #ff794a;
        border-radius: 32px;
        // color: #ff794a;
        font-size: 13px;
      }
    }
  }
</style>
