<template>
  <div>
    <BasicTable
      @register="registerTable"
      :rowSelection="{ type: 'checkbox', selectedRowKeys, onChange: onSelectChange }"
    >
      <!-- 页面标题&操作 -->
      <template #pageTitle>
        <a-button type="primary" v-permission="'b_dimensionManage_add'" @click="addDimension">
          <template #icon><Icon icon="plus" /></template>{{ p('b_dimensionManage_add') }}
        </a-button>
      </template>

      <!-- 页面查询筛选 -->
      <template #pageFilters>
        <a-input
          placeholder="维度名称"
          v-model:value="searchInfo.name"
          allow-clear
          @pressEnter="fetch"
        />
        <a-input
          placeholder="维度编号"
          v-model:value="searchInfo.code"
          allow-clear
          @pressEnter="fetch"
        />
        <FilterPopover @reset="resetForm">
          <FilterPopoverItem label="状态">
            <a-select placeholder="请选择状态" v-model:value="searchInfo.status" allow-clear>
              <a-select-option :key="'T'">启用</a-select-option>
              <a-select-option :key="'F'">禁用</a-select-option>
            </a-select>
          </FilterPopoverItem>
          <FilterPopoverItem label="创建方式">
            <a-select
              placeholder="请选择创建方式"
              allow-clear
              v-model:value="searchInfo.createType"
            >
              <a-select-option :key="'1'">手动创建</a-select-option>
            </a-select>
          </FilterPopoverItem>
        </FilterPopover>
        <a-button type="primary" @click="fetch">查询</a-button>
      </template>

      <!-- 页面操作功能 -->
      <template #pageActions>
        <ActionButton @click="importDimension">{{ p('b_dimensionManage_import') }}</ActionButton>
        <ActionButton
          :disabled="selectedRowKeys.length === 0"
          disabledText="请选择要操作的数据"
          :loading="isDownloading"
          @click="download"
        >
          {{ p('b_dimensionManage_export') }}
        </ActionButton>
        <ActionButton
          :disabled="selectedRowKeys.length === 0"
          disabledText="请选择要操作的数据"
          @click="batchDel"
        >
          {{ p('b_dimensionManage_batch_del') }}
        </ActionButton>
      </template>

      <!-- 表格操作功能 -->
      <template #action="{ record }">
        <TableAction :actions="getTableActions(record)" />
      </template>

      <!-- 表格列自定义 -->
      <template #bodyCell="{ column, record }">
        <template v-if="column.dataIndex === 'name'">
          <router-link :to="`dimensionDetail?code=${record.code}`">{{ record.name }} </router-link>
        </template>
        <template v-if="column.dataIndex == 'status'">
          <span :class="record.status === '启用' ? 'success-color' : 'disabled-color'">{{
            record.status
          }}</span>
        </template>
      </template>
    </BasicTable>
    <!-- 导入组件 -->
    <ImportModal
      v-if="importVisible"
      v-model:importVisible="importVisible"
      :templateApi="ExportTemplateApi"
      :uploadApi="ImportExcelApi"
      fileName="维度导入模板.xlsx"
      errField="checkMsg"
      @import-success="importSuccess"
    />
  </div>
</template>

<script lang="ts">
  // 表格插件
  import { useTable, ActionItem } from '/@/components/Table'

  // 表格中的类型
  import type { BasicColumn, Key } from '/@/components/Table/src/types/table'

  // 表格列配置
  const columns: BasicColumn[] = [
    {
      title: '维度名称',
      resizable: true,
      dataIndex: 'name',
      minWidth: 150,
      width: 150,
      align: 'left',
      fixed: 'left',
    },
    {
      title: '维度编号',
      resizable: true,
      dataIndex: 'code',
      minWidth: 150,
      width: 150,
      align: 'left',
    },
    {
      title: '维度描述',
      resizable: true,
      dataIndex: 'described',
      minWidth: 120,
      width: 120,
    },
    {
      title: '状态',
      resizable: true,
      dataIndex: 'status',
      minWidth: 120,
      width: 120,
    },
    {
      title: '展示顺序',
      resizable: true,
      dataIndex: 'sortIndex',
      minWidth: 120,
      width: 120,
    },
    {
      title: '备注',
      resizable: true,
      dataIndex: 'remark',
      minWidth: 200,
      width: 200,
    },
    {
      title: '维度值创建方式',
      resizable: true,
      dataIndex: 'createType',
      minWidth: 120,
      width: 120,
    },
    {
      title: '创建人',
      resizable: true,
      dataIndex: 'createUserName',
      minWidth: 180,
      width: 180,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      minWidth: 180,
      width: 180,
      sorter: true,
      resizable: true,
    },
    {
      title: '修改人',
      resizable: true,
      dataIndex: 'updateUserName',
      minWidth: 180,
      width: 180,
    },
    {
      title: '修改时间',
      resizable: true,
      dataIndex: 'updateTime',
      minWidth: 180,
      width: 180,
    },
  ]

  // API
  import {
    GetDimensionByPageApi,
    // DeleteDimensionApi,
    BatchDeleteDimensionApi,
    ExportApi,
    ExportTemplateApi,
    ImportExcelApi,
  } from '/@/api/dimension-manage/dimension'
  import type {
    DimensionInstance,
    GetDimensionParams,
  } from '/@/api/dimension-manage/model/dimensionModel'

  import { usePermission } from '/@/hooks/web/usePermission'

  import { message, Modal } from 'ant-design-vue'
  // p：根据资源权限标识获取资源名称
  const { p, isActionColumnHidden } = usePermission()

  import { useCreateVNode } from '/@/hooks/web/useCreateVNode'
  const { batchPrompt } = useCreateVNode()

  // 导入组件

  // 导入路由组件
  import { useRouter } from 'vue-router'

  import useDownload from '/@/hooks/web/useDownload'

  export default defineComponent({
    name: 'DimensionManage',
    components: {},
    setup() {
      const initSearchInfo = () => {
        return {
          name: '',
          code: '',
          status: undefined,
          createType: undefined,
        }
      }
      // 查询筛选参数（根据Api请求模型）
      const searchInfo = reactive<GetDimensionParams>(initSearchInfo())

      // 重制过滤筛选表单
      const resetForm = () => {
        Object.assign(searchInfo, initSearchInfo())
      }

      // 操作列配置及所有权限
      const getTableActions = (record?) => {
        // 操作列方法
        return [
          {
            label: '查看详情',
            icon: 'filesearch',
            permission: 'b_dimensionManage_detail', // 根据权限控制是否显示: 有权限，会显示
            onClick: () => {
              detail(record)
            },
          },
          {
            label: '删除',
            icon: 'delete',
            permission: 'b_dimensionManage_del', // 根据权限控制是否显示: 有权限，会显示
            onClick: () => {
              del(record)
            },
          },
        ] as ActionItem[]
      }

      // 表格组件配置
      const [registerTable, { reload }] = useTable({
        pageTitle: '维度管理', // 页面标题
        api: GetDimensionByPageApi, // API命名后缀明确如：getDimensionByPage
        searchInfo, // 查询参数
        rowKey: 'code',
        // 默认排序字段
        defSort: {
          field: 'createTime', // 排序字段
          order: 'ascend', // 排序方式 ascend | descend
        },
        useSearchForm: true, // 是否使用查询过滤器
        showIndexColumn: false, // 是否展示序号
        columns, // 表格列配置
        // 操作列配置
        actionColumn: {
          defaultHidden: isActionColumnHidden(getTableActions()), // 操作列判断权限是否隐藏
        },
      })

      // 查询
      const fetch = () => {
        reload({ page: 1, searchInfo })
      }

      // 选中项keys
      const selectedRowKeys = ref<Key[]>([])
      // 选中项rows
      const selectedRow = ref<any[]>([])

      // 行选中事件
      function onSelectChange(keys: Key[], rows: any) {
        selectedRowKeys.value = keys
        selectedRow.value = rows
      }

      /**
       * @description: 批量删除
       */
      const batchDel = () => {
        const selectedContent = toRaw(selectedRow.value).map((item) => item.name)
        Modal.confirm({
          title: `是否删除以下内容（${selectedContent.length}项）?`,
          content: batchPrompt(selectedContent),
          async onOk() {
            await BatchDeleteDimensionApi({ code: selectedRowKeys.value as string[] })
              .then(() => {
                message.success('批量删除度量成功')
                fetch()
              })
              .catch(() => {
                message.error('批量删除度量失败')
              })
          },
          onCancel() {
            console.log('Cancel')
          },
          class: 'test',
        })
      }

      /**
       * @description: 删除
       */
      const del = (record: DimensionInstance) => {
        Modal.confirm({
          title: '提示',
          content: `删除维度，将同步删除维度值列表信息，确定删除维度"${record.name}"吗？`,
          async onOk() {
            await BatchDeleteDimensionApi({ code: record.code })
              .then(() => {
                message.success('删除维度成功')
                fetch()
              })
              .catch(() => {
                message.error('删除维度失败')
              })
          },
        })
      }

      const importVisible = ref<boolean>(false) // 导入弹窗

      /**
       * @description: 导入
       */
      const importDimension = () => {
        importVisible.value = true
      }

      /**
       * @description: 导入成功回调
       */
      const importSuccess = () => {
        reload({ page: 1, searchInfo })
      }

      const isDownloading = ref<boolean>(false)

      /**
       * @description: 导出
       */
      const download = async () => {
        const selectedIds = toRaw(selectedRowKeys.value)
        isDownloading.value = true
        await ExportApi({ type: '1', modelCodes: selectedIds as string[] })
          .then((res) => {
            useDownload(res, '维度信息.xlsx')
          })
          .finally(() => {
            isDownloading.value = false
          })
      }

      // 定义路由变量
      const router = useRouter()

      /**
       * @description: 新增维度
       */
      const addDimension = () => {
        // 操作路由
        router.push({
          name: 'addDimension',
        })
      }

      /**
       * @description: 查看详情
       */
      const detail = (record: DimensionInstance) => {
        // 操作路由
        router.push({
          name: 'dimensionDetail',
          query: { code: record.code },
        })
      }

      // 返回的变量、函数
      return {
        searchInfo,
        selectedRowKeys,
        p,
        registerTable,
        getTableActions,
        fetch,
        resetForm,
        onSelectChange,
        batchDel,
        importVisible,
        importDimension,
        importSuccess,
        addDimension,
        isDownloading,
        download,
        ExportTemplateApi,
        ImportExcelApi,
      }
    },
  })
</script>
