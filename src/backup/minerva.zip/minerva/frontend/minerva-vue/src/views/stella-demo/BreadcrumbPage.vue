<template>
  <div class="page-container">
    <!-- 面包屑模式 -->
    <PageTitle>
      <template #breadcrumb>
        <router-link to="/home">首页</router-link>
        <router-link to="/index/library">指标库</router-link>
        <router-link to="">面包屑样例</router-link>
      </template>
      <a-button type="primary" v-permission="'b_user_new'">
        <template #icon><Icon icon="plus" /></template>{{ p('b_user_new') }}
      </a-button>
    </PageTitle>
    <br />
    <!-- 传统title模式 -->
    <PageTitle title="首页">
      <a-button type="primary" v-permission="'b_user_new'">
        <template #icon><Icon icon="plus" /></template>{{ p('b_user_new') }}
      </a-button>
    </PageTitle>
  </div>
</template>

<script lang="ts">
  import { usePermission } from '/@/hooks/web/usePermission'
  // p：根据资源权限标识获取资源名称
  const { p } = usePermission()
  export default defineComponent({
    setup() {
      return {
        p,
      }
    },
  })
</script>

<style scoped></style>
