<template>
  <div class="page-container">
    <PageTitle title="单选" />
    <StellaSelect
      v-model:value="singleValue"
      :tree-data="functionData"
      allowClear
      placeholder="请选择什么"
    />
    <span>singleValue: {{ singleValue }}</span>
    <PageTitle title="多选" class="mt-50" />
    <StellaSelect
      v-model:value="multipleValue"
      multiple
      :tree-data="functionData"
      allowClear
      selectWidth="250px"
      placeholder="请选择什么"
    />
    <StellaSelect
      v-model:value="multipleValue"
      multiple
      :tree-data="functionData"
      allowClear
      :maxTagCount="2"
      selectWidth="250px"
      placeholder="请选择什么"
    />
    <span>multipleValue: {{ multipleValue }}</span>
  </div>
</template>

<script lang="ts">
  import { TreeProps } from 'ant-design-vue'
  import { GetFuntionsApi } from '/@/api/index/library'

  export default defineComponent({
    name: 'StellaSelectPage',
    setup() {
      const functionData = ref<TreeProps['treeData']>()
      const singleValue = ref<any>()
      const multipleValue = ref<any>()

      // 获取函数列表
      const getFuntions = () => {
        GetFuntionsApi().then((res) => {
          functionData.value = res.content.map((item) => {
            item.title = item.categoryCN
            item.key = item.categoryEN
            item.children = item.functionList.map((f) => {
              f.title = f.funCN
              f.key = f.funEN
              return f
            })
            delete item.categoryCN
            delete item.categoryEN
            delete item.functionList
            return item
          })
        })
      }

      onMounted(() => {
        getFuntions()
      })

      return { functionData, singleValue, multipleValue }
    },
  })
</script>

<style scoped></style>
