<template>
  <div>
    <Resizable line-class="opacity-0" :min="250" :max="600" :width="320" style="height: 300px">
      <template #start>
        <div style="background-color: #00000026; height: 100%; width: 100%; display: flex">
          <span style="margin: auto">左方或者上方内容</span>
        </div>
      </template>

      <template #end>
        <div style="background-color: #00000056; height: 100%; width: 100%; display: flex">
          <span style="margin: auto">右方或者下方内容</span>
        </div>
      </template>
    </Resizable>
  </div>
</template>
