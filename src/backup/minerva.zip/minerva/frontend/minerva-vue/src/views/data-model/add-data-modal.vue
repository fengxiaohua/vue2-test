<template>
  <div class="page-container asset-pack h-full flex flex-col">
    <!-- 面包屑模式 -->
    <PageTitle>
      <template #breadcrumb>
        <router-link to="/model/dataModel">数据模型</router-link>
        <router-link :to="'/model/editDataModal?type=' + type + '&code=' + code" v-if="code"
          >数据模型详情</router-link
        >
        <router-link to="">{{ title }}</router-link>
      </template>
      <a-button v-if="code" shape="round" @click="onCancelToEdit"> 取消 </a-button>
      <a-button
        v-if="code"
        shape="round"
        :loading="isConfirmLoading"
        type="primary"
        @click="onConfirmToEdit"
      >
        确定
      </a-button>
    </PageTitle>

    <div class="flex-1 flex h-0 mt-2">
      <AddDataModalStep1
        ref="addDataModalStep1Ref"
        :step="steps[current - 1]"
        :isAssetPack="isAssetPack"
        :class="[
          'asset-pack-container',
          'w-full',
          'h-full',
          'overflow-hidden',
          isAssetPack && !code ? 'w-1/2 mr-4' : 'background-img',
        ]"
        v-show="current === 1"
      />
      <AddDataModalStep2
        :step="steps[isAssetPack ? current : current - 1]"
        :class="[
          'asset-pack-container w-full h-full overflow-hidden',
          isAssetPack && !code ? 'mr-4' : 'background-img',
        ]"
        v-if="isAssetPack && !code ? current === 1 : current === 2"
      />
      <AddDataModalStep3
        :step="steps[current - 1]"
        :class="['asset-pack-container w-full h-full overflow-hidden', !code ? 'mr-4' : '']"
        v-if="current === 3"
      />
      <AddDataModalStep4
        :step="steps[current - 1]"
        ref="addDataModalStep4Ref"
        :class="[
          'asset-pack-container background-img w-full h-full overflow-hidden',
          !code ? 'mr-4' : '',
        ]"
        v-show="current === 4"
      />
      <StellaStep
        v-if="!code"
        :steps="steps"
        :is-step-loading="isStepLoading"
        :current="current"
        @on-cancel="onCancel"
        @on-next="onNext"
        @on-prev="onPrev"
        @on-complete="onComplete"
      />
    </div>
  </div>
</template>

<script lang="ts" setup>
  import AddDataModalStep1 from './components/components/add-data-modal-step1.vue'
  import AddDataModalStep2 from './components/components/add-data-modal-step2.vue'
  import AddDataModalStep3 from './components/components/add-data-modal-step3.vue'
  import AddDataModalStep4 from './components/components/add-data-modal-step4.vue'

  // 使用缓存
  import { useDataModalLibraryWithOut } from '/@/store/modules/dataModalLibrary'

  // 导入类型
  import type {
    AddAssetPackModalParams,
    UpdateAssetPackModalParams,
  } from '/@/api/data-model/model/addAssetPackModel'

  // 导入接口
  import {
    PostAddDataModal,
    createTable,
    validateSQL,
    PutEditDataModal,
    getParseField,
  } from '/@/api/data-model'

  // 导入步骤条信息
  import {
    DataModalType,
    steps,
    dataModalTitle,
    dataModalAddType,
    dataModalEditTitle,
  } from './components/const'
  import { useRouter } from 'vue-router'
  import { message } from 'ant-design-vue'
  const router = useRouter()
  // 设置步骤条
  const current = ref<number>(1)
  // 设置面包屑title
  const title = ref<string>(DataModalType.AssetPack)
  // 获取路由参数信息
  const { step, type, code } = router.currentRoute.value.query
  // 是否是根据资产包引入
  const isAssetPack = ref<boolean>(false)
  // step1,step4引用
  const addDataModalStep1Ref = ref<any>(null)
  const addDataModalStep4Ref = ref<any>(null)
  // 提交按钮loading
  const isConfirmLoading = ref<boolean>(false)
  // step按钮loading
  const isStepLoading = ref(false)
  // 使用缓存
  const dataModalLibraryStore = useDataModalLibraryWithOut()

  onMounted(() => {
    current.value = typeof step === 'string' ? parseInt(step) : 1
    title.value = code
      ? dataModalEditTitle[type as DataModalType]
      : dataModalTitle[type as DataModalType]
  })

  watch(
    current,
    (value) => {
      router.push({ query: { step: value.toString(), type, code } })
    },
    {
      immediate: true,
    },
  )

  watch(
    () => type,
    (val) => {
      isAssetPack.value = val === DataModalType.AssetPack
    },
    { immediate: true },
  )

  const onNext = async (e) => {
    const dataModalSourceInfo = dataModalLibraryStore.getDataModalSourceInfo
    if (e === 1) {
      // 第一步校验
      const result = await addDataModalStep1Ref.value.onFinish()
      if (result) {
        if (isAssetPack.value) {
          dataModalSourceInfo?.assetCode ? (current.value = e + 2) : message.warning('请选择资产包')
        } else {
          current.value = e + 1
        }
      }
    }
    // 第二步检查传参
    else if (e === 2) {
      if (type === DataModalType.SQL) {
        const { sqlContent, dataSourceName } = dataModalSourceInfo
        if (sqlContent) {
          validateSQL({ dsName: dataSourceName, sql: sqlContent }).then(() => {
            current.value = e + 1
          })
          // current.value = e + 1 // 接口不同先通过
        } else {
          message.warning('请选择表或视图生成SQL语句')
        }
      }
    } else if (e === 3) {
      const { fieldMapping } = dataModalLibraryStore.getDataModalEditFieldInfo
      const res = fieldMapping?.some((item) => !item.fieldNameCn || !item.fieldNameEn)
      res ? message.warning('请输入缺失的字段名称') : (current.value = e + 1)
    }

    console.log('onNext', e)
  }

  const onPrev = (e) => {
    if (e === 3 && isAssetPack.value) {
      current.value = e - 2
    } else {
      current.value = e - 1
    }
    console.log('onPre', e)
  }

  // 完成（清空pinia缓存）
  const onComplete = async () => {
    const result = await addDataModalStep4Ref.value.onFinish()
    if (result) {
      // 调用接口新增模型
      addDataModal(type as DataModalType)
    } else {
      return
    }
  }

  // 取消（清空pinia缓存）
  const onCancel = (e) => {
    console.log('oncancel', e)
    router.push('/model/dataModel')
    dataModalLibraryStore.clear()
  }

  // 取消 到编辑页面
  const onCancelToEdit = () => {
    if (step === '2') {
      // 如果是资产包/SQL引入 需要把缓存地上一步选择内容拿出来更新,如果获取不到，说明没有选新数据，那么拿原来数据即可
      const dataModalSourceInfo = dataModalLibraryStore.getDataModalSourceInfo
      const preDataModalSourceInfo = dataModalSourceInfo?.preDataModalSourceInfo
      dataModalLibraryStore.setDataModalSourceInfo(
        preDataModalSourceInfo ? preDataModalSourceInfo : dataModalSourceInfo,
      )
    }
    router.push(`/model/editDataModal?type=${type}&code=${code}`)
  }

  // 确定 到编辑页面
  const onConfirmToEdit = async () => {
    let flag = true
    // 第一步校验
    const result1 = await addDataModalStep1Ref.value.onValiditeName()
    flag = flag && result1
    result1 || message.warning('请确认模型基本信息是否填写正确')
    // 第二步校验
    if (type === DataModalType.SQL) {
      const dataModalSourceInfo = dataModalLibraryStore.getDataModalSourceInfo
      const { sqlContent, dataSourceName } = dataModalSourceInfo
      const result2 = await validateSQL({ dsName: dataSourceName, sql: sqlContent })
        .then(() => {
          return true
        })
        .catch((e) => {
          message.warning(e.msg)
          return false
        })
      flag = flag && result2
    }
    if (step === '2') {
      // 获取第三步数据
      await getParseField(getTableParams(type))
        .then((res) => {
          dataModalLibraryStore.setDataModalEditFieldInfo(res.content || {})
          flag = flag && true
        })
        .catch(() => {
          flag = flag && false
        })
    }
    // 第四部校验
    const result4 = await addDataModalStep4Ref.value.onFinish()
    flag = flag && result4
    result4 || message.warning('请确认模型高级属性是否填写正确')
    // 所有校验通过，发请求更新数据
    if (flag) {
      await updateDataModal(type as DataModalType)
    }
  }

  function getTableParams(type) {
    const dataModalSourceInfo = dataModalLibraryStore.getDataModalSourceInfo
    const dataModalBaseInfo = dataModalLibraryStore.getDataModalBaseInfo
    console.log(dataModalSourceInfo, dataModalBaseInfo)
    let params = {}
    switch (type) {
      case DataModalType.AssetPack:
        params = {
          content: JSON.stringify({ apCode: dataModalSourceInfo.assetCode }),
          modelCode: dataModalBaseInfo.code,
          type: 1,
        }
        break
      case DataModalType.SQL:
        params = {
          content: JSON.stringify({
            dataSourceName: dataModalSourceInfo.dataSourceName,
            sourceScheme: dataModalSourceInfo.sourceSchema,
            sqlContent: dataModalSourceInfo.sqlContent,
          }),
          modelCode: dataModalBaseInfo.code,
          type: 3,
        }
        break
      default:
        break
    }
    return params
  }

  const addDataModal = (type: DataModalType) => {
    isStepLoading.value = true
    // 获取第三部信息
    const { fieldMapping, groundDatabaseScheme, groundTableEn, groundDatabaseCode } =
      dataModalLibraryStore.getDataModalEditFieldInfo
    // 获取第二步信息
    const dataModalSourceInfo = dataModalLibraryStore.getDataModalSourceInfo
    // 获取第一步信息
    const dataModalBaseInfo = dataModalLibraryStore.getDataModalBaseInfo
    // 获取第四部信息
    const dataModalAdvanceInfo = dataModalLibraryStore.getDataModalAdvanceInfo
    const modelInfoAddVo = {
      ...dataModalAdvanceInfo,
      ...dataModalBaseInfo,
      groundDatabaseCode: dataModalSourceInfo.dataSourceName,
      groundTableEn,
      type: `${dataModalAddType[type]}`,
      status: `${dataModalBaseInfo.status}`,
      sourcePlatform: 'MODEL', // 默认 MODEL
    }

    const params: AddAssetPackModalParams = {
      minervaModelFieldInfoAddVos: fieldMapping || [],
      // modelContent: JSON.stringify({ apCode: 'ZCB_20220524_0009' }), // 测试用
      modelContent: '',
      modelInfoAddVo: { ...modelInfoAddVo, typeContentCode: dataModalBaseInfo.code },
    }
    switch (type) {
      case DataModalType.AssetPack:
        params.modelContent = JSON.stringify({ apCode: dataModalSourceInfo.assetCode })
        params.modelInfoAddVo.groundDatabaseCode = groundDatabaseCode
        params.modelInfoAddVo.groundDatabaseScheme = groundDatabaseScheme
        break
      case DataModalType.SQL:
        params.modelContent = JSON.stringify({
          dataSourceName: dataModalSourceInfo.dataSourceName,
          sourceScheme: dataModalSourceInfo.sourceSchema,
          sqlContent: dataModalSourceInfo.sqlContent,
          dsType: dataModalSourceInfo.dsType,
        })
        break
      default:
        break
    }
    PostAddDataModal(params)
      .then(() => {
        const createParams = {
          minervaModelFieldInfoVos: params.minervaModelFieldInfoAddVos,
          modelCode: params.modelInfoAddVo.code,
        }
        createTable(createParams)
          .then(() => {
            router.push('/model/dataModel')
            dataModalLibraryStore.clear()
          })
          .finally(() => {
            isStepLoading.value = false
          })
      })
      .catch(() => {
        isStepLoading.value = false
      })
  }

  const updateDataModal = async (type: DataModalType) => {
    isConfirmLoading.value = true
    // 获取第三部信息
    const { groundDatabaseScheme, groundTableEn, groundDatabaseCode } =
      dataModalLibraryStore.getDataModalEditFieldInfo
    // 获取第二步信息
    const dataModalSourceInfo = dataModalLibraryStore.getDataModalSourceInfo
    // 获取第一步信息
    const dataModalBaseInfo = dataModalLibraryStore.getDataModalBaseInfo
    // 获取第四部信息
    const dataModalAdvanceInfo = dataModalLibraryStore.getDataModalAdvanceInfo
    const modelInfoAddVo = {
      ...dataModalAdvanceInfo,
      ...dataModalBaseInfo,
      groundDatabaseCode: dataModalSourceInfo.dataSourceName,
      groundTableEn,
      type: `${dataModalAddType[type]}`,
      status: `${dataModalBaseInfo.status}`,
      sourcePlatform: 'MODEL', // 默认 MODEL
    }

    const params: UpdateAssetPackModalParams = {
      // minervaModelFieldInfoUptVos: fieldMapping || [], 现在调用第1.2.4步骤不需要这个参数
      // modelContent: JSON.stringify({ apCode: 'ZCB_20220524_0009' }), // 测试用
      modelContent: '',
      modelInfoUptVo: { ...modelInfoAddVo, typeContentCode: dataModalBaseInfo.code },
    }
    switch (type) {
      case DataModalType.AssetPack:
        params.modelContent = JSON.stringify({ apCode: dataModalSourceInfo.assetCode })
        params.modelInfoUptVo.groundDatabaseCode = groundDatabaseCode
        params.modelInfoUptVo.groundDatabaseScheme = groundDatabaseScheme
        break
      case DataModalType.SQL:
        params.modelContent = JSON.stringify({
          dataSourceName: dataModalSourceInfo.dataSourceName,
          sourceScheme: dataModalSourceInfo.sourceSchema,
          sqlContent: dataModalSourceInfo.sqlContent,
          dsType: dataModalSourceInfo.dsType,
        })
        break
      default:
        break
    }
    isConfirmLoading.value = true
    await PutEditDataModal(params)
      .then(() => {
        router.push(`/model/editDataModal?type=${type}&code=${code}`)
      })
      .finally(() => {
        isConfirmLoading.value = false
      })
  }
</script>

<style lang="less" scoped>
  .asset-pack {
    &-container {
      overflow: auto;
      border: 1px solid #eee;
      border-radius: 6px;
      box-shadow: 0 0 10px #eee;
    }

    .background-img {
      background-image: url('/@/assets/images/index/card-bg.png');
      background-position: 100% 0;
      background-repeat: no-repeat;
    }
  }
</style>
