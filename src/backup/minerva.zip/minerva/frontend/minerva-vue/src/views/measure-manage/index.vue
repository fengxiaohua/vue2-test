<template>
  <div class="page-container">
    <!-- 页面标题&操作 -->
    <PageTitle title="度量管理">
      <a-button type="primary" v-permission="'b_measureManage_add'" @click="addMeasure">
        <template #icon><Icon icon="plus" /></template>{{ p('b_measureManage_add') }}
      </a-button>
    </PageTitle>
    <!-- 页面查询筛选 -->
    <PageHandle>
      <!-- 筛选项 -->
      <template #filters>
        <a-input
          placeholder="度量名称"
          v-model:value="searchInfo.name"
          allow-clear
          @pressEnter="fetch"
        />
        <a-input
          placeholder="度量编号"
          v-model:value="searchInfo.code"
          allow-clear
          @pressEnter="fetch"
        />
        <FilterPopover @reset="resetForm">
          <FilterPopoverItem label="状态">
            <a-select placeholder="请选择状态" v-model:value="searchInfo.status" allow-clear>
              <a-select-option :key="'T'">启用</a-select-option>
              <a-select-option :key="'F'">禁用</a-select-option>
            </a-select>
          </FilterPopoverItem>
          <FilterPopoverItem label="度量单位">
            <a-input
              placeholder="度量单位"
              v-model:value="searchInfo.measuringUnit"
              allow-clear
              @pressEnter="fetch"
            />
          </FilterPopoverItem>
        </FilterPopover>
        <a-button type="primary" @click="fetch">查询</a-button>
      </template>
      <!-- 操作栏 -->
      <template #actions>
        <div :class="{ 'action-box': true, transition: isBatch }">
          <ActionButton @click="importMeasure">
            <template #icon><Icon icon="upload" /></template>
            {{ p('b_measureManage_import') }}
          </ActionButton>
          <ActionButton
            :disabled="selectedRowKeys.length === 0"
            disabledText="请选择要操作的数据"
            @click="download"
            :loading="isDownloading"
          >
            <template #icon><Icon icon="download" /></template>
            {{ p('b_measureManage_export') }}
          </ActionButton>
          <ActionButton
            :disabled="selectedRowKeys.length === 0"
            disabledText="请选择要操作的数据"
            @click="batchDelete"
          >
            <template #icon><Icon icon="delete" /></template>
            {{ p('b_measureManage_delete') }}
          </ActionButton>
          <ActionButton @click="onBatch">
            <template #icon>
              <Icon
                icon="xiangzuo"
                size="12"
                :class="{ 'before-rotate': !isBatch, 'after-rotate': isBatch }"
              />
            </template>
            {{ p('b_measureManage_batch') }}
          </ActionButton>
        </div>
      </template>
    </PageHandle>
    <!-- 卡片列表 -->
    <div class="measure-list" v-loading="isLoading">
      <a-row :gutter="[20, 20]" v-if="measureList.length > 0">
        <a-col v-for="item in measureList" :key="item.id" :md="12" :lg="8" :xl="6">
          <MeasureCard
            :item="item"
            :isBatch="isBatch"
            @checked-change="checkedChange"
            @on-update-measure="onMeasureConfirm"
          />
        </a-col>
      </a-row>
      <Empty v-else class="empty" />
    </div>
    <!-- 导入组件 -->
    <ImportModal
      v-if="importVisible"
      v-model:importVisible="importVisible"
      :templateApi="ExportTemplateApi"
      :uploadApi="ImportExcelApi"
      fileName="度量导入模板.xlsx"
      errField="checkMsg"
      @import-success="importSuccess"
    />
    <!-- 新增组件 -->
    <MeasureModal
      v-if="addVisible"
      v-model:visible="addVisible"
      @on-add-confirm="onMeasureConfirm"
    />
  </div>
</template>

<script lang="ts">
  // 卡片组件
  import MeasureCard from './components/MeasureCard.vue'
  // 新增组件
  import MeasureModal from './components/MeasureModal.vue'
  // 引入API
  import {
    GetMeasureApi,
    BatchDeleteMeasureApi,
    ExportApi,
    ExportTemplateApi,
    ImportExcelApi,
  } from '/@/api/measure-manage/index'
  // 引入类型模型
  import { GetMeasureListParams, MeasureInstance } from '/@/api/measure-manage/model/measure'

  import { usePermission } from '/@/hooks/web/usePermission'

  import { message, Modal } from 'ant-design-vue'

  import { useCreateVNode } from '/@/hooks/web/useCreateVNode'
  const { batchPrompt } = useCreateVNode()

  // p：根据资源权限标识获取资源名称
  const { p } = usePermission()

  import useDownload from '/@/hooks/web/useDownload'

  export default defineComponent({
    name: 'MeasureManage',
    components: {
      MeasureCard,
      MeasureModal,
    },
    setup() {
      const initSearchInfo = () => {
        return {
          name: '',
          code: '',
          measuringUnit: '',
          status: undefined,
        }
      }
      // 查询筛选参数（根据Api请求模型）
      const searchInfo = reactive<GetMeasureListParams>(initSearchInfo())

      // 重制过滤筛选表单
      const resetForm = () => {
        Object.assign(searchInfo, initSearchInfo())
      }

      const isLoading = ref<boolean>(false)

      // 度量列表
      const measureList = ref<Array<MeasureInstance>>([])

      /**
       * @description: 获取度量列表
       * @param {*} searchInfo
       */
      const getMeasureList = async (searchInfo: GetMeasureListParams) => {
        isLoading.value = true
        await GetMeasureApi(searchInfo)
          .then((res) => {
            const { content } = res
            content.forEach((item) => {
              item.checked = false
            })
            measureList.value = content
          })
          .finally(() => {
            isLoading.value = false
          })
      }

      // 查询列表的方法provide出去，供孙子组件使用
      provide('getMeasureList', getMeasureList)

      // 新增弹窗visible
      const addVisible = ref<boolean>(false)

      /**
       * @description: 新增度量
       */
      const addMeasure = () => {
        addVisible.value = true
      }

      /**
       * @description: 度量信息提交回调
       */
      const onMeasureConfirm = () => {
        getMeasureList(searchInfo)
      }

      /**
       * @description: 筛选查询
       */
      const fetch = () => {
        getMeasureList(searchInfo)
      }

      // 是否开启批量操作
      const isBatch = ref<boolean>(false)

      /**
       * @description: 批量操作状态
       */
      const onBatch = () => {
        isBatch.value = !isBatch.value
      }

      // 导入弹窗
      const importVisible = ref<boolean>(false)

      /**
       * @description: 导入
       */
      const importMeasure = () => {
        importVisible.value = true
      }

      /**
       * @description: 导入成功回调
       */
      const importSuccess = () => {
        getMeasureList(searchInfo)
      }

      // 选中项keys
      const selectedRowKeys = ref<any[]>([])
      // 选中项rows
      const selectedRow = ref<any[]>([])

      /**
       * @description: 卡片勾选回调
       */
      const checkedChange = (item) => {
        item.checked = !item.checked
        if (item.checked) {
          selectedRow.value.push(item)
          selectedRowKeys.value.push(item.code)
        } else {
          const findIndex = selectedRow.value.findIndex((val) => val.code === item.code)
          selectedRow.value.splice(findIndex, 1)
          selectedRowKeys.value.splice(findIndex, 1)
        }
      }

      const isDownloading = ref<boolean>(false)

      /**
       * @description: 导出
       */
      const download = async () => {
        const selectedIds = toRaw(selectedRowKeys.value)
        isDownloading.value = true
        await ExportApi({ codes: selectedIds })
          .then((res) => {
            useDownload(res, '度量信息.xlsx')
          })
          .finally(() => {
            isDownloading.value = false
          })
      }

      /**
       * @description: 批量删除
       */
      const batchDelete = () => {
        const selectedContent = toRaw(selectedRow.value).map((item) => item.name)
        Modal.confirm({
          title: `是否删除以下内容（${selectedContent.length}项）?`,
          content: batchPrompt(selectedContent),
          async onOk() {
            await BatchDeleteMeasureApi({ code: selectedRowKeys.value }).then(() => {
              message.success('批量删除度量成功')
              getMeasureList(searchInfo)
            })
          },
          onCancel() {
            console.log('Cancel')
          },
          class: 'test',
        })
      }

      /**
       * @description: 挂载初始化列表
       */
      onMounted(() => {
        getMeasureList(searchInfo)
      })

      return {
        p,
        addVisible,
        addMeasure,
        onMeasureConfirm,
        searchInfo,
        selectedRowKeys,
        selectedRow,
        fetch,
        isLoading,
        getMeasureList,
        resetForm,
        measureList,
        isBatch,
        onBatch,
        importVisible,
        importMeasure,
        importSuccess,
        checkedChange,
        batchDelete,
        isDownloading,
        download,
        ExportTemplateApi,
        ImportExcelApi,
      }
    },
  })
</script>

<style lang="less" scoped>
  .page-container {
    padding: 10px 0 20px;

    .page-title {
      padding: 0 20px;
    }

    .page-handle {
      padding: 10px 20px;
    }
  }

  .measure-list {
    position: relative;
    overflow-x: hidden;
    overflow-y: auto;
    padding: 2px 20px;
    height: calc(100% - 96px);
  }

  .empty {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  .action-box {
    display: flex;
    overflow: hidden;
    justify-content: flex-end;
    width: 90px;
    height: 36px;
    border: 1px solid #ffc3b0;
    border-radius: 18px;
    background: #fff;
    transition: width 0.3s;

    .action-button {
      // 隐藏按钮的点击效果
      :deep(button[ant-click-animating-without-extra-node]:after) {
        border: 0 none;
        opacity: 0;
        animation: none 0 ease 0 1 normal;
      }

      // 覆盖原来的disabled样式
      :deep(button[disabled]) {
        background: #fff;
      }

      :deep(.ant-btn) {
        height: 29px;
        border: none !important;

        &:hover {
          color: #f36f4e;
        }
      }

      &:last-child {
        :deep(.ant-btn) {
          color: #f36f4e;
        }
      }

      &:nth-last-child(2)::after {
        margin-left: 2px;
        height: 22px;
        border-left: 1px solid #f0f0f0;
        content: '';
      }
    }
  }

  .transition {
    width: 310px;
  }

  .before-rotate {
    transition: all 0.3s;
  }

  .after-rotate {
    transition: all 0.3s;
    transform: rotate(-180deg);
  }
</style>
