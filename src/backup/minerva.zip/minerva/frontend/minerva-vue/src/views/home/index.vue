<template>
  <div class="m-5"> </div>
</template>

<script lang="ts">
  export default defineComponent({
    setup() {
      return {}
    },
  })
</script>

<style scoped lang="less"></style>
