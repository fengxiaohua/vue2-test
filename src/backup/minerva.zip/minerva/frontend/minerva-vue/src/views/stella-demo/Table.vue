<template>
  <div class="h-full p-6">
    <!-- 定高 -->
    <PageTitle title="定高" />
    <BasicTable @register="registerTable" />
    <div class="h-4"></div>
    <!-- 表格大小 -->
    <PageTitle title="表格大小">
      <a-button type="primary" @click="changeSize('small')">small</a-button>
      <a-button type="primary" @click="changeSize('middle')">middle</a-button>
      <a-button type="primary" @click="changeSize('default')">default</a-button>
    </PageTitle>
    <BasicTable @register="registerSizeTable" />
    <div class="h-4"></div>
    <!-- 无分页器、显示边框线 -->
    <PageTitle title="无分页器、显示边框线" />
    <BasicTable @register="registerTable1" />
    <div class="h-4"></div>
    <!-- 随内容撑开 -->
    <PageTitle title="随内容撑开" />
    <BasicTable @register="registerTable2" />
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue'
  // 标题组件
  import PageTitle from '/@/components/PageTitle/index.vue'

  // 表格插件
  import { BasicTable, useTable } from '/@/components/Table'

  // 表格中的类型
  import type { BasicColumn, SizeType } from '/@/components/Table/src/types/table'
  // 表格列配置
  const columns: BasicColumn[] = [
    {
      title: '分组名称',
      resizable: true,
      dataIndex: 'groupName',
      minWidth: 120,
      width: 120,
      fixed: 'left',
    },
    {
      title: '分组描述',
      resizable: true,
      dataIndex: 'describe',
      minWidth: 120,
      width: 120,
    },
    {
      title: '项目数量',
      resizable: true,
      dataIndex: 'projectCount',
      minWidth: 120,
      width: 120,
    },
    {
      title: '分组排序',
      resizable: true,
      dataIndex: 'groupOrder',
      minWidth: 120,
      width: 120,
    },
    {
      title: '创建人',
      resizable: true,
      dataIndex: 'createUserName',
      minWidth: 180,
      width: 180,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      minWidth: 180,
      width: 200,
      sorter: true,
      resizable: true,
    },
    {
      title: '修改人',
      resizable: true,
      dataIndex: 'updateUserName',
      minWidth: 180,
      width: 200,
    },
    {
      title: '修改时间',
      resizable: true,
      dataIndex: 'updateTime',
      minWidth: 180,
      width: 200,
    },

    // {
    //   title: '操作',
    //   align: 'center',
    //   dataIndex: 'operation',
    //   minWidth: 120,
    //   width: 120,
    //   fixed: 'right',
    //   // defaultHidden: !hasPermission('auditsHistoryLooK'), // 判断操作列权限
    // },
  ]

  // API
  import { getGroup } from '/@/api/project/group'

  export default defineComponent({
    // 组件
    components: {
      BasicTable,
      PageTitle,
    },
    setup() {
      // 表格组件配置
      const [registerTable] = useTable({
        api: getGroup, // API命名后缀明确如：getGroupApi
        columns, // 表格列配置
        canResize: false, // 是否可以自适应高度
        scroll: { y: 200 }, // 定高
      })

      // 表格组件配置
      const [registerTable1] = useTable({
        api: getGroup, // API命名后缀明确如：getGroupApi
        columns, // 表格列配置
        canResize: false, // 是否可以自适应高度
        scroll: { y: 200 }, // 定高
        searchInfo: {
          page: 1,
          pageNum: 1,
          pageSize: 60,
        },
        bordered: true, // 是否显示边框
        pagination: false,
      })

      // 表格组件配置
      const [registerTable2] = useTable({
        api: getGroup, // API命名后缀明确如：getGroupApi
        columns, // 表格列配置
        canResize: false, // 是否可以自适应高度
      })

      let tableSize = ref<SizeType>('small')
      // 表格组件配置
      const [registerSizeTable] = useTable({
        api: getGroup, // API命名后缀明确如：getGroupApi
        columns, // 表格列配置
        canResize: false, // 是否可响应
        scroll: { y: 200 }, // 定高
        size: tableSize, // 表格大小
      })

      // 改变table的size
      const changeSize = (size: SizeType) => {
        tableSize.value = size
      }

      // 返回的变量、函数
      return {
        registerTable,
        registerTable1,
        registerTable2,
        registerSizeTable,
        changeSize,
      }
    },
  })
</script>
