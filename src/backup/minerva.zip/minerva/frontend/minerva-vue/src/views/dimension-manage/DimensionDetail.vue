<template>
  <div class="page-container">
    <PageTitle>
      <template #breadcrumb>
        <router-link to="/model/dimensionManage">维度管理</router-link>
        <router-link to="">维度详情</router-link>
      </template>
    </PageTitle>
    <div class="top">
      <EditDimensionBaseInfo :data="baseData" @on-edit="OnHandleEdit" />
    </div>
    <div class="bottom">
      <EditDimensionValueTable :dimensionsBaseCode="dimensionsBaseCode" />
    </div>
  </div>
</template>

<script lang="ts">
  // 引入基础信息组件
  import EditDimensionBaseInfo from './components/EditDimensionBaseInfo.vue'
  // 引入维度值列表
  import EditDimensionValueTable from './components/EditDimensionValueTable.vue'
  // 引入模型
  import type { DimensionInstance, Key } from '/@/api/dimension-manage/model/dimensionModel'
  // 引入API
  import { GetDimensionDetailApi } from '/@/api/dimension-manage/dimension'

  export default defineComponent({
    name: 'AddDimension',
    components: {
      EditDimensionBaseInfo,
      EditDimensionValueTable,
    },
    setup() {
      // 定义路由变量
      const router = useRouter()

      // 挂载后获取维度详情
      onMounted(() => {
        getBaseInfo()
      })

      // 维度基础信息
      const baseData = reactive<DimensionInstance>({
        name: '',
        code: '',
        described: '',
        status: '1',
        sortIndex: 999,
        remark: '',
        createType: '1',
      })

      /**
       * @description: 获取维度基础信息的详情
       */
      const getBaseInfo = async () => {
        // 获取详情路由中的code 查询详情信息
        const params = {
          code: router.currentRoute.value.query.code,
        } as Key
        await GetDimensionDetailApi(params).then((res) => {
          const { name, code, described, status, sortIndex, remark, createType } =
            reactive<DimensionInstance>(res.content)
          baseData.name = name
          baseData.code = code
          baseData.described = described
          baseData.status = status
          baseData.sortIndex = sortIndex
          baseData.remark = remark
          baseData.createType = createType
        })
      }

      // 获取维度基础编号
      const dimensionsBaseCode = ref<string>(router.currentRoute.value.query.code as string)

      /**
       * @description: 编辑维度回调
       */
      const OnHandleEdit = () => {
        getBaseInfo()
      }

      return {
        OnHandleEdit,
        baseData,
        dimensionsBaseCode,
      }
    },
  })
</script>

<style lang="less" scoped>
  .top {
    margin-top: 10px;
  }

  .bottom {
    margin-top: 10px;
    padding: 0 10px 0 15px;
    border-radius: 6px;
    background: #fff;
  }
</style>
