<template>
  <BasicTable
    @register="registerTable"
    :rowSelection="{ type: 'checkbox', selectedRowKeys, onChange: onSelectChange }"
  >
    <!-- 页面标题&操作 -->
    <template #pageTitle>
      <a-button type="primary" v-permission="'b_user_new'">
        <template #icon><Icon icon="plus" /></template>{{ p('b_user_new') }}
      </a-button>
    </template>

    <!-- 页面查询筛选 -->
    <template #pageFilters>
      <a-input placeholder="分组名称" v-model:value="searchInfo.groupName" allow-clear />
      <!-- <a-select placeholder="请选择" allow-clear /> -->
      <DictSelect
        v-model:value="selectValue"
        placeholder="请选择下拉数据内容"
        dict-type="PROCESS_NODE"
        allow-clear
      />
      <FilterPopover @reset="resetForm">
        <FilterPopoverItem label="创建人">
          <a-input placeholder="请输入创建人名称" allow-clear />
        </FilterPopoverItem>
        <FilterPopoverItem label="单选">
          <a-select placeholder="请选择" allow-clear>
            <a-select-option :key="1">测试1</a-select-option>
            <a-select-option :key="2">测试2</a-select-option>
            <a-select-option :key="3">测试3</a-select-option>
          </a-select>
        </FilterPopoverItem>
        <FilterPopoverItem label="多选">
          <a-select mode="multiple" placeholder="请选择" :show-arrow="true" allow-clear>
            <a-select-option key="测试1">测试1</a-select-option>
            <a-select-option key="测试2">测试2</a-select-option>
            <a-select-option key="测试3">测试3</a-select-option>
          </a-select>
        </FilterPopoverItem>
        <FilterPopoverItem label="创建时间">
          <a-date-picker allow-clear />
        </FilterPopoverItem>
        <FilterPopoverItem label="结束时间">
          <a-date-picker allow-clear />
        </FilterPopoverItem>
        <FilterPopoverItem label="运行时间">
          <a-range-picker format="YYYY-MM-DD" :placeholder="['创建时间', '结束时间']" allow-clear />
        </FilterPopoverItem>
      </FilterPopover>
      <a-button type="primary" @click="fetch">查询</a-button>
    </template>

    <!-- 页面操作功能 -->
    <template #pageActions>
      <ActionButton
        :disabled="selectedRowKeys.length === 0"
        disabledText="请选择要操作的数据"
        @click="onBatchDelete"
        >{{ p('b_resource_delete') }}</ActionButton
      >
    </template>

    <!-- 表格操作功能 -->
    <template #action="{ record }">
      <TableAction :actions="getTableActions(record)" />
    </template>

    <!-- 表格列自定义 -->
    <template #bodyCell="{ column, record }">
      <template v-if="column.dataIndex === 'groupName'">
        <router-link to="">{{ record.groupName }} </router-link>
      </template>
    </template>
  </BasicTable>
</template>

<script lang="ts">
  // 表格插件
  import { useTable, ActionItem } from '/@/components/Table'

  // 公共字典下拉组件
  import { DictSelect } from '/@/components/DictSelect'

  // 表格中的类型
  import type { BasicColumn, Key } from '/@/components/Table/src/types/table'
  // 表格列配置
  const columns: BasicColumn[] = [
    {
      title: '分组名称',
      resizable: true,
      dataIndex: 'groupName',
      minWidth: 120,
      width: 120,
      align: 'left',
      fixed: 'left',
    },
    {
      title: '分组描述',
      resizable: true,
      dataIndex: 'describe',
      minWidth: 120,
      width: 120,
      align: 'left',
    },
    {
      title: '项目数量',
      resizable: true,
      dataIndex: 'projectCount',
      minWidth: 120,
      width: 120,
    },
    {
      title: '分组排序',
      resizable: true,
      dataIndex: 'groupOrder',
      minWidth: 120,
      width: 120,
    },
    {
      title: '创建人',
      resizable: true,
      dataIndex: 'createUserName',
      minWidth: 180,
      width: 180,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      minWidth: 180,
      width: 200,
      sorter: true,
      resizable: true,
    },
    {
      title: '修改人',
      resizable: true,
      dataIndex: 'updateUserName',
      minWidth: 180,
      width: 200,
    },
    {
      title: '修改时间',
      resizable: true,
      dataIndex: 'updateTime',
      minWidth: 180,
      width: 200,
    },
  ]

  // API
  import { getGroup } from '/@/api/project/group'
  import type { GetGroupParams } from '/@/api/project/model/group'

  import { usePermission } from '/@/hooks/web/usePermission'
  // p：根据资源权限标识获取资源名称
  const { p, isActionColumnHidden } = usePermission()

  import { Modal } from 'ant-design-vue'
  import { useCreateVNode } from '/@/hooks/web/useCreateVNode'
  const { batchPrompt } = useCreateVNode()

  export default defineComponent({
    components: { DictSelect },
    setup() {
      // 查询筛选参数（根据Api请求模型）
      const searchInfo = reactive<GetGroupParams>({
        groupName: '',
        pageNum: 1,
        // ...
      })

      // 公共下拉参数
      let selectValue = ref()

      // 操作列配置及所有权限
      const getTableActions = (record?) => {
        return [
          {
            label: '编辑', // 名称或提示
            icon: 'edit-square', // 图标
            ifLoading: () => {
              // 其他逻辑亦可，如：arr.includes('Code1')
              return record.loading
            },
            disabled: record?.groupName === 'w9', // 是否禁用
            onClick: () => {
              record.loading = true
              setTimeout(() => {
                record.loading = false
              }, 2000)
            },
            permission: 'b_log_query', // 根据权限控制是否显示: 无权限，不显示
          },
          {
            label: p('b_user_delete'),
            icon: 'delete',
            permission: 'b_user_delete', // 根据权限控制是否显示: 有权限，会显示
          },
          {
            label: '删除',
            icon: 'delete',
            permission: 'b_log_query', // 根据权限控制是否显示: 有权限，会显示
          },
          {
            label: '启用',
            icon: 'yunhang',
            // 根据业务控制是否显示，如: 非enable状态的不显示启用按钮
            ifShow: (_action) => {
              return record.status !== 'enable'
            },
          },
          {
            label: '禁用',
            // 根据业务控制是否显示，如: enable状态的显示禁用按钮
            ifShow: () => {
              return record.status === 'enable'
            },
          },
          {
            label: '查看',
            icon: 'filesearch',
            ifShow: true,
            disabled: record?.groupName === '分组1', // 是否禁用
            disabledText: '你不能查看', // 禁用提示
            onClick: () => {
              console.log('查看', record)
            },
          },
        ] as ActionItem[]
      }

      // 表格组件配置
      const [registerTable, { reload }] = useTable({
        pageTitle: '在列表页面的Title、Filter、Action、Table等使用样例', // 页面标题
        api: getGroup, // API命名后缀明确如：getGroupApi
        searchInfo, // 查询参数
        // 默认排序字段
        defSort: {
          field: 'createTime', // 排序字段
          order: 'ascend', // 排序方式 ascend | descend
        },
        useSearchForm: true, // 是否使用查询过滤器
        showIndexColumn: false, // 是否展示序号
        columns, // 表格列配置
        // 操作列配置
        actionColumn: {
          defaultHidden: isActionColumnHidden(getTableActions()), // 操作列判断权限是否隐藏
        },
      })

      // 查询
      const fetch = () => {
        reload({ page: 1, searchInfo })
      }

      // 重制过滤筛选表单
      const resetForm = () => {
        console.log(selectValue)
        console.log('重制过滤筛选表单')
      }

      // 选中项keys
      const selectedRowKeys = ref<Key[]>([])
      // 选中项rows
      const selectedRow = ref<any[]>([])

      // 行选中事件
      function onSelectChange(keys: Key[], rows: any) {
        selectedRowKeys.value = keys
        selectedRow.value = rows
      }

      // 批量删除
      function onBatchDelete() {
        const selectedContent = toRaw(selectedRow.value).map((item) => item.groupName)
        Modal.confirm({
          title: `是否删除以下内容（${selectedContent.length}项）?`,
          content: batchPrompt(selectedContent),
          onOk() {
            console.log('OK')
          },
          onCancel() {
            console.log('Cancel')
          },
          class: 'test',
        })
      }

      // 返回的变量、函数
      return {
        searchInfo,
        selectValue,
        selectedRowKeys,
        p,
        registerTable,
        getTableActions,
        fetch,
        resetForm,
        onSelectChange,
        onBatchDelete,
        DictSelect,
      }
    },
  })
</script>
