<template>
  <div class="pt-10px p-20px">
    <PageTitle title="手动运行" />
    <a-tabs v-model:activeKey="activeKey" type="card">
      <a-tab-pane key="runningJob" tab="运行中">
        <RunningJob :activeKey="activeKey" />
      </a-tab-pane>
      <a-tab-pane key="historyJob" tab="运行历史">
        <HistoryJob :activeKey="activeKey" />
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script lang="ts">
  import RunningJob from './components/RunningJob.vue'
  import HistoryJob from './components/HistoryJob.vue'
  export default defineComponent({
    // 组件
    components: {
      RunningJob,
      HistoryJob,
    },
    setup() {
      // 当前tab页的key
      const activeKey = ref('historyJob')
      // 返回的变量、函数
      return {
        activeKey,
      }
    },
  })
</script>
<style lang="less" scoped>
  :deep(.ant-tabs .senses-basic-table) {
    padding: 0 16px;
  }

  :deep(.senses-basic-table-form-container .ant-table-wrapper) {
    padding: 0;
    border: none;
  }
</style>
