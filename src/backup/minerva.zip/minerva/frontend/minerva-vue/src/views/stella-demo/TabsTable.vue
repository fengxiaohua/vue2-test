<template>
  <div class="page-container h-full">
    <PageTitle title="标签页展示表格">
      <a-button type="primary" @click="add"><Icon icon="plus" /> 抽屉式新增 </a-button>
    </PageTitle>
    <a-tabs v-model:activeKey="currentTab" class="senses-tabs" type="card">
      <a-tab-pane key="1" tab="表格">
        <FirstTabTable v-if="currentTab === '1'" />
      </a-tab-pane>
      <a-tab-pane key="2" tab="带标题的表格">
        <SecondTabTable v-if="currentTab === '2'" />
      </a-tab-pane>
      <a-tab-pane key="3" tab="批量编辑的表格">
        <ThiridTabTable v-if="currentTab === '3'" />
      </a-tab-pane>
    </a-tabs>
    <NewDrawer
      v-if="drawerVisible"
      :drawerVisible="drawerVisible"
      @change-drawer-visible="changeDrawerVisible"
    />
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue'
  import { ref } from 'vue'
  // 图标组件
  import Icon from '/@/components/Icon'
  // 页面标题组件
  import { PageTitle } from '/@/components/PageTitle'
  // tab页的子组件
  import FirstTabTable from './components/FirstTabTable.vue'
  import SecondTabTable from './components/SecondTabTable.vue'
  import ThiridTabTable from './components/ThiridTabTable.vue'

  // 抽屉组件
  import NewDrawer from './components/NewDrawer.vue'

  export default defineComponent({
    name: 'TabsTable',
    components: {
      Icon,
      PageTitle,
      FirstTabTable,
      SecondTabTable,
      ThiridTabTable,
      NewDrawer,
    },
    setup() {
      // 当前tab页的key
      const currentTab = ref<string>('1')

      const drawerVisible = ref(false) // 新增抽屉visible
      // 显示抽屉
      const add = (): void => {
        drawerVisible.value = true
      }

      const changeDrawerVisible = (bool) => {
        drawerVisible.value = bool
      }
      return {
        currentTab,
        drawerVisible,
        add,
        changeDrawerVisible,
      }
    },
  })
</script>

<style lang="less">
  .senses-tabs {
    height: calc(100% - 36px);

    .ant-tabs-content {
      height: calc(100vh - 175px);
      border-radius: 0 6px 6px 6px;
    }

    .ant-tabs-card.ant-tabs-top > .ant-tabs-nav .ant-tabs-tab + .ant-tabs-tab {
      margin: 0;
      margin-right: 2px;
      padding: 0 16px;
      height: 40px;
      border: 1px solid #f0f0f0;
      border-radius: 3px 3px 0 0;
      background: #fafafa;
      line-height: 38px;
      transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
    }

    & .page-title {
      padding: 10px 15px 0 15px;
    }

    & .page-handle {
      padding: 10px 15px;
    }

    & .table-container {
      border-right: 0 !important;
      border-bottom: 0 !important;
      border-left: 0 !important;
      border-radius: 0 0 6px 6px !important;
    }
  }
</style>
