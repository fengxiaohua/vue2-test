<template>
  <div class="page-container">
    <div class="page-title">
      <PageTitle>
        <template #breadcrumb>
          <router-link to="/model/dimensionManage">维度管理</router-link>
          <router-link to="">新增维度（手动创建）</router-link>
        </template>
        <a-button shape="round" @click="cancel">取消</a-button>
        <a-button type="primary" shape="round" :loading="isConfirmLoading" @click="handleSubmit">
          确认
        </a-button>
      </PageTitle>
    </div>
    <div class="item">
      <AddDimensionBaseInfo ref="dimensionBaseInfoRef" />
    </div>
    <div class="item">
      <AddDimensionValueTable ref="addDimensionValueTableRef" />
    </div>
  </div>
</template>

<script lang="ts">
  // 引入基础信息组件
  import { message, Modal } from 'ant-design-vue'
  import AddDimensionBaseInfo from './components/AddDimensionBaseInfo.vue'
  // 引入维度值列表
  import AddDimensionValueTable from './components/AddDimensionValueTable.vue'
  import { AddDimensionApi } from '/@/api/dimension-manage/dimension'
  import { BatchAddDimensionValueApi } from '/@/api/dimension-manage/dimensionValue'

  export default defineComponent({
    name: 'AddDimension',
    components: {
      AddDimensionBaseInfo,
      AddDimensionValueTable,
    },
    setup() {
      // 确认新增按钮loading
      const isConfirmLoading = ref<boolean>(false)

      // 定义路由变量
      const router = useRouter()

      /**
       * @description: 取消新增维度
       */
      const cancel = () => {
        toDimensionManage()
      }

      /**
       * @description: 路由跳转维度管理
       */
      const toDimensionManage = () => {
        router.push({
          name: 'dimensionManage',
        })
      }

      // 维度基础信息组件ref
      const dimensionBaseInfoRef = ref()

      // 新增维度值列表组件ref
      const addDimensionValueTableRef = ref()

      /**
       * @description: 确认新增维度
       */
      const handleSubmit = async () => {
        // 获取基础信息以及维度值列表校验结果
        dimensionBaseInfoRef.value.formRef.validateFields().then(() => {
          addDimensionValueTableRef.value.validateTable().then(async (isValid) => {
            if (isValid) {
              // 校验成功 获取数据
              // 通过 ref 获取子组件 expose 暴露的表单数据
              const params = dimensionBaseInfoRef.value.form
              isConfirmLoading.value = true
              await AddDimensionApi(params)
                .then(async () => {
                  // 新增维度基础信息后请求新增维度值列表
                  // 获取维度值列表数据 并将维度编号赋给维度值列表
                  const data = addDimensionValueTableRef.value.getTableData()
                  data.forEach((item) => {
                    item.dimensionsBaseCode = params.code
                    item.pcode = item.pcode ? item.pcode : ''
                  })
                  // 请求批量新增维度值接口
                  await BatchAddDimensionValueApi(data)
                    .then(() => {
                      message.success('新增维度成功')
                      isConfirmLoading.value = false
                      toDimensionManage()
                    })
                    .catch(() => {
                      message.error('新增维度值失败')
                      isConfirmLoading.value = false
                    })
                })
                .catch(() => {
                  message.error('新增维度失败')
                  isConfirmLoading.value = false
                })
            }
          })
        })
      }

      return {
        isConfirmLoading,
        dimensionBaseInfoRef,
        addDimensionValueTableRef,
        cancel,
        handleSubmit,
      }
    },
  })
</script>

<style lang="less" scoped>
  .item {
    margin-top: 10px;
    padding: 0 15px;
    border-radius: 6px;
    background: #fff;
  }
</style>
