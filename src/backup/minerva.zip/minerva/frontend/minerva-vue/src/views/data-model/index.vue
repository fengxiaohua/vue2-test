<template>
  <div>
    <BasicTable
      @register="registerTable"
      :rowSelection="{ type: 'checkbox', selectedRowKeys, onChange: onSelectChange }"
    >
      <!-- 页面标题&操作 -->
      <template #pageTitle>
        <a-button @click="onAddModelClick" type="primary" v-permission="'data_model_add'">
          <template #icon><Icon icon="plus" /></template>{{ p('data_model_add') }}
        </a-button>
      </template>

      <!-- 页面查询筛选 -->
      <template #pageFilters>
        <a-input
          placeholder="模型名称/编码"
          allow-clear
          v-model:value="searchInfo.codeOrName"
          @pressEnter="fetch"
        />
        <!-- <a-select placeholder="选择状态" v-model:value="searchInfo.status" allow-clear>
          <a-select-option key="1">启用</a-select-option>
          <a-select-option key="0">禁用</a-select-option>
        </a-select> -->
        <DictSelect
          v-model:value="searchInfo.status"
          placeholder="请选择状态"
          dict-type="MINERVA_STATUS"
          allow-clear
        />
        <a-button type="primary" @click="fetch">查询</a-button>
      </template>

      <!-- 页面操作功能 -->
      <template #pageActions>
        <ActionButton
          @click="onDeleteBatch"
          :disabled="selectedRowKeys.length === 0"
          disabledText="请选择要操作的数据"
          >{{ p('data_model_batch_delete') }}</ActionButton
        >
      </template>

      <!-- 表格操作功能 -->
      <template #action="{ record }">
        <TableAction :actions="getTableActions(record)" />
      </template>

      <!-- 表格列自定义 -->
      <template #bodyCell="{ column, record }">
        <template v-if="column.dataIndex === 'name'">
          <span @click="onLookDataModelInfo(record)" class="primary">{{ record.name }} </span>
        </template>

        <template v-if="column.dataIndex === 'status'">
          <span v-if="record.status === 'T'" class="success-color">启用</span>
          <span v-if="record.status === 'F'" class="disabled-color">禁用</span>
        </template>

        <template v-if="column.dataIndex === 'syncStatus'">
          <span v-if="record.syncStatus === 'running'" class="progress-color">运行中</span>
          <span v-else-if="record.syncStatus === 'success'" class="success-color">成功</span>
          <span v-else-if="record.syncStatus === 'fail'" class="fail-color">禁用</span>
          <span v-else>待同步</span>
        </template>
      </template>
    </BasicTable>
    <AsyncData
      v-model:isModalShow="isAsynModalShow"
      :modelCode="modelCode"
      :type="type"
      @is-asynced="fetch"
    />
    <ChooseModal
      @register="register"
      @on-click="onAddModalClick"
      v-model:isModalShow="isAddModelModalShow"
    />

    <!-- 数据预览 -->
    <DataPreview
      v-model:dataPreviewVisible="isDataPreviewModalShow"
      :base-info="dataPreviewBaseInfo"
      :preview-api="DataPreviewApi"
      :preview-count-api="DataPreviewCountApi"
    />
  </div>
</template>

<script lang="ts" setup>
  import { useRouter } from 'vue-router'
  import { message, Modal } from 'ant-design-vue'
  import { useTable, ActionItem } from '/@/components/Table'

  import { GetModelTableParams } from '/@/api/data-model/model/dataModel'
  import {
    getDataModel,
    deleteDataModalBatch,
    GetDataModalInfo,
    getFieldsWithRelCode,
    DataPreviewApi,
    DataPreviewCountApi,
  } from '/@/api/data-model/index'

  // 表格中的类型
  import type { BasicColumn, Key } from '/@/components/Table/src/types/table'

  import { usePermission } from '/@/hooks/web/usePermission'

  // 使用缓存
  import { useDataModalLibraryWithOut } from '/@/store/modules/dataModalLibrary'

  // 导入函数
  import { findKey } from './components/utils'

  //导入组件
  import DataPreview from '/@/components/BatchOperation/src/DataPreview.vue'

  import { ChooseModal, BaseItemModalData, useChooseModal } from '/@/components/ChooseModal'
  import { useCreateVNode } from '/@/hooks/web/useCreateVNode'
  import { DataModalType, dataModalAddType } from './components/const'
  // import DictSelect from '/@/components/DictSelect/src/dict-select.vue'
  import { getDictOptions } from '/@/api/util/dict'
  import type { BasicDictResult } from '/@/api/util/model/dictModel'
  import AsyncData from './components/async-data.vue'

  DictOptions()

  // 使用缓存
  const dataModalLibraryStore = useDataModalLibraryWithOut()

  const dictOptions = ref<Array<BasicDictResult>>()

  const { batchPrompt } = useCreateVNode()

  const [register] = useChooseModal({
    modalTitle: '通过哪种方式新增模型？',
    sourceData: [
      {
        data: [
          {
            title: '根据资产包引入',
            desc: '通过引入资产管理平台中定义的单个资产包，来配置数据模型的字段信息',
            icon: 'zichanbao',
            path: `/model/addDataModal?step=1&type=${DataModalType.AssetPack}`,
            // 自定义属性
            // key: 'string'
          },
          // 此版本先隐藏掉（没时间做这个功能）
          // {
          //   title: '根据数据库表引入',
          //   desc: '通过引入数据源链接中的单个或多个数据库表，设置表间关联关系，实现数据模型的逻辑，来配置数据模型的字段信息',
          //   icon: 'peizhishujuyuan',
          //   path: `/model/addDataModal?step=1&type=${DataModalType.DataBase}`,
          // },
          {
            title: '根据SQL语句引入',
            desc: '通过SQL编程语句，实现数据模型的逻辑，来配置数据模型的字段信息',
            icon: 'file-SQL',
            path: `/model/addDataModal?step=1&type=${DataModalType.SQL}`,
          },
        ],
      },
    ],
  })

  // p：根据资源权限标识获取资源名称
  const { p, isActionColumnHidden } = usePermission()

  // 路由
  const router = useRouter()

  // 是否显示同步
  const isAsynModalShow = ref<boolean>(false)
  // 是否显示新增模型弹框
  const isAddModelModalShow = ref<boolean>(false)

  // 数据预览传参
  const modelCode = ref()
  const type = ref()

  // 查询筛选参数（根据Api请求模型）
  const searchInfo = reactive<GetModelTableParams>({
    codeOrName: '', // 模型名称
    status: undefined, // 状态
    // ...
  })

  // 表格列配置
  const columns: BasicColumn[] = [
    {
      title: '模型名称',
      resizable: true,
      dataIndex: 'name',
      minWidth: 120,
      width: 120,
      align: 'left',
      fixed: 'left',
    },
    {
      title: '模型编号',
      resizable: true,
      dataIndex: 'code',
      minWidth: 120,
      width: 120,
      align: 'left',
    },
    {
      title: '状态',
      resizable: true,
      dataIndex: 'status',
      align: 'center',
      minWidth: 120,
      width: 120,
    },
    {
      title: '展示顺序',
      resizable: true,
      dataIndex: 'sortIndex',
      align: 'center',
      minWidth: 120,
      width: 120,
    },
    {
      title: '备注',
      resizable: true,
      dataIndex: 'remark',
      minWidth: 120,
      width: 120,
    },
    {
      title: '模型创建方式',
      resizable: true,
      dataIndex: 'type',
      format: (cellValue) => {
        return cellValue === '1'
          ? '根据资产包引入'
          : cellValue === '2'
          ? '根据数据库表引入'
          : '根据SQL引入'
      },
      minWidth: 120,
      width: 120,
    },
    {
      title: '同步状态',
      resizable: true,
      dataIndex: 'syncStatus',
      minWidth: 120,
      width: 120,
    },
    {
      title: '创建人',
      resizable: true,
      dataIndex: 'createUserName',
      minWidth: 180,
      width: 180,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      minWidth: 180,
      width: 200,
      sorter: true,
      resizable: true,
    },
    {
      title: '修改人',
      resizable: true,
      dataIndex: 'updateUserName',
      minWidth: 180,
      width: 180,
    },
    {
      title: '修改时间',
      resizable: true,
      dataIndex: 'updateTime',
      minWidth: 180,
      width: 200,
    },
  ]

  // 操作列配置及所有权限
  const getTableActions = (record?) => {
    // 操作列方法
    return [
      {
        label: '同步', // 名称或提示
        icon: 'sync', // 图标
        onClick: () => {
          type.value = record.type
          modelCode.value = record.code
          isAsynModalShow.value = true
          console.log('同步', record)
        },
      },
      {
        label: '查看详情', // 名称或提示
        icon: 'filesearch', // 图标
        onClick: () => {
          onLookDataModelInfo(record)
        },
        permission: 'data_model_info', // 根据权限控制是否显示: 无权限，不显示
      },
      {
        label: '数据预览', // 名称或提示
        icon: 'organization-report', // 图标
        onClick: () => {
          dataPreview(record)
        },
        permission: 'data_model_preview', // 根据权限控制是否显示: 无权限，不显示
      },
      {
        label: '删除',
        icon: 'delete',
        permission: 'data_model_delete', // 根据权限控制是否显示: 有权限，会显示
        onClick: () => {
          onDeleteDataModel(record)
        },
      },
    ] as ActionItem[]
  }

  // 表格组件配置
  const [registerTable, { reload }] = useTable({
    pageTitle: '数据模型', // 页面标题
    api: getDataModel, // API命名后缀明确如：getGroupApi
    searchInfo, // 查询参数
    // 默认排序字段
    defSort: {
      field: 'createTime', // 排序字段
      order: 'ascend', // 排序方式 ascend | descend
    },
    useSearchForm: true, // 是否使用查询过滤器
    showIndexColumn: false, // 是否展示序号
    columns, // 表格列配置
    // 操作列配置
    actionColumn: {
      defaultHidden: isActionColumnHidden(getTableActions()), // 操作列判断权限是否隐藏
    },
  })

  // 查询
  const fetch = () => {
    reload({ page: 1, searchInfo })
  }

  // 删除
  const onDeleteDataModel = (record) => {
    try {
      Modal.confirm({
        title: '提示',
        content: `确定删除"${record.name}"数据模型吗？`,
        async onOk() {
          try {
            await deleteDataModalBatch(record.code)
            message.success('删除数据模型成功')
            fetch()
          } catch (error) {
            console.error('error', error)
          }
        },
      })
    } catch (error) {
      console.log('error', error)
    }
  }

  // 批量删除
  const onDeleteBatch = () => {
    console.log('批量删除', selectedRowKeys)
    const selectedContent = toRaw(selectedRow.value).map((item) => item.name)
    const selectedRowKey = toRaw(selectedRow.value).map((item) => item.code)
    Modal.confirm({
      title: `是否删除以下内容（${selectedContent.length}项）?`,
      content: batchPrompt(selectedContent),
      async onOk() {
        console.log('OK')
        await deleteDataModalBatch(selectedRowKey.toString())
        message.success('批量删除数据模型成功')
        fetch()
      },
      onCancel() {
        console.log('Cancel')
      },
      class: 'test',
    })
  }

  // 选中项keys
  const selectedRowKeys = ref<Key[]>([])
  const selectedRow = ref<any[]>([])

  // 行选中事件
  const onSelectChange = (keys: Key[], rows: any) => {
    selectedRowKeys.value = keys
    selectedRow.value = rows
  }

  /**
   * @description: 新增模型跳转
   */
  const onAddModelClick = (): void => {
    dataModalLibraryStore.clear()
    isAddModelModalShow.value = true
  }

  const onAddModalClick = (row: BaseItemModalData) => {
    router.push(row.path)
  }

  /**
   * @description: 查看模型详情
   * @param {any} record
   */
  const onLookDataModelInfo = (record) => {
    console.log('查询模型', record)
    // 避免有未完成新增的缓存影响
    dataModalLibraryStore.clear()
    GetDataModalInfo(record.code, record.type).then((res) => {
      const { content } = res
      // 设置缓存数据
      setDataModalStep1Info(content)
      setDataModalStep2Info(content, record.type)
      setDataModalStep3Info(content)
      setDataModalStep4Info(content)
      router.push(
        `/model/editDataModal?type=${findKey(dataModalAddType, parseInt(content.type))}&code=${
          content.code
        }`,
      )
    })
  }

  // 设置第一步缓存数据，以供编辑时适用
  const setDataModalStep1Info = (content) => {
    dataModalLibraryStore.setDataModalBaseInfo({
      code: content.code, // 模型编码
      name: content.name, // 模型名称
      status: content.status, // 状态
      sortIndex: content.sortIndex, // 展示顺序
      remark: content.remark, // 描述
    })
  }

  // 设置第二步缓存数据，以供编辑时适用
  const setDataModalStep2Info = (content, type) => {
    type = parseInt(type)
    switch (type) {
      case dataModalAddType[DataModalType.AssetPack]:
        const twoPath = content.twoDirCode ? `${content.twoDirName}（${content.twoDirCode}）` : ''
        dataModalLibraryStore.setDataModalSourceInfo({
          assetCode: content.apCode,
          assetName: content.apName,
          path: `${content.oneDirName}（${content.oneDirCode}） > ${twoPath} > ${content.apName}（${content.apCode}）`,
        })
        break
      case dataModalAddType[DataModalType.SQL]:
        dataModalLibraryStore.setDataModalSourceInfo({
          sqlContent: content.sqlContent,
          sourceSchema: content.sourceScheme,
          dataSourceName: content.dsName,
          path: content.dsName,
        })
        break
      case dataModalAddType[DataModalType.DataBase]:
        console.log('编辑根据数据库引入模型')
        break
      default:
        break
    }
  }

  // 设置第三步缓存数据，以供编辑时适用
  const setDataModalStep3Info = (content) => {
    getFieldsWithRelCode(content.code).then((res) => {
      dataModalLibraryStore.setDataModalEditFieldInfo({
        fieldMapping: res.content.map((item) => Object.assign(item, { isEdit: false })),
        groundDatabaseCode: content.groundDatabaseCode,
        groundDatabaseScheme: content.groundDatabaseScheme,
        groundTableEn: content.groundTableEn,
      })
    })
  }

  // 设置第四步缓存数据，以供编辑时适用
  const setDataModalStep4Info = (content) => {
    dataModalLibraryStore.setDataModalAdvanceInfo({
      modelDateField: content.modelDateField,
      dateFormat: content.dateFormat,
      saveType: content.saveType,
      partitionFiled: content.partitionFiled,
      frequency: content.frequency,
      dataRetainedStrategy: content.dataRetainedStrategy,
    })
  }

  // 获取下拉数据
  function DictOptions() {
    getDictOptions({ dictType: 'MINERVA_STATUS' }).then((res) => {
      dictOptions.value = res.content
    })
  }

  // 是否显示数据预览弹框
  const isDataPreviewModalShow = ref(false)
  // title,code
  const dataPreviewBaseInfo = ref({})
  // 数据预览按钮操作
  const dataPreview = async (record) => {
    dataPreviewBaseInfo.value = {
      title: `数据模型 - ${record.name}`,
      code: record.code,
    }
    isDataPreviewModalShow.value = true
  }
</script>
<style lang="less" scoped>
  .primary {
    color: @primary-color;
    cursor: pointer;
  }
</style>
