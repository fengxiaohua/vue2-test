<template>
  <div class="flex justify-center items-center p-5">
    <a-button type="primary" @click="showModal">打开弹窗</a-button>
    <!-- 弹窗 -->
    <a-modal
      v-model:visible="visible"
      width="800px"
      title="Basic Modal"
      :maskClosable="false"
      @ok="handleOk"
    >
      <p>Some contents...</p>
      <p>Some contents...</p>
      <p>Some contents...</p>
      <BasicTable @register="registerTable" />
    </a-modal>
  </div>
</template>
<script lang="ts">
  import { defineComponent, ref } from 'vue'
  // 表格插件
  import { BasicTable, useTable } from '/@/components/Table'
  // API
  import { getGroup } from '/@/api/project/group'
  // 表格中的类型
  import type { BasicColumn } from '/@/components/Table/src/types/table'
  // 表格列配置
  const columns: BasicColumn[] = [
    {
      title: '分组名称',
      resizable: true,
      dataIndex: 'groupName',
      minWidth: 120,
      width: 120,
      fixed: 'left',
    },
    {
      title: '分组描述',
      resizable: true,
      dataIndex: 'describe',
      minWidth: 120,
      width: 120,
    },
    {
      title: '项目数量',
      resizable: true,
      dataIndex: 'projectCount',
      minWidth: 120,
      width: 120,
    },
    {
      title: '分组排序',
      resizable: true,
      dataIndex: 'groupOrder',
      minWidth: 120,
      width: 120,
    },
    {
      title: '创建人',
      resizable: true,
      dataIndex: 'createUserName',
      minWidth: 180,
      width: 180,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      minWidth: 180,
      width: 200,
      sorter: true,
      resizable: true,
    },
    {
      title: '修改人',
      resizable: true,
      dataIndex: 'updateUserName',
      minWidth: 180,
      width: 200,
    },
    {
      title: '修改时间',
      resizable: true,
      dataIndex: 'updateTime',
      minWidth: 180,
      width: 200,
    },

    // {
    //   title: '操作',
    //   align: 'center',
    //   dataIndex: 'operation',
    //   minWidth: 120,
    //   width: 120,
    //   fixed: 'right',
    //   // defaultHidden: !hasPermission('auditsHistoryLooK'), // 判断操作列权限
    // },
  ]

  export default defineComponent({
    components: { BasicTable },
    setup() {
      const visible = ref<boolean>(false)

      // 弹窗展示
      const showModal = () => {
        visible.value = true
      }

      // 弹窗确定按钮事件
      const handleOk = (e: MouseEvent) => {
        console.log(e)
        visible.value = false
      }

      // 表格组件配置
      const [registerTable] = useTable({
        api: getGroup, // API命名后缀明确如：getGroupApi
        columns, // 表格列配置
        canResize: false, // 是否可响应
        bordered: true, // 显示边框线
        scroll: { y: 300 }, // 定高
      })

      return {
        visible,
        registerTable,
        showModal,
        handleOk,
      }
    },
  })
</script>
