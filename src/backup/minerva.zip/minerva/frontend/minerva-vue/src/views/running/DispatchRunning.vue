<template>
  <div>
    <BasicTable @register="registerTable">
      <!-- 页面查询筛选 -->
      <template #pageFilters>
        <a-input
          placeholder="名称/编号"
          v-model:value="searchInfo.keyword"
          allow-clear
          @pressEnter="fetch"
        />
        <a-range-picker
          v-model:value="rangeRunDate"
          format="YYYY-MM-DD"
          :placeholder="['运行开始日期', '运行结束日期']"
          @change="runDateChange"
        />
        <FilterPopover @reset="resetForm">
          <FilterPopoverItem class="w-420px" label="运行状态">
            <a-select v-model:value="searchInfo.runStatus" allow-clear placeholder="请选择运行状态">
              <a-select-option value="success">成功</a-select-option>
              <a-select-option value="fail">失败</a-select-option>
            </a-select>
          </FilterPopoverItem>
          <FilterPopoverItem class="w-420px" label="开始时间">
            <a-range-picker
              v-model:value="rangeDate"
              format="YYYY-MM-DD"
              :placeholder="['开始时间', '结束时间']"
              @change="dateChange"
            />
          </FilterPopoverItem>
        </FilterPopover>
        <a-button type="primary" @click="fetch">查询</a-button>
      </template>

      <!-- 表格操作功能 -->
      <template #action="{ record }">
        <TableAction :actions="getTableActions(record)" />
      </template>

      <!-- 字段处理 -->
      <template #bodyCell="{ record, column }">
        <template v-if="column.dataIndex === 'runStatus'">
          <span v-if="record[column.dataIndex] === 'success'" class="success-color">成功</span>
          <span v-else-if="record[column.dataIndex] === 'fail'" class="fail-color">失败</span>
        </template>
      </template>
    </BasicTable>

    <a-modal
      v-model:visible="logVisible"
      title="日志"
      :destroy-on-close="true"
      :footer="null"
      width="70%"
      @change="clearLogs"
    >
      <div v-loading="isLoading" class="relative">
        <div v-if="logs" class="log_content">
          <pre class="log_info"> {{ logs }}</pre>
        </div>
        <Empty v-else class="relative" description="" />
      </div>
    </a-modal>
  </div>
</template>

<script lang="ts">
  // 表格插件
  import { BasicTable, useTable, TableAction, ActionItem } from '/@/components/Table'

  import { FilterPopover, FilterPopoverItem } from '/@/components/FilterPopover'
  // 表格中的类型
  import type { BasicColumn } from '/@/components/Table/src/types/table'

  // 表格列配置
  const columns: BasicColumn[] = [
    {
      title: '名称',
      resizable: true,
      dataIndex: 'name',
      minWidth: 120,
      width: 180,
      fixed: 'left',
    },
    {
      title: '编号',
      resizable: true,
      dataIndex: 'code',
      minWidth: 120,
      width: 180,
    },
    {
      title: '业务类型',
      resizable: true,
      dataIndex: 'bizTypeDesc',
      minWidth: 120,
      width: 180,
    },
    {
      title: '运行日期',
      resizable: true,
      dataIndex: 'runDate',
      minWidth: 180,
      width: 180,
    },
    {
      title: '数据日期',
      resizable: true,
      dataIndex: 'dataDate',
      width: 180,
      minWidth: 120,
    },
    {
      title: '运行状态',
      resizable: true,
      dataIndex: 'runStatus',
      minWidth: 120,
      width: 120,
    },
    {
      title: '开始时间',
      resizable: true,
      dataIndex: 'startTime',
      minWidth: 180,
      sorter: true,
      width: 180,
    },
    {
      title: '结束时间',
      dataIndex: 'endTime',
      minWidth: 180,
      width: 200,
      sorter: true,
      resizable: true,
    },
    {
      title: '运行时长（S）',
      resizable: true,
      dataIndex: 'elapsed',
      minWidth: 180,
      width: 200,
    },
    {
      title: '运行人',
      resizable: true,
      dataIndex: 'runUserName',
      minWidth: 180,
      width: 200,
    },
  ]
  // API
  import { getDispatchListApi, getRunlogApi, rerunApi } from '/@/api/running/running'
  import { Key, GetRunnningParams } from '/@/api/running/model/running'
  //
  import { usePermission } from '/@/hooks/web/usePermission'
  import { message } from 'ant-design-vue'
  // p：根据资源权限标识获取资源名称
  const { p, isActionColumnHidden } = usePermission()
  export default defineComponent({
    // 组件
    components: {
      BasicTable,
      TableAction,
      FilterPopover,
      FilterPopoverItem,
    },
    setup() {
      //定时器
      let TIMER
      //日志弹窗
      const logVisible = ref(false)
      //isLoading
      const isLoading = ref(false)
      //日志详情
      const logs = ref('')
      // 运行日期区间
      let rangeRunDate = ref(['', ''])
      // 运行时间区间
      let rangeDate = ref(['', ''])

      const initSearchInfo = () => {
        return {
          keyword: '',
          startDateStr: '',
          endDateStr: '',
          startRunDateStr: '',
          endRunDateStr: '',
          runStatus: undefined,
          bizType: 'all',
        }
      }

      // 查询筛选参数（根据API请求模型）
      let searchInfo = reactive<GetRunnningParams>(initSearchInfo())

      // 重置过滤筛选表单
      const resetForm = () => {
        Object.assign(searchInfo, initSearchInfo())
        rangeDate.value = rangeRunDate.value = ['', '']
      }

      // 选择运行日期
      const runDateChange = (dates, dateStrings) => {
        searchInfo.startRunDateStr = dateStrings[0]
        searchInfo.endRunDateStr = dateStrings[1]
        if (dateStrings[0] === '' || dateStrings[1] === '') {
          searchInfo.startRunDateStr = searchInfo.endRunDateStr = ''
        }
      }
      // 选择运行时间
      const dateChange = (dates, dateStrings) => {
        searchInfo.startDateStr = dateStrings[0]
        searchInfo.endDateStr = dateStrings[1]
        if (dateStrings[0] === '' || dateStrings[1] === '') {
          searchInfo.startDateStr = searchInfo.endDateStr = ''
        }
      }

      // 操作列配置及所有权限
      const getTableActions = (record?) => {
        // 操作列方法
        return [
          {
            label: p('b_running_redo'),
            icon: 'redo',
            permission: 'b_running_redo',
            ifLoading: () => {
              return record.loading
            },
            onClick: () => {
              record.loading = true
              rerunApi({ id: record.id } as Key)
                .then((res) => {
                  message.success(res.content)
                })
                .finally(() => {
                  record.loading = false
                })
            },
          },
          {
            label: p('b_running_log'),
            icon: 'filesearch',
            permission: 'b_running_log',
            onClick: () => {
              logVisible.value = true
              getRunlog(record.id)
            },
          },
        ] as ActionItem[]
      }

      // 表格组件配置
      const [registerTable, { reload, getPaginationRef }] = useTable({
        pageTitle: '例行运行', // 页面标题
        api: getDispatchListApi,
        searchInfo, // 查询参数
        // 默认排序字段
        defSort: {
          // field: 'startTime', // 排序字段
          // order: 'descend', // 排序方式 ascend | descend
        },
        useSearchForm: true, // 是否使用查询过滤器
        showIndexColumn: false, // 是否展示序号
        columns, // 表格列配置
        // 操作列配置
        actionColumn: {
          defaultHidden: isActionColumnHidden(getTableActions()), // 操作列判断权限是否隐藏
        },
      })

      // 查询
      const fetch = () => {
        clearInterval(TIMER) // 清除定时器
        reload({ page: 1, searchInfo })
        startTimer()
      }

      // 每隔5秒查询一次
      const startTimer = () => {
        TIMER = setInterval(() => {
          const currentPage: any = getPaginationRef()
          clearInterval(TIMER) // 清除定时器
          reload({ page: currentPage.current, searchInfo })
          startTimer()
        }, 5000)
      }

      // 挂载后启动定时器
      onMounted(() => {
        startTimer()
      })
      onBeforeUnmount(() => {
        clearInterval(TIMER)
      })

      // 获取手动运行的历史日志
      const getRunlog = (key) => {
        isLoading.value = true
        const params = {
          id: key,
        } as Key
        getRunlogApi(params)
          .then((res) => {
            logs.value = res.content.logContent
          })
          .finally(() => {
            isLoading.value = false
          })
      }
      //清空日志
      const clearLogs = () => {
        logs.value = ''
      }
      // 返回的变量、函数
      return {
        searchInfo,
        initSearchInfo,
        logVisible,
        rangeRunDate,
        rangeDate,
        logs,
        isLoading,
        runDateChange,
        dateChange,
        registerTable,
        getTableActions,
        fetch,
        resetForm,
        clearLogs,
        p,
        getRunlog,
      }
    },
  })
</script>
<style lang="less" scoped>
  .log_content {
    padding: 20px;
  }
</style>
