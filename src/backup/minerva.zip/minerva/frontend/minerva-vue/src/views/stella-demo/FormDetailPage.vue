<template>
  <div class="page-container">
    <!-- on-cancel 取消事件  on-confirm 确认事件  maxHeight 设置最大高度，默认为125px-->
    <FormDetail
      ref="formDetailRef"
      @on-cancel="handleCancel"
      @on-confirm="handleConfirm"
      maxHeight="500px"
    >
      <template #content>
        <a-form
          ref="formRef"
          :model="form"
          :rules="formRules"
          :label-col="{ span: 8 }"
          :wrapper-col="{ span: 16 }"
        >
          <a-form-item label="维度名称" name="name">
            <a-input placeholder="请输入维度名称" v-model:value="form.name" />
          </a-form-item>
          <a-form-item label="维度编号" name="code">
            <a-input disabled placeholder="请输入维度编号" v-model:value="form.code" />
          </a-form-item>
          <a-form-item label="状态" name="status">
            <a-select placeholder="请选择状态" v-model:value="form.status">
              <a-select-option :key="'1'">启用</a-select-option>
              <a-select-option :key="'0'">禁用</a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item label="维度名称" name="name">
            <a-input placeholder="请输入维度名称" v-model:value="form.name" />
          </a-form-item>
          <a-form-item label="展示顺序" name="sortIndex">
            <a-input-number
              disabled
              style="width: 100%"
              :min="1"
              placeholder="请输入展示顺序"
              v-model:value="form.sortIndex"
            />
          </a-form-item>
          <a-form-item label="备注" name="remark">
            <a-textarea
              v-model:value="form.remark"
              placeholder="请输入备注"
              :auto-size="{ minRows: 1, maxRows: 2 }"
            />
          </a-form-item>
          <a-form-item label="备注" name="remark">
            <a-textarea
              v-model:value="form.remark"
              placeholder="请输入备注"
              :auto-size="{ minRows: 1, maxRows: 2 }"
            />
          </a-form-item>
        </a-form>
      </template>
    </FormDetail>
  </div>
</template>

<script lang="ts">
  import { FormInstance, message } from 'ant-design-vue'
  import { DimensionInstance } from '/@/api/dimension-manage/model/dimensionModel'
  // 引入表单自定义校验
  import { rules, FormRule } from '/@/utils/rules/index'

  export default defineComponent({
    setup() {
      //表单对象
      const form = reactive<DimensionInstance>({
        name: 'name',
        code: 'code',
        described: '描述',
        status: '1',
        sortIndex: 999,
        remark: '备注',
        createType: '1',
      })

      // 表单校验规则
      const formRules: Record<string, FormRule[]> = {
        name: [
          {
            required: true,
            message: '请输入维度名称',
          },
          {
            validator: rules.regTextLength,
            trigger: ['change', 'blur'],
          },
        ],
        code: [
          {
            required: true,
            message: '请输入维度编号',
          },
          {
            validator: rules.regTextLength,
            trigger: ['change', 'blur'],
          },
        ],
        status: [
          {
            required: true,
            message: '请选择状态',
          },
        ],
        sortIndex: [
          {
            required: true,
            message: '请输入展示顺序',
          },
        ],
        described: [
          {
            validator: rules.regDesc,
            trigger: ['change', 'blur'],
          },
        ],
        remark: [
          {
            validator: rules.regDesc,
            trigger: ['change', 'blur'],
          },
        ],
      }

      // 表单组件对象ref
      const formRef = ref<FormInstance>()

      // FormDetail组件ref
      const formDetailRef = ref()

      /**
       * @description: 取消
       */
      const handleCancel = () => {
        // 关闭编辑状态
        formDetailRef.value.isEdit = false
        // 关闭展开
        formDetailRef.value.isExpand = false
        console.log('取消')
      }

      /**
       * @description: 确认
       */
      const handleConfirm = () => {
        // 表单校验
        formRef.value?.validateFields().then(() => {
          // 请求接口结果
          const result = true
          if (result) {
            // 通过 ref 获取子组件 expose 暴露的 isEdit, isExpand
            // success 关闭编辑状态
            formDetailRef.value.isEdit = false
            // success 关闭展开
            formDetailRef.value.isExpand = false
          } else {
            // error 保持当前状态
            message.error('有错误')
          }
        })
      }

      return {
        form,
        formRules,
        formRef,
        formDetailRef,
        handleCancel,
        handleConfirm,
      }
    },
  })
</script>

<style scoped></style>
