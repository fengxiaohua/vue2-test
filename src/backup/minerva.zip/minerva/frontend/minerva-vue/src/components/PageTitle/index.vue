<!--
 * @Description: 页面头部组件控件项
 * @Date: 2021-08-12 16:31:29
-->
<template>
  <div class="page-title">
    <span class="page-title__label">
      {{ title }}
      <slot name="breadcrumb"></slot>
    </span>
    <div class="page-title__action">
      <slot></slot>
    </div>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from 'vue'
  const props = {
    title: { type: String, default: '' },
  }
  export default defineComponent({
    name: 'PageTitle',
    props,
  })
</script>

<style scoped lang="less">
  .page-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 36px;

    &__label {
      display: flex;
      align-items: center;
      color: #44454d;
      font-weight: 500;
      font-size: 16px;
      line-height: 22px;

      &::before {
        margin-right: 15px;
        width: 4px;
        height: 16px;
        border-radius: 2px;
        background: #f36f4e;
        content: '';
      }

      :deep(a) {
        color: #44454d;

        // 在每个元素之后绘制 > （最后一个元素除外）
        &:not(:last-child):after {
          margin: 0 8px;
          color: rgba(0, 10, 33, 0.45);
          content: '>';
          line-height: 22px;
        }

        &:not(:first-child):not(:last-child) {
          color: rgba(0, 10, 33, 0.45);
        }

        // hover样式
        &:not(:last-child):hover {
          color: #f36f4e;
        }

        // 最后一级样式
        &:last-child {
          color: #f36f4e;
          cursor: default;
          pointer-events: none;
        }
      }
    }

    &__action {
      :deep(.ant-btn) {
        padding-right: 15px;
        padding-left: 15px;
        min-width: 80px;
        height: 36px;
        font-weight: 500;
        font-size: 14px;
        line-height: 1.25;

        &:not(.ant-btn-round) {
          border-radius: 6px;
        }

        & + .ant-btn {
          margin-left: 10px;
        }
      }
    }
  }
</style>
