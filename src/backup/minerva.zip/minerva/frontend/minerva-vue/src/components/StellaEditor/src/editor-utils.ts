// 计算字符串宽度
export const getStrWidth = (str: string): number => {
  const numberStr = str?.match(/\d/g)
  const englishStr = str?.match(/[a-z]/gi)
  const chineseStr = str?.match(/[^ -~]/g)
  const specialStr = str?.match(
    /[`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”       【】、；‘’，。、]/g,
  )
  const gap = 56 // margin + padding
  return (
    (numberStr ? numberStr.length * 7.7 : 0) +
    (englishStr ? englishStr.length * 8 : 0) +
    (chineseStr ? chineseStr.length * 12.2 : 0) +
    (specialStr ? specialStr.length * 7.7 : 0) +
    gap
  )
}

// 根据类型获取对应的模板标识
// 1.指标类型： {_code_} 如存在indexCode
// 2.字段类型：
// 模型维度：{#code#} type: dimension_model
// 普通维度：{@code@}  type: dimension
// 度量：{&code&} type: measuring
// 其他：{*code*} type: other
export const getKeyStr = (data): string => {
  if (data.indexCode) {
    return `{_${data.indexCode}_}`
  } else if (data.type === 'dimension') {
    return `{@${data.code}@}`
  } else if (data.type === 'dimension_model') {
    return `{#${data.modelFieldCode}#}`
  } else if (data.type === 'measuring') {
    return `{&${data.modelFieldCode}&}`
  } else {
    return `{*${data.modelFieldCode}*}`
  }
}

// 转换tag数据为HTML标签（判断类型为指标/模型字段）
export const transfromTagToHTML = (data): string => {
  // 指标
  if (data.indexType) {
    return transfromIndexTypeTagToHTML(data)
  }
  // 模型字段
  return transfromFieldTagToHTML(data)
}

// 转换字段Tag数据为HTML标签
export const transfromFieldTagToHTML = (data): string => {
  return `&nbsp;<input disabled title="${data.name}" key="${getKeyStr(data)}" value="${
    data.name
  }"  class="tag ${data.dataType || ''} ${data.type}" ${getKeyValueStrByObject(
    data,
  )} style="width: ${getStrWidth(data.name)}px;">&nbsp;`
}

// 转换指标Tag数据为HTML标签
export const transfromIndexTypeTagToHTML = (data): string => {
  return `&nbsp;<input disabled title="${data.indexName}" key="${getKeyStr(data)}" value="${
    data.indexName
  }"  class="tag ${data.indexType}" ${getKeyValueStrByObject(data)} style="width: ${getStrWidth(
    data.indexName,
  )}px;" onclick="onTagClick('${data.indexCode}','${data.indexName}')">&nbsp;`
}

// 根据传入数据，拼接所有字段、值字符串
export const getKeyValueStrByObject = (data: object): string => {
  let str = ''
  Object.keys(data).forEach((key) => {
    str += `${key}="${data[key] || ''}"`
  })
  return str
}

// 根据表达式获取字段信息，拼接HTML
export const getHTMLByAnalysis = (analysis: any) => {
  let HTML = analysis?.expression || ''
  // 根据分析中的字段列表信息，生成对应字符串模版，转移字段为html字符串替换express中对应模板
  analysis?.fieldList?.forEach((item) => {
    // 获取indexCode或code对应的模版字符串
    const templateStr = getKeyStr(item)
    // 转换当前数据为html字符串
    const HTMLstr = transfromTagToHTML(item)
    // 替换对应的模版字符串为html
    HTML = HTML.replaceAll(templateStr, HTMLstr)
  })
  return HTML
}
