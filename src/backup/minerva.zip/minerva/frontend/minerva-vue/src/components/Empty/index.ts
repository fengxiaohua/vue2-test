import Empty from './src/Empty.vue'

export { Empty }
