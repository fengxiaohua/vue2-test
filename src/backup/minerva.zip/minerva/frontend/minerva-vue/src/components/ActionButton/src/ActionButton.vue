<template>
  <div class="action-button">
    <a-tooltip>
      <!-- 按钮禁用被禁用时，显示提示信息，非禁用状态不显示禁用提示信息-->
      <template v-if="disabled && disabledText" #title>{{ disabledText }}</template>
      <!-- v-bind="$attrs" 用来继承a-button原有的功能 vue3移除了$listeners，合并到$attrs中 -->
      <!-- props中的disabled不选择继承，是为了处理$attrs.disabled的取值为空字符串的情况需要多次判断控制显示信息问题 -->
      <a-button v-bind="$attrs" :disabled="disabled">
        <slot name="icon"></slot>
        <slot></slot>
      </a-button>
    </a-tooltip>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue'
  export default defineComponent({
    name: 'ActionButton',
    // 设置根元素是否继承特性
    inheritAttrs: false,
    props: {
      // 按钮禁用状态，默认为false
      disabled: {
        type: Boolean,
        default: false,
      },
      // 按钮禁用时的提示信息
      disabledText: {
        type: String,
        default: null,
      },
    },
  })
</script>
