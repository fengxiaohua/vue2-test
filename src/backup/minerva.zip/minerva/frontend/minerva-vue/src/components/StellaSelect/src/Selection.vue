<template>
  <span class="select-selection-item" :title="data[fieldName]">
    {{ data[fieldName] }}
  </span>
</template>

<script lang="ts">
  export default defineComponent({
    name: 'Selection',
    props: {
      data: {
        type: Object,
        default: () => {},
      },
      fieldName: {
        type: String,
        default: 'title',
      },
    },
    setup() {
      return {}
    },
  })
</script>

<style lang="less" scoped>
  .select-selection-item {
    overflow: hidden;
    flex: 1;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: 400;

    &:focus {
      opacity: 0.4;
    }
  }
</style>
