<template>
  <div class="function-desc">
    <span v-if="!data">函数描述</span>
    <template v-else>
      <p>
        <span>函数名称：</span> <span>{{ data.funCN }}</span>
      </p>
      <p>
        <span>函数描述：</span> <span>{{ data.funDesc }}</span>
      </p>
      <p>
        <span>函数例子：</span> <span>{{ data.example }}</span>
      </p>
    </template>
  </div>
</template>

<script lang="ts">
  export default {
    name: 'FunctionDesc',
  }
</script>

<script lang="ts" setup>
  interface FunctionInfo {
    example?: string
    funCN?: string
    funDesc?: string
    funEN?: string
  }
  defineProps<{ data?: FunctionInfo | undefined }>()
</script>

<style lang="less" scoped>
  .function-desc {
    height: 74px;
    padding: 8px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    background: #fff;
    border-color: transparent;
    border-radius: 6px;
    font-size: 12px;

    & > span {
      color: #b0b7c3;
    }

    & > p {
      margin: 0;
      line-height: 1;

      span:first-child {
        font-weight: 500;
      }

      span:last-child {
        color: #787a81;
        font-weight: 400;
      }
    }
  }
</style>
