<template>
  <div
    class="select-input"
    @click="onFocus"
    :class="{
      'select-selection-focus': isFocus,
      'icon-hover': allowClear && (selectionList.length || searchValue),
    }"
  >
    <div class="select-selector">
      <div class="select-selection">
        <template v-if="maxTagCount">
          <SelectionItem
            v-for="item in computedSelectionList"
            :key="item"
            :data="item"
            :fieldName="fieldName"
            @on-remove="handleRemove"
          />
          <MaxTagCount
            v-if="selectionList.length > computedSelectionList.length"
            :restTagNumber="restTagNumber"
          />
        </template>
        <template v-else>
          <SelectionItem
            v-for="item in selectionList"
            :key="item"
            :data="item"
            :fieldName="fieldName"
            @on-remove="handleRemove"
          />
        </template>

        <!-- <div class="select-selection-item-suffix"> -->
        <div class="select-selection-search">
          <a-input
            ref="inputRef"
            class="select-selection-search-input"
            v-model:value="searchValue"
            @blur="onBlur"
            @keydown.delete="onDelete"
            :placeholder="selectionList.length ? '' : placeholder"
          />
          <!-- <span class="select-selection-search-mirror">&nbsp;</span> -->
        </div>
        <!-- </div> -->
      </div>
    </div>
    <div class="select-clear" v-if="allowClear">
      <Icon icon="guanbi" :size="12" @click.stop="clear" />
    </div>
  </div>
</template>

<script lang="ts">
  import SelectionItem from './SelectionItem.vue'
  import MaxTagCount from './MaxTagCount.vue'

  export default defineComponent({
    name: 'SingleSelection',
    components: { SelectionItem, MaxTagCount },
    props: {
      selectionList: {
        type: Array,
        default: () => [],
      },
      allowClear: {
        type: Boolean,
        default: false,
      },
      placeholder: {
        type: String,
        default: '请选择',
      },
      maxTagCount: {
        type: Number,
        default: null,
      },
      fieldName: {
        type: String,
        default: 'title',
      },
    },
    emits: ['on-search-change', 'on-remove-item', 'on-blur'],
    setup(props, context) {
      const inputRef = ref()
      const searchValue = ref<string>('')
      const isFocus = ref<boolean>(false)

      const computedSelectionList = computed(() => {
        let list: any = []
        if (props.selectionList.length > props.maxTagCount) {
          for (let i = 0; i < props.maxTagCount; i++) {
            list.push(props.selectionList[i])
          }
        } else {
          list = props.selectionList
        }
        return list
      })

      const restTagNumber = computed(() => {
        if (props.selectionList.length > props.maxTagCount) {
          return props.selectionList.length - computedSelectionList.value.length
        }
      })

      watch(
        () => props.selectionList,
        (value) => {
          console.log(value)
          searchValue.value = ''
        },
      )

      // 监听搜索值变化 触发tree的筛选
      watch(searchValue, (value) => {
        context.emit('on-search-change', value)
      })

      // select聚焦后手动聚焦input搜索框
      const onFocus = () => {
        inputRef.value.focus()
        isFocus.value = true
      }

      const onBlur = () => {
        if (props.selectionList.length !== 0) {
          setTimeout(() => {
            searchValue.value = ''
          }, 300)
        } else {
          context.emit('on-blur', searchValue.value)
        }
        isFocus.value = false
      }

      // 清除
      const clear = () => {
        searchValue.value = ''
        const clearType = 'multiple'
        context.emit('on-search-change', '', clearType)
      }

      // 移除节点选项 removeData 为要删除的子项
      const handleRemove = (removeData) => {
        context.emit('on-remove-item', 'click', removeData)
      }

      // input搜索框 键盘delete事件，搜索值为空，模拟删除tag列
      const onDelete = () => {
        if (!searchValue.value.length) {
          context.emit('on-remove-item', 'keyboard')
        }
      }

      return {
        inputRef,
        searchValue,
        isFocus,
        onFocus,
        onBlur,
        clear,
        handleRemove,
        onDelete,
        computedSelectionList,
        restTagNumber,
      }
    },
  })
</script>

<style lang="less" scoped>
  .select-input {
    position: relative;
    display: inline-block;
    border: 1px solid #dbdbdb;
    border-radius: 4px;
    background-color: #fff;
    font-size: 14px;
  }

  .icon-hover {
    &:hover {
      .select-clear {
        opacity: 0.3;
      }
    }
  }

  .input-opacity {
    opacity: 0 !important;
  }

  .select-selection-focus {
    border-color: #ff9d73;
    border-right-width: 1px !important;
    box-shadow: 0 0 0 2px #ff794a33;
  }

  .select-selector {
    position: relative;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    padding: 8px 24px 8px 11px;

    .select-selection {
      position: relative;
      display: flex;
      flex: auto;
      flex-wrap: wrap;
      width: 100%;

      .select-selection-search {
        flex: 1;

        .select-selection-search-input {
          position: relative;
          margin: 0;
          padding: 0;
          max-width: 100%;
          outline: none;
          border: none;
          border-color: #fff;
          background: transparent;
          // opacity: 0;

          appearance: none;

          &:focus {
            box-shadow: none;
          }
        }

        // .select-selection-search-mirror {
        //   position: absolute;
        //   top: 0;
        //   left: 0;
        //   z-index: 999;
        //   visibility: hidden;
        //   white-space: pre;
        // }
      }
    }
  }

  .select-clear {
    position: absolute;
    top: 50%;
    right: 7px;
    z-index: 2;
    margin-top: -11px;
    width: 12px;
    height: 12px;
    opacity: 0;
    cursor: pointer;
  }
</style>
