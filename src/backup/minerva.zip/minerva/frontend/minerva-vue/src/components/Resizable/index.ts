import Resizable from './Resizable.vue'
export { Resizable }
