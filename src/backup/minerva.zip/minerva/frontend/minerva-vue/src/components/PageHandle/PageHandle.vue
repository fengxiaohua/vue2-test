<!--
 * @Description: 页面筛选组件
 * @Date: 2022-05-18 17:30:46
-->

<template>
  <div v-if="hasBeforeExtra || hasAfterExtra" class="page-handle">
    <!-- 筛选项 -->
    <div v-if="hasBeforeExtra" class="page-handle__filters">
      <div class="hander_filter space-x-10px">
        <slot name="filters"></slot>
      </div>
    </div>
    <i class="page-handle__gap"></i>
    <!-- 操作项 -->
    <div v-if="hasAfterExtra" class="page-handle__actions">
      <div class="hander_filter space-x-10px">
        <slot name="actions"></slot>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue'
  export default defineComponent({
    name: 'PageHandle',
    computed: {
      // 是否存在‘筛选项’插槽控件
      hasBeforeExtra() {
        return !!this.$slots.filters
      },
      // 是否存在‘操作项’插槽控件
      hasAfterExtra() {
        return !!this.$slots.actions
      },
    },
  })
</script>

<style lang="less">
  .page-handle {
    display: flex;
    align-items: center;
    padding: 10px 0;

    .hander_filter {
      display: flex;
    }

    &__gap {
      flex: 1;
      min-width: 20px;
    }

    &__filters,
    &__actions {
      & div {
        display: flex;
        align-items: center;
      }
    }

    &__filters {
      .hander_filter {
        /* 输入框样式 */
        & > input,
        & > .ant-input-affix-wrapper {
          width: 180px;
          height: 40px;
          border-radius: 6px;
          line-height: 38px;
        }
        /* 下拉框样式 */
        & > .ant-select {
          min-width: 180px;
          border-radius: 6px;

          .ant-select-selector {
            height: 40px;
            border-radius: 6px;
            line-height: 38px;

            .ant-select-selection-search,
            .ant-select-selection-item {
              line-height: 38px;
            }
          }

          :deep(.ant-select-selection),
          :deep(.ant-select-selection__rendered) {
            height: 40px;
            border-radius: 6px;
            line-height: 38px;
          }

          :deep(.ant-select-selection__rendered) > ul > li {
            margin-top: 7px;
          }

          :deep(.ant-select-selection--multiple) {
            .ant-select-selection__clear,
            .ant-select-arrow {
              top: 50%;
            }
          }
        }

        /* 日期选择器样式 */
        & > .ant-picker {
          min-width: 180px;
          height: 40px;
          border-radius: 6px;
        }

        & > .ant-calendar-picker-input.ant-input {
          width: 340px;
          height: 40px;
          line-height: 1;

          .ant-calendar-range-picker-separator {
            vertical-align: text-top;
          }
        }
        /* 按钮样式 */
        & > button {
          padding-right: 10px;
          padding-left: 10px;
          min-width: 70px;
          height: 26px;
          border-radius: 32px;
          font-size: 13px;
          line-height: 1 !important;

          /* 查询按钮 */
          &.ant-btn-primary {
            padding-right: 10px;
            padding-left: 10px;
            height: 36px;
            border-radius: 6px;
            font-size: 14px;
          }
        }
      }
    }

    &__actions {
      & > div {
        justify-content: flex-end;
      }

      button {
        padding-right: 10px;
        padding-left: 10px;
        min-width: 70px;
        height: 26px;
        color: @primary-color;
        border-color: @primary-color;
        background: transparent;
        border-radius: 32px;
        font-size: 13px;
        display: flex;
        align-items: center;
        justify-content: center;

        &:hover,
        &:focus {
          background: transparent;
        }
      }
    }
  }
</style>
