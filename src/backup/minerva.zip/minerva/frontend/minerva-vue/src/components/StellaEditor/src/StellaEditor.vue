<template>
  <div
    ref="editorRef"
    class="stella-editor"
    :disabled="disabled"
    :contenteditable="contenteditable"
    @click="onEditorClick"
    @keyup="onEditorKeyup"
    @dragenter.prevent
    @dragover.prevent
    @dragleave.prevent
    @drop.stop.prevent="onDrop"
  ></div>
</template>

<script lang="ts">
  import tagDrag from '/@/libs/tag-drag'
  import { transfromFieldTagToHTML, transfromIndexTypeTagToHTML } from './editor-utils'
  import { Ref } from 'vue'
  import { Modal } from 'ant-design-vue'

  export default defineComponent({
    name: 'StellaEditor',
    props: {
      // 编辑器禁用状态
      disabled: {
        type: Boolean,
        default: false,
      },
      // 编辑器内容
      content: {
        type: String,
        default: '',
      },
      // 编辑器拖入内容（Tag）前验证事件
      beforeDrag: {
        type: Function,
        default: undefined,
      },
    },
    setup(props) {
      const contenteditable = ref(true)

      // 编辑框
      const editorRef = ref()
      // 定义最后光标对象
      let lastEditRange

      // 拖拽的类型
      let dragType = 'text'
      let dragContent = ref() // 拖拽进编辑框的内容

      // watch content
      watch(
        () => props.content,
        () => {
          onReset()
          onAddHtml(props.content)
          contenteditable.value = !props.disabled
          tagDrag.emit('on-tag-change', getContent())
        },
      )

      // 编辑框点击事件
      const onEditorClick = () => {
        // 获取选定对象
        var selection = getSelection() as Selection
        // 设置最后光标对象
        lastEditRange = selection.getRangeAt(0)
      }

      // 编辑框按键弹起事件
      const onEditorKeyup = () => {
        // 获取选定对象
        var selection = getSelection() as Selection
        // 设置最后光标对象
        lastEditRange = selection.getRangeAt(0)
        tagDrag.emit('on-tag-change', getContent())
      }

      // 测试添加html元素
      const testHTML = () => {
        onAddHtml(`&nbsp;<input class="tag string" readonly value="币种">&nbsp;`)
      }

      // 将新节点插入到某节点之后
      const insertAfter = (newNode, oldNode) => {
        var parent = oldNode.parentNode
        if (parent.lastChild == oldNode) {
          // 如果父元素的最后一个子节点是oldNode，直接添加到parent的最后
          parent.appendChild(newNode)
        } else {
          parent.insertBefore(newNode, oldNode.nextSibling) // 否则把新节点插入到旧节点的下一个兄弟节点处
        }
      }

      // 添加文本内容
      const onAddText = (val: string) => {
        // 获取输入框对象
        // var textInput = document.getElementById('textInput')
        // var textInput = '我测试一下'
        var textInput = val
        // 获取编辑框对象
        var edit = editorRef.value
        // 编辑框设置焦点
        edit.focus()
        // 获取选定对象
        var selection = getSelection() as Selection
        // 判断是否有最后光标对象存在
        if (lastEditRange) {
          // 存在最后光标对象，选定对象清除所有光标并添加最后光标还原之前的状态
          selection.removeAllRanges()
          selection.addRange(lastEditRange)
        }
        // 判断选定对象范围是编辑框还是文本节点
        if (selection?.anchorNode?.nodeName != '#text') {
          console.log('编辑框范围。则创建文本节点进行插入')

          // 如果是编辑框范围。则创建文本节点进行插入
          var newContent = document.createTextNode(textInput)
          if (edit.childNodes.length > 0) {
            // 如果文本框的子元素大于0，则表示有其他元素，则按照位置插入节点
            for (var i = 0; i < edit.childNodes.length; i++) {
              if (i === selection.anchorOffset - 1) {
                insertAfter(newContent, edit.childNodes[i])
                // edit.insertBefore(newContent, edit.childNodes[i])
              }
            }
          } else {
            // 否则直接插入一个元素
            edit.appendChild(newContent)
          }
          // 创建新的光标对象
          var range = document.createRange()
          // 光标对象的范围界定为新建的文本节点
          range.selectNodeContents(newContent)
          // 光标位置定位在文本节点的最大长度
          range.setStart(newContent, newContent.length + (textInput.includes('()') ? -1 : 0))
          // 使光标开始和光标结束重叠
          range.collapse(true)
          // 清除选定对象的所有光标对象
          selection.removeAllRanges()
          // 插入新的光标对象
          selection.addRange(range)
        } else {
          console.log('文本节点则先获取光标对象')
          // 如果是文本节点则先获取光标对象
          var range = selection.getRangeAt(0)
          // 获取光标对象的范围界定对象，一般就是textNode对象
          var textNode = range.startContainer
          // 获取光标位置
          var rangeStartOffset = range.startOffset
          // 文本节点在光标位置处插入新的文本内容
          textNode.insertData(rangeStartOffset, textInput)
          // 光标移动到到原来的位置加上新内容的长度（判断是否有()括号，有则光标向后一位）
          range.setStart(
            textNode,
            rangeStartOffset + textInput.length + (textInput.includes('()') ? -1 : 0),
          )
          // 光标开始和光标结束重叠
          range.collapse(true)
          // 清除选定对象的所有光标对象
          selection.removeAllRanges()
          // 插入新的光标对象
          selection.addRange(range)
        }
        // 更新记录最后光标对象
        lastEditRange = selection.getRangeAt(0)
      }

      // 添加html元素
      const onAddHtml = (htmlStr: string) => {
        // 获取编辑框对象
        var edit = editorRef.value
        // 编辑框设置焦点
        edit.focus()
        var selection, range
        selection = window.getSelection()
        // 判断是否有最后光标对象存在
        if (lastEditRange) {
          // 存在最后光标对象，选定对象清除所有光标并添加最后光标还原之前的状态
          selection.removeAllRanges()
          selection.addRange(lastEditRange)
        }
        if (selection.getRangeAt && selection.rangeCount) {
          range = selection.getRangeAt(0)
          range.deleteContents()
          // Range.createContextualFragment() would be useful here but is
          // non-standard and not supported in all browsers (IE9, for one)
          var el = document.createElement('div')
          el.innerHTML = htmlStr
          var frag = document.createDocumentFragment(),
            node,
            lastNode
          while ((node = el.firstChild)) {
            lastNode = frag.appendChild(node)
          }
          range.insertNode(frag)
          // Preserve the selection
          if (lastNode) {
            range = range.cloneRange()
            range.setStartAfter(lastNode)
            range.collapse(true)
            selection.removeAllRanges()
            selection.addRange(range)
          }

          // 更新记录最后光标对象
          lastEditRange = selection.getRangeAt(0)
        }
      }

      // 重置/清空编辑器内容
      const onReset = () => {
        editorRef.value.innerHTML = ''
      }

      // tag拖拽事件
      const onTagDrag = (data) => {
        dragType = 'node'
        if (data.dragNodeType === 'Field') {
          dragContent.value = transfromFieldTagToHTML(data)
        } else if (data.dragNodeType === 'IndexType') {
          dragContent.value = transfromIndexTypeTagToHTML(data)
        } else {
          console.warn('未定义的拖拽类型')
        }
      }

      // tag拖拽完成事件
      const onTagDragFinish = () => {
        // 拖拽完成后 获取当前内容
        tagDrag.emit('on-tag-change', getContent())
      }

      // tag点击事件
      const onTagClick = (code, name) => {
        tagDrag.emit('on-tag-click', { code, name })
      }

      // 启用监听
      tagDrag.on('on-tag-drag', onTagDrag)
      tagDrag.on('on-tag-drag-finish', onTagDragFinish)

      // 在组件卸载之前移除监听
      onBeforeUnmount(() => {
        tagDrag.off('on-tag-drag', onTagDrag)
        tagDrag.off('on-tag-drag-finish', onTagDragFinish)
        window['onTagClick'] = undefined
      })

      // 编辑框被拖拽内容事件
      const onDrop = () => {
        // 拖拽前事件执行
        if (props.beforeDrag) {
          props.beforeDrag(dragContent.value).then(() => {
            if (dragType === 'text') {
              onAddText(dragContent.value)
            } else {
              onAddHtml(dragContent.value)
            }
          })
          return
        }

        if (dragType === 'text') {
          onAddText(dragContent.value)
        } else {
          onAddHtml(dragContent.value)
        }
      }

      // 文本拖拽
      // const onTextDrag = () => {
      //   dragType = 'text'
      //   dragContent.value = `power()`
      // }

      // const onNodeDrag = () => {
      //   dragType = 'node'
      //   dragContent.value = `&nbsp;<input readonly type="button" value="客户昵称">&nbsp;`
      // }

      // 获取标签内容，递归查找所有标签，转译express表达式、tags标签数组
      const getExpressAndTags = (nodes: any, express: Ref<string>, tags: any[]) => {
        nodes.forEach((item) => {
          if (item.nodeName === 'DIV') {
            // div代表有换行，添加空格处理
            express.value += ' '
            // Div容器，内容可能包含更多复杂内容，childNodes继续循环获取
            getExpressAndTags(item.childNodes, express, tags)
          } else if (item.nodeName === '#text') {
            express.value += item.nodeValue
          } else if (
            item.nodeName === 'INPUT' &&
            (item.getAttribute('indexType') === 'base_index' ||
              item.getAttribute('indexType') === 'derivation_index')
          ) {
            // 指标Tag类型indexType: base_index derivation_index
            express.value += item.getAttribute('key')
            tags.push({
              indexCode: item.getAttribute('indexCode'),
              indexName: item.getAttribute('indexName'),
              indexType: item.getAttribute('indexType'),
              indexTypeName: item.getAttribute('indexTypeName'),
              dataType: item.getAttribute('dataType'),
              dataTypeName: item.getAttribute('dataTypeName'),
              dataLength: item.getAttribute('dataLength'),
              dataPrecision: item.getAttribute('dataPrecision'),
              status: item.getAttribute('status'),
            })
          } else if (item.nodeName === 'INPUT') {
            // 模型字端Tag类型type： dimension_model dimension measuring other
            express.value += item.getAttribute('key')
            tags.push({
              code: item.getAttribute('code'),
              name: item.getAttribute('name'),
              type: item.getAttribute('type'),
              modelFieldCode: item.getAttribute('modelFieldCode'),
              modelCode: item.getAttribute('modelCode'),
              dataType: item.getAttribute('dataType'),
              dataTypeName: item.getAttribute('dataTypeName'),
              dataLength: item.getAttribute('dataLength'),
              dataPrecision: item.getAttribute('dataPrecision'),
              status: item.getAttribute('status'),
            })
          } else if (item.nodeName === 'SPAN') {
            express.value += item.innerText
          } else if (item.nodeName === 'BR') {
            // 换行，暂不处理
          }
        })
      }

      // 获取编辑器内容（cotent表达式、contentHTML编辑器富文本、tags所有tag标签的数据对象）
      const getContent = () => {
        let express = ref(''),
          tags: any = []
        // 获取表达式、tags
        getExpressAndTags(editorRef.value.childNodes, express, tags)
        return { content: express.value, contentHTML: editorRef.value.innerHTML, tags }
      }

      onMounted(() => {
        // 添加tag点击事件
        window['onTagClick'] = onTagClick
        if (props.content) {
          onReset()
          onAddHtml(props.content)
          tagDrag.emit('on-tag-change', getContent())
        }
        contenteditable.value = !props.disabled

        // editorRef.value.innerHTML = `<input readonly="" key="{*DimensionDemo*}" value="Dimension23" code="DimensionDemo" class="tag DT_STRING" style="width: 125.4px;"> asdjsalk  <input readonly="" key="{*DimensionDemo*}" value="Dimension23" code="DimensionDemo" class="tag DT_NUMBER" style="width: 125.4px;"> asdjsalk11`
        // onAddHtml(
        //   `&nbsp;<input readonly="" key="{*DimensionDemo*}" value="Dimension23" code="DimensionDemo" class="tag DT_DATE" style="width: 125.4px;">&nbsp;&nbsp;<input readonly="" key="{*DimensionDemo*}" value="Dimension23" code="DimensionDemo" class="tag DT_STRING" style="width: 125.4px;">&nbsp;select`,
        // )

        // editorRef.value.focus()
        // const selection = window.getSelection() as Selection
        // if (selection.getRangeAt && selection.rangeCount) {
        //   lastEditRange = selection.getRangeAt(0)
        // }
        // console.log('lastEditRange', lastEditRange)
        // const str = `case when <input class="tag number" value="账户金额" readonly>  power( <input class="tag string" value="币种" readonly> )`
        // editorRef.value.innerHTML = str
        // todo 生成、解析
        // 1.生成带符号的字符串给后端：case when {#code#} from table
        // 2.获取带符号的字符串从后端，解析成编辑器可识别的html，逐一添加：
        //   1. case when
        //   2. {#code#} -> <input>
        //   3. from table
      })

      return {
        editorRef,
        contenteditable,
        onEditorClick,
        onEditorKeyup,
        onAddText,
        onAddHtml,
        onReset,
        testHTML,
        onDrop,
        dragContent,
        getContent,
        onTagClick,
        transfromFieldTagToHTML,
        transfromIndexTypeTagToHTML,
      }
    },
  })
</script>

<style scoped lang="less">
  // 编辑框添加placeholder效果
  div[contenteditable]:empty:before {
    color: #b0b7c3;
    content: attr(placeholder);
  }

  div[contenteditable]:focus {
    content: none;
  }

  .stella-editor {
    overflow: auto;
    padding: 10px;
    height: 100%;
    border-radius: 6px;
    background: #fff;
    word-break: break-all;

    &[disabled='true'] {
      border: 1px solid #eeeeee;
      background: #f9f9f9;
      cursor: not-allowed;
    }

    :deep(input) {
      display: inline-block;
      margin: 3px;
      padding: 3px 25px;
      max-width: 500px;
      height: 24px;
      outline: none;
      border-width: 1px;
      border-style: solid;
      border-radius: 12px;
      color: #999;
      text-align: center;
      font-size: 12px;
      line-height: 24px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      background: #fff;
    }
  }
</style>
