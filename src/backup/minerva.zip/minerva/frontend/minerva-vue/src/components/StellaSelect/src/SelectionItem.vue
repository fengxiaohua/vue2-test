<template>
  <div class="select-selection-item" :title="data[fieldName]">
    <span class="select-selection-item-content">{{ data[fieldName] }}</span>
    <span class="select-selection-item-remove">
      <Icon icon="close" :size="12" class="remove-icon" @click.stop="remove(data)" />
    </span>
  </div>
</template>

<script lang="ts">
  export default defineComponent({
    name: 'SelectionItem',
    props: {
      data: {
        type: Object,
        default: () => {},
      },
      fieldName: {
        type: String,
        default: 'title',
      },
    },
    emits: ['onRemove'],
    setup(props, context) {
      watch(
        () => props.data,
        (value) => {
          console.log('11', value)
        },
      )
      watch(
        () => props.fieldName,
        (value) => {
          console.log('fieldName', value)
        },
      )
      const remove = (removeData) => {
        context.emit('onRemove', removeData)
      }
      return { remove }
    },
  })
</script>

<style lang="less" scoped>
  .select-selection-item {
    position: relative;
    display: flex;
    overflow: hidden;
    align-self: center;
    flex: none;
    box-sizing: border-box;
    margin-bottom: 2px;
    max-width: 100%;
    border: 1px solid #f0f0f0;
    border-radius: 2px;
    background: #f5f5f5;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: 400;
    cursor: default;
    transition: font-size 0.3s, line-height 0.3s, height 0.3s;

    user-select: none;
    margin-inline-end: 4px;
    padding-inline-start: 8px;
    padding-inline-end: 4px;

    .select-selection-item-content {
      display: inline-block;
      overflow: hidden;
      margin-right: 4px;
      text-overflow: ellipsis;
    }

    .select-selection-item-remove {
      width: 12px;
    }

    .remove-icon {
      opacity: 0.4;

      &:hover {
        opacity: 1;
        cursor: pointer;
      }
    }
  }
</style>
