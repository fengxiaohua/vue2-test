<template>
  <span class="step-number">0{{ number }}</span>
</template>

<script lang="ts">
  export default {
    name: 'StepNumber',
    props: {
      number: {
        type: Number,
        default: () => {
          return 1
        },
      },
    },
  }
</script>

<style lang="less" scoped>
  .step-number {
    display: inline-block;
    font-size: 60px;
    font-weight: 600;
    line-height: 1;
    margin-bottom: 2.5vh;
    color: #8c8f96;
  }
</style>
