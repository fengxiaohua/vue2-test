/*
 * @Description:
 * @Date: 2022-05-18 17:37:50
 */

import PageHandle from './PageHandle.vue'
export { PageHandle }
