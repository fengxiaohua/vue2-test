<template>
  <a-select
    v-model:value="selectValue"
    allow-clear
    @change="onChange"
    show-search
    :filter-option="filterOption"
  >
    <a-select-option :key="item[nameField]" :value="item[codeField]" v-for="item in list">
      {{ item[nameField] }}
    </a-select-option>
  </a-select>
</template>

<script lang="ts">
  export default {
    name: 'DataSelect',
  }
</script>

<script setup lang="ts">
  import { get } from 'lodash-es'

  const props = withDefaults(
    defineProps<{
      api: Function
      value: string | undefined
      name?: string | undefined
      listField?: string
      codeField?: string
      nameField?: string
    }>(),
    {
      listField: 'content',
      codeField: 'code',
      nameField: 'name',
    },
  )

  const selectValue = ref(props.value)

  watch(
    () => props.value,
    (value) => {
      selectValue.value = value
    },
  )

  const emit = defineEmits(['update:value', 'update:name', 'on-change'])

  const onChange = (value, option) => {
    emit('update:value', value)
    emit('update:name', option?.key)
    emit('on-change', option)
  }

  let list = ref([])

  onMounted(() => {
    if (props.api) {
      props.api().then((res) => {
        const listField = toRaw(props.listField)
        list.value = get(res, listField)
      })
    }
  })

  // 过滤筛选
  const filterOption = (input: string, option: any) => {
    return option.key.toLowerCase().indexOf(input.toLowerCase()) >= 0
  }
</script>
