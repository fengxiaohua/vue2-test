import DataSelect from './src/DataSelect.vue'

export { DataSelect }
