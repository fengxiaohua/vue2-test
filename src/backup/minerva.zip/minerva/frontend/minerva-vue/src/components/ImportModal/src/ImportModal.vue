<template>
  <a-modal
    :visible="importVisible"
    width="40%"
    title="导入"
    :maskClosable="false"
    @cancel="onCancel"
  >
    <a-form ref="formRef" :rules="rules" :model="formState">
      <a-form-item name="fileList">
        <a-upload-dragger
          :file-list="fileList"
          name="file"
          :max-count="1"
          :before-upload="beforeUpload"
          @remove="handleRemove"
          @change="onChange"
          accept=".xlsx"
          action=""
        >
          <p class="ant-upload-drag-icon">
            <inbox-outlined />
          </p>
          <p class="ant-upload-text"> 点击或将文件拖拽到这里上传（支持扩展名.xlsx） </p>
        </a-upload-dragger>
      </a-form-item>
    </a-form>
    <template #footer>
      <a-button
        v-if="templateApi"
        type="primary"
        class="float-left"
        ghost
        :loading="isDownloading"
        @click="onDownLoad"
        >下载导入模板
      </a-button>
      <a-button @click="onCancel">取消</a-button>
      <a-button type="primary" :loading="isConfirmLoading" @click="onUpload">上传</a-button>
    </template>
    <a-alert v-if="errMsg" message="校验失败" :description="errMsg" type="error" show-icon />
  </a-modal>
</template>

<script lang="ts">
  import { defineComponent } from 'vue'
  import { InboxOutlined } from '@ant-design/icons-vue'
  import { UploadProps, FormInstance, message } from 'ant-design-vue'
  import useDownload from '/@/hooks/web/useDownload'

  interface FormState {
    fileList: []
  }

  export default defineComponent({
    name: 'ImportModal',
    components: {
      InboxOutlined,
    },
    props: {
      importVisible: {
        type: Boolean,
        default: false,
      },
      // 模板api
      templateApi: {
        type: Function,
        default: null,
      },
      // 上传api
      uploadApi: {
        type: Function,
        default: null,
      },
      fileName: {
        type: String,
        default: '模板.xlsx',
      },
      errField: {
        type: String,
        default: 'errorMsg',
      },
    },
    emits: ['update:importVisible', 'import-success'],
    setup(props, content) {
      const isDownloading = ref<boolean>(false)
      const isConfirmLoading = ref<boolean>(false)
      const fileList = ref<UploadProps['fileList']>([])

      // 错误提示信息
      const errMsg = ref<string>('')
      // 表单组件对象
      const formRef = ref<FormInstance>()

      //表单对象
      const formState = reactive<FormState>({
        fileList: [],
      })

      /**
       * @description: 表单校验规则
       */
      const rules = reactive({
        fileList: [
          {
            required: true,
            message: '请选择上传的文件',
          },
        ],
      })

      /**
       * @description: 文件上传前的钩子函数
       */
      const beforeUpload: UploadProps['beforeUpload'] = (file) => {
        fileList.value = [file]
        formState.fileList.push(file)
        return false
      }

      /**
       * @description: 移除文件事件
       */
      const handleRemove = () => {
        formState.fileList = []
        fileList.value = []
        // 清除校验信息
        errMsg.value = ''
      }

      /**
       * @description: 文件change事件
       */
      const onChange = () => {
        // 清除校验信息
        errMsg.value = ''
      }

      /**
       * @description: 下载模板
       */
      const onDownLoad = () => {
        isDownloading.value = true
        props
          .templateApi()
          .then((res) => {
            useDownload(res, props.fileName)
          })
          .finally(() => {
            isDownloading.value = false
          })
      }

      /**
       * @description: 确认上传
       */
      const onUpload = () => {
        formRef.value?.validateFields().then(() => {
          isConfirmLoading.value = true
          const formData = new FormData()
          // 获取fileList中的数据
          fileList.value?.forEach((file: UploadProps['fileList'][number]) => {
            formData.append('file', file as any)
          })
          props
            .uploadApi(formData)
            .then(() => {
              message.success('导入成功')
              content.emit('update:importVisible')
              content.emit('import-success')
            })
            .catch((err) => {
              if (props.errField === 'checkMsg') {
                const { checkMsg, notNull } = err.content
                const msg = (checkMsg ? checkMsg : '') + (notNull ? notNull : '')
                errMsg.value = msg
              } else {
                errMsg.value = err.content[props.errField]
              }
              message.error('导入失败')
            })
            .finally(() => {
              isConfirmLoading.value = false
            })
        })
      }

      /**
       * @description 关闭弹窗
       */
      const onCancel = () => {
        content.emit('update:importVisible')
      }

      return {
        fileList,
        isConfirmLoading,
        errMsg,
        formState,
        formRef,
        rules,
        beforeUpload,
        handleRemove,
        onChange,
        onUpload,
        onCancel,
        onDownLoad,
        isDownloading,
      }
    },
  })
</script>

<style scoped>
  .float-left {
    float: left;
  }
</style>
