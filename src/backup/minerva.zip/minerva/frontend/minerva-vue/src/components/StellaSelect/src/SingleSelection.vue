<template>
  <div
    class="select-input"
    @click="onFocus"
    :class="{
      'select-selection-focus': isFocus,
      'icon-hover': allowClear && (selection[fieldName] || searchValue),
    }"
  >
    <div class="select-selector">
      <div class="select-selection">
        <div class="select-selection-search">
          <a-input
            ref="inputRef"
            v-model:value="searchValue"
            @blur="onBlur"
            :placeholder="selection[fieldName] ? '' : placeholder"
          />
        </div>
        <Selection
          :class="{ 'input-opacity': searchValue.length }"
          :data="selection"
          :fieldName="fieldName"
        />
      </div>
    </div>
    <div class="select-clear" v-if="allowClear">
      <Icon icon="guanbi" :size="12" @click.stop="clear" />
    </div>
    <div class="select-arrow">
      <Icon icon="down" :size="12" />
    </div>
  </div>
</template>

<script lang="ts">
  import Selection from './Selection.vue'

  export default defineComponent({
    name: 'SingleSelection',
    components: { Selection },
    props: {
      selection: {
        type: Object,
        default: () => {},
      },
      allowClear: {
        type: Boolean,
        default: false,
      },
      placeholder: {
        type: String,
        default: '请选择',
      },
      fieldName: {
        type: String,
        default: 'title',
      },
    },
    emits: ['on-search-change', 'on-blur'],
    setup(props, context) {
      const inputRef = ref()
      const searchValue = ref<string>('')
      const isFocus = ref<boolean>(false)

      watch(
        () => props.selection,
        (value) => {
          console.log(value)
          searchValue.value = ''
        },
      )

      // 监听搜索值变化 触发tree的筛选
      watch(searchValue, (value) => {
        context.emit('on-search-change', value)
      })

      // select聚焦后手动聚焦input搜索框
      const onFocus = () => {
        inputRef.value.focus()
        isFocus.value = true
      }

      const onBlur = () => {
        // data对象不为空，不保留搜索值作为value
        if (Object.keys(props.selection).length !== 0) {
          setTimeout(() => {
            searchValue.value = ''
          }, 300)
        } else {
          context.emit('on-blur', searchValue.value)
        }
        isFocus.value = false
      }

      // 清除
      const clear = () => {
        searchValue.value = ''
        const clearType = 'single'
        context.emit('on-search-change', '', clearType)
      }
      return { inputRef, searchValue, isFocus, onFocus, onBlur, clear }
    },
  })
</script>

<style lang="less" scoped>
  .select-input {
    position: relative;
    display: inline-block;
    border: 1px solid #dbdbdb;
    border-radius: 4px;
    background-color: #fff;
    font-size: 14px;
  }

  .icon-hover {
    &:hover {
      .select-clear {
        opacity: 0.3;
      }

      .select-arrow {
        opacity: 0;
      }
    }
  }

  .input-opacity {
    opacity: 0 !important;
  }

  .select-selection-focus {
    border-color: #ff9d73;
    border-right-width: 1px !important;
    box-shadow: 0 0 0 2px #ff794a33;
  }

  .select-selector {
    position: relative;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    padding: 8px 24px 8px 11px;
    height: 40px;

    .select-selection {
      position: relative;
      display: flex;
      flex: auto;
      flex-wrap: wrap;
      width: 100%;
      height: 22px;

      .select-selection-search {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;

        :deep(.ant-input) {
          margin: 0;
          padding: 0;
          width: 100%;
          outline: none;
          border: none;
          border-color: #fff;
          background: transparent;

          appearance: none;

          &:focus {
            box-shadow: none;
          }
        }
      }
    }
  }

  .select-clear {
    position: absolute;
    top: 50%;
    right: 7px;
    z-index: 2;
    margin-top: -11px;
    width: 12px;
    height: 12px;
    opacity: 0;
    cursor: pointer;
  }

  .select-arrow {
    position: absolute;
    top: 50%;
    right: 7px;
    z-index: 1;
    margin-top: -11px;
    width: 12px;
    height: 12px;
    opacity: 0.3;
    cursor: pointer;
  }
</style>
