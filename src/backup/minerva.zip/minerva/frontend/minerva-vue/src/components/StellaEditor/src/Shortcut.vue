<template>
  <div class="shortcut" v-if="list.length > 0">
    <ul class="flex">
      <li v-for="item in list" :key="item">
        <a-button @click="onClick(item)">{{ item }}</a-button>
      </li>
      <li v-if="showMore">
        <a-button @click="onMore">
          更多函数
          <Icon icon="actions-overflow-menu--vertical" />
        </a-button>
      </li>
    </ul>
  </div>
</template>

<script lang="ts">
  export default {
    name: 'Shortcut',
  }
</script>

<script lang="ts" setup>
  withDefaults(
    defineProps<{
      showMore?: boolean
      list: string[]
    }>(),
    {
      showMore: false,
      list: () => [],
    },
  )

  const emit = defineEmits(['on-more', 'on-click'])

  const onMore = () => {
    emit('on-more')
  }

  const onClick = (val) => {
    emit('on-click', val)
  }
</script>

<style scoped lang="less">
  .shortcut {
    height: 26px;
    background: #ffffff;
    border-radius: 4px;
    color: #9395a1;
    font-size: 14px;
    font-weight: 400;

    ul {
      padding: 0 13px 0 30px;

      li {
        margin-right: 10px;
        font-size: 16px;

        .ant-btn {
          height: 26px;
          min-width: 16px;
          padding: 0 5px;
          color: #b0b7c3;
          border: 0;

          &:hover {
            color: @primary-color;
          }
        }
      }
    }
  }
</style>
