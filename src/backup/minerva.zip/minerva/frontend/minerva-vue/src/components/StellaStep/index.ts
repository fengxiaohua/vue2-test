import StellaStep from './src/StellaStep.vue'
import StepNumber from './src/StepNumber.vue'

export { StellaStep, StepNumber }
