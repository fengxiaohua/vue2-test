<template>
  <div class="stella-step flex flex-col items-center justify-between">
    <!-- steps -->
    <div class="steps text-center">
      <!-- step number -->
      <StepNumber v-if="showStepNumber" :number="current" />
      <div
        v-for="(item, index) in steps"
        :key="index"
        class="step-item"
        :class="{ active: current - 1 === index }"
      >
        <div class="step-item__title"> {{ item.title }}</div>
        <div class="flex flex-col items-center" v-show="index !== steps.length - 1">
          <div class="step-item__icon"></div>
          <div class="step-item__line"></div>
        </div>
      </div>
    </div>

    <!-- actions -->
    <a-space class="step-actions flex flex-col">
      <a-button v-if="current > 1" shape="round" @click="onPrev">上一步</a-button>
      <a-button
        v-if="current < steps.length"
        :loading="isStepLoading"
        shape="round"
        type="primary"
        @click="onNext"
        >下一步</a-button
      >
      <a-button
        v-if="current === steps.length"
        :loading="isStepLoading"
        shape="round"
        type="primary"
        @click="onComplete"
        >确定</a-button
      >
      <a-button shape="round" @click="onCancel">取消</a-button>
    </a-space>
  </div>
</template>
<script lang="ts">
  export default {
    name: 'StellaStep',
    props: {
      // steps data
      steps: {
        type: Array,
        default: () => {
          return []
        },
      },
      // 当前步骤
      current: {
        type: Number,
        default: () => {
          return 1
        },
      },
      // 是否隐藏 step number
      showStepNumber: {
        type: Boolean,
        default: () => {
          return true
        },
      },
      // 是否隐藏 step number
      isStepLoading: {
        type: Boolean,
        default: () => {
          return false
        },
      },
    },
    emits: ['on-prev', 'on-next', 'on-complete', 'on-cancel'],
    setup(props, context) {
      const onPrev = () => {
        context.emit('on-prev', props.current)
      }

      const onNext = () => {
        context.emit('on-next', props.current)
      }

      const onComplete = () => {
        context.emit('on-complete', props.current)
      }

      const onCancel = () => {
        context.emit('on-cancel', props.current)
      }

      return { onPrev, onNext, onComplete, onCancel }
    },
  }
</script>
<style lang="less" scoped>
  .stella-step {
    padding: 0 10px;

    .step-item {
      &.active {
        .step-item__title {
          color: #474850;
          font-weight: 600;
        }

        .step-item__icon {
          border: 2px solid @primary-color;
          box-shadow: 0 0 4px @primary-color;
        }

        .step-item__line {
          background: linear-gradient(
              to bottom,
              @primary-color,
              @primary-color 2.5px,
              transparent 5.5px,
              transparent
            )
            0% 0% / 100% 6px;
        }
      }

      &__title {
        margin-top: 8px;
        margin-bottom: 8px;
        font-size: 12px;
        color: #999;
        line-height: 1;
      }

      &__icon {
        margin-bottom: 5px;
        width: 12px;
        height: 12px;
        background: #ffffff;
        border: 1px solid #8c8f97;
        border-radius: 50px;
      }

      &__line {
        width: 2px;
        height: 11vh;
        background: linear-gradient(
            to bottom,
            #e2e2e2,
            #e2e2e2 2.5px,
            transparent 5.5px,
            transparent
          )
          0% 0% / 100% 6px;
      }
    }

    .step-actions {
      margin-top: 2.5vh;

      .ant-btn {
        width: 100px;
      }
    }
  }
</style>
