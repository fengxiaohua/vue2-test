<template>
  <a-dropdown
    placement="bottom"
    :trigger="trigger"
    v-bind="$attrs"
    overlayClassName="more-action-btn"
  >
    <span>
      <slot></slot>
    </span>
    <template #overlay>
      <a-menu :selectedKeys="selectedKeys">
        <template v-for="item in dropMenuList" :key="`${item.event}`">
          <div class="triangle"></div>
          <a-menu-item
            v-bind="getAttr(item.event)"
            @click="handleClickMenu(item)"
            :disabled="item.disabled"
          >
            <a-tooltip v-if="item.disabled">
              <template v-if="item.disabledText" #title>
                <span>{{ item.disabledText }}</span>
              </template>
              <a-popconfirm
                v-if="popconfirm && item.popConfirm"
                v-bind="getPopConfirmAttrs(item.popConfirm)"
              >
                <template #icon v-if="item.popConfirm.icon">
                  <Icon :icon="item.popConfirm.icon" />
                </template>
                <div>
                  <Icon :icon="item.icon" v-if="item.icon" />
                  <span class="ml-1">{{ item.text }}</span>
                </div>
              </a-popconfirm>
              <template v-else>
                <Icon :icon="item.icon" v-if="item.icon" />
                <span class="ml-1">{{ item.text }}</span>
              </template>
            </a-tooltip>
            <template v-else>
              <a-popconfirm
                v-if="popconfirm && item.popConfirm"
                v-bind="getPopConfirmAttrs(item.popConfirm)"
              >
                <template #icon v-if="item.popConfirm.icon">
                  <Icon :icon="item.popConfirm.icon" />
                </template>
                <div>
                  <Icon :icon="item.icon" v-if="item.icon" />
                  <span class="ml-1">{{ item.text }}</span>
                </div>
              </a-popconfirm>
              <template v-else>
                <Icon :icon="item.icon" v-if="item.icon" />
                <span class="ml-1">{{ item.text }}</span>
              </template>
            </template>
          </a-menu-item>
          <a-menu-divider v-if="item.divider" :key="`d-${item.event}`" />
        </template>
      </a-menu>
    </template>
  </a-dropdown>
</template>

<script lang="ts" setup>
  import { computed, PropType } from 'vue'
  import type { DropMenu } from './typing'
  import { Dropdown, Menu, Popconfirm } from 'ant-design-vue'
  import { Icon } from '/@/components/Icon'
  import { omit } from 'lodash-es'
  import { isFunction } from '/@/utils/is'

  const ADropdown = Dropdown
  const AMenu = Menu
  const AMenuItem = Menu.Item
  const AMenuDivider = Menu.Divider
  const APopconfirm = Popconfirm

  const props = defineProps({
    popconfirm: Boolean,
    /**
     * the trigger mode which executes the drop-down action
     * @default ['hover']
     * @type string[]
     */
    trigger: {
      type: [Array] as PropType<('contextmenu' | 'click' | 'hover')[]>,
      default: () => {
        return ['contextmenu']
      },
    },
    dropMenuList: {
      type: Array as PropType<(DropMenu & Recordable)[]>,
      default: () => [],
    },
    selectedKeys: {
      type: Array as PropType<string[]>,
      default: () => [],
    },
  })

  const emit = defineEmits(['menuEvent'])

  function handleClickMenu(item: DropMenu) {
    const { event } = item
    const menu = props.dropMenuList.find((item) => `${item.event}` === `${event}`)
    emit('menuEvent', menu)
    item.onClick?.()
  }

  const getPopConfirmAttrs = computed(() => {
    return (attrs) => {
      const originAttrs = omit(attrs, ['confirm', 'cancel', 'icon'])
      if (!attrs.onConfirm && attrs.confirm && isFunction(attrs.confirm))
        originAttrs['onConfirm'] = attrs.confirm
      if (!attrs.onCancel && attrs.cancel && isFunction(attrs.cancel))
        originAttrs['onCancel'] = attrs.cancel
      return originAttrs
    }
  })

  const getAttr = (key: string | number) => ({ key })
</script>
<style lang="less">
  // 更多按钮弹出框样式
  .more-action-btn {
    .ant-dropdown-content {
      position: relative;
    }
    .ant-dropdown-menu {
      padding: 5px;
      border: 1px solid @dropdown-light-border;
      border-radius: 10px;
      box-shadow: 0px 4px 8px 0px rgba(28, 41, 90, 0.04);
      list-style: none;
      .ant-dropdown-menu-item {
        color: @primary-color;
        text-align: center;
      }
      .ant-dropdown-menu-item-disabled {
        color: rgba(0, 0, 0, 0.25);
      }
    }
    .ant-menu-item-divider {
      border: none;
    }
    // 三角样式
    &.ant-dropdown-placement-bottom {
      .ant-dropdown-content {
        .triangle {
          position: absolute;
          top: -5px;
          right: 45%;
          width: 9px;
          height: 9px;
          border-top: 1px solid @dropdown-light-border;
          border-left: 1px solid @dropdown-light-border;
          background: #fff;
          transform: rotate(45deg);
        }
      }
    }
    &.ant-dropdown-placement-top {
      .ant-dropdown-content {
        .triangle {
          position: absolute;
          right: 40%;
          bottom: 2px;
          width: 9px;
          height: 9px;
          border-top: 1px solid @dropdown-light-border;
          border-left: 1px solid @dropdown-light-border;
          background: #fff;
          transform: rotate(225deg);
          transform-origin: bottom;
        }
      }
    }
  }
</style>
