// 新增模型基类型
export interface BaseItemModalData {
  title: string
  desc: string
  icon: string
  [propName: string]: string
}

export interface ModalDataItem {
  title?: String
  icon?: string
  data: Array<BaseItemModalData>
}

export interface ChooseModalProps {
  modalTitle: String
  sourceData: Array<ModalDataItem>
}

export interface ChooseModalInstance {
  setChooseModalProps(addModelProp: Partial<ChooseModalProps>)
}

export type Register = (ChooseModalInstance: ChooseModalInstance) => void

export type useAddModelReturnType = [Register, ChooseModalInstance]
