import FormDetail from './src/FormDetail.vue'

export { FormDetail }
