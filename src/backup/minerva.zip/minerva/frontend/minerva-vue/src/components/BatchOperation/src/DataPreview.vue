<template>
  <a-modal
    :visible="dataPreviewVisible"
    width="80%"
    title="数据预览"
    :bodyStyle="{
      'overflow-y': 'hidden',
      display: 'flex',
      'flex-direction': 'column',
      'max-height': '100vh',
    }"
    :maskClosable="false"
    @change="close"
    :footer="null"
  >
    <div class="count_content">
      <Icon icon="wodechanpin" class="icon margin_r" :size="60" />
      <div class="content">
        <span class="content_title">{{ baseInfo.title }}</span>
        <div class="content_count_info">
          <div class="margin_r font_color">{{ countInfo.rowNum }} 行</div>
          <div class="margin_r font_color">{{ countInfo.colNum }} 列</div>
          <div v-if="updateTime" class="margin_r font_color"
            >最近数据更新时间：{{ countInfo.updateTime }}</div
          >
        </div>
      </div>
    </div>
    <span class="datanum font_color">预览 {{ countInfo.previewNum }} 条数据</span>
    <BasicTable @register="registerTable" />
  </a-modal>
</template>

<script lang="ts">
  import Icon from '/@/components/Icon'
  // 表格插件
  import { BasicTable, useTable } from '/@/components/Table'
  import type { BasicColumn } from '/@/components/Table/src/types/table'

  interface CountInfo {
    rowNum: Number | String // 行数
    colNum: Number | String // 列数
    previewNum: Number | String // 预览数据总条数
    updateTime?: String // 最近更新时间
  }
  export default defineComponent({
    name: 'DataPreview',
    props: {
      // 上一级‘数据预览’按钮loading
      isPreviewBtnLoading: {
        type: Boolean,
        default: () => true,
      },
      // 基础信息
      baseInfo: {
        type: Object,
        default: () => {},
      },
      // 预览数据总数统计api
      previewCountApi: {
        type: Function,
      },
      // 预览数据api
      previewApi: {
        type: Function,
      },
      // 能否预览数据api
      ablePreviewApi: {
        type: Function,
      },
    },
    components: {
      Icon,
      BasicTable,
    },
    emits: ['update:baseInfo', 'update:isPreviewBtnLoading'],
    setup(props, { emit }) {
      const { baseInfo } = toRefs(props)
      // 弹框
      const dataPreviewVisible = ref(false)
      // loading
      const isLoading = ref(false)
      // 表格数据
      const tableData = ref(<any[]>[])
      // 表格列配置
      let columns: BasicColumn[] = []
      // 初始化统计信息
      const initCountInfo = () => {
        return {
          rowNum: 0,
          colNum: 0,
          previewNum: 0,
          updateTime: '',
        }
      }
      // 统计信息
      let countInfo = reactive<CountInfo>(initCountInfo())

      watch(baseInfo, (newValue) => {
        getData(newValue)
      })

      // 表格组件配置
      const [registerTable] = useTable({
        dataSource: tableData,
        loading: isLoading,
        columns: columns, // 表格列配置
        pagination: false, // 是否分页
        showIndexColumn: false, // 是否展示序号
        canResize: true, // 是否可响应
        bordered: true, // 显示边框线
        striped: false, // 斑马纹
      })

      // 关闭
      const close = () => {
        dataPreviewVisible.value = false
        emit('update:baseInfo', {})
        Object.assign(countInfo, initCountInfo())
        resetTable()
      }

      // 重置表格数据
      const resetTable = () => {
        columns.length = 0
        tableData.value = []
      }

      /**
       * @description: 获取预览数据
       * @param {*} params
       * @return {*}
       */
      const getData = (params) => {
        if (props.ablePreviewApi) {
          props
            .ablePreviewApi(params.code)
            .then((res) => {
              if (res.content) {
                dataPreviewVisible.value = true
                isLoading.value = true
                getPreviewData(params)
                getPreviewCountData(params)
              }
            })
            .finally(() => {
              emit('update:isPreviewBtnLoading', false)
            })
        } else {
          dataPreviewVisible.value = true
          isLoading.value = true
          getPreviewData(params)
          getPreviewCountData(params)
        }
      }

      // 预览数据
      const getPreviewData = (params) => {
        if (props.previewApi) {
          props
            .previewApi(params.code)
            .then(({ content }) => {
              content.columnList?.forEach((item) => {
                const tmp = {
                  title: item.chineseName,
                  dataIndex: item.englishName,
                  resizable: true,
                  minWidth: 160,
                  width: 160,
                }
                columns.push(tmp)
              })
              tableData.value = content.dataList
            })
            .finally(() => {
              isLoading.value = false
            })
        }
      }

      // 预览总数统计
      const getPreviewCountData = (params) => {
        if (props.previewCountApi) {
          props.previewCountApi(params.code).then(({ content }) => {
            countInfo.colNum = content.fieldNum
            countInfo.rowNum = content.countNum
            countInfo.previewNum = content.previewNum
            countInfo.updateTime = content.lastUpdateTime
          })
        }
      }
      return {
        tableData,
        isLoading,
        dataPreviewVisible,
        close,
        registerTable,
        resetTable,
        getData,
        getPreviewData,
        getPreviewCountData,
        initCountInfo,
        countInfo,
      }
    },
  })
</script>
<style lang="less" scoped>
  .count_content {
    display: flex;
    flex: 1;

    .icon {
      color: #ff794a;
    }

    .content {
      text-align: left;
      line-height: 30px;
    }

    .margin_r {
      margin-right: 25px;
    }

    .content_title {
      font-weight: bold;
    }

    .content_count_info {
      display: flex;
      flex: 1;
    }
  }

  .font_color {
    color: #9395a2;
    font-weight: bold;
  }

  .datanum {
    line-height: 40px;
  }

  :deep(.ant-table-container) {
    border: 1px solid #dbdbdb;
    border-top: none;

    .ant-table-thead .ant-table-cell:last-child {
      border-right: none;
    }

    .ant-table-body .ant-table-row .ant-table-cell:last-child {
      border-right: none;
    }
  }
</style>
