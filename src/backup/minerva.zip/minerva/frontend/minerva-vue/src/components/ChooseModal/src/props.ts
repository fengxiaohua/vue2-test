import { ModalDataItem } from './typing'
export const ChooseModalProps = {
  isModalShow: { type: Boolean, default: () => false },
  modalTitle: { type: String, default: () => '' },
  sourceData: { type: Array as PropType<ModalDataItem[]>, default: () => [] },
}
