<!--
 * @Description: MorePopover中的项
-->
<template>
  <li>
    <slot></slot>
  </li>
</template>

<script>
  export default {
    name: 'MorePopoverItem',
  }
</script>
