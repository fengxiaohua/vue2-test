import StellaSelect from './src/StellaSelect.vue'

export { StellaSelect }
