<template>
  <a-modal
    :title="`批量${operationName}${fieldName}`"
    :visible="visible"
    width="40%"
    :maskClosable="false"
    :confirm-loading="isConfirmLoading"
    @cancel="cancel"
    @ok="handleOk"
  >
    <div class="form">
      <a-form ref="formRef" :model="form" :rules="formRules" layout="vertical">
        <a-form-item :label="`${operationName}说明`" name="remark">
          <a-textarea
            v-model:value="form.remark"
            :placeholder="`请输入${fieldName}${operationName}说明`"
            :auto-size="{ minRows: 3, maxRows: 3 }"
          />
        </a-form-item>
      </a-form>
    </div>
    <a-alert v-if="tip" :message="tip" banner />
    <div class="content">
      <div class="content-title">
        已选择要{{ operationName + '的' + fieldName + '(' + selectedContent.length }}项)?
      </div>
      <ul>
        <li v-for="(item, index) in selectedContent" :key="index">{{ item }}</li>
      </ul>
    </div>
  </a-modal>
</template>

<script lang="ts">
  import { FormInstance } from 'ant-design-vue'
  import { defineComponent } from 'vue'
  import { rules, FormRule } from '/@/utils/rules/index'

  export default defineComponent({
    name: 'BatchOperation',
    props: {
      visible: {
        type: Boolean,
        default: false,
      },
      operationName: {
        type: String,
        default: null,
      },
      fieldName: {
        type: String,
        default: null,
      },
      tip: {
        type: String,
        default: null,
      },
      selectedContent: {
        type: Array,
        default: () => [],
      },
    },
    emits: ['update:visible', 'on-confirm'],
    setup(props, context) {
      //表单对象
      let form = reactive({
        remark: '',
      })

      // 表单组件对象
      const formRef = ref<FormInstance>()

      // 表单校验规则
      const formRules: Record<string, FormRule[]> = {
        remark: [
          {
            validator: rules.regDesc,
            trigger: ['change', 'blur'],
          },
        ],
      }

      // 确认提交loading
      const isConfirmLoading = ref<boolean>(false)

      const cancel = () => {
        context.emit('update:visible')
      }

      const handleOk = () => {
        // 校验
        formRef.value?.validateFields().then(() => {
          context.emit('on-confirm')
        })
      }

      context.expose({ form, isConfirmLoading })

      return {
        formRef,
        form,
        formRules,
        isConfirmLoading,
        cancel,
        handleOk,
      }
    },
  })
</script>
<style lang="less" scoped>
  .form {
    margin-bottom: 10px;
  }

  .content {
    margin-top: 10px;

    .content-title {
      margin-bottom: 10px;
      font-weight: 500;
    }

    ul {
      overflow: auto;
      margin: 0;
      padding-left: 20px;
      max-height: 30vh;
      list-style: disc;
    }

    li {
      margin: 0;
      color: rgba(0, 0, 0, 0.65);
    }
  }
</style>
