<!--
 * @Description: 单个筛选过滤内容
 * @Date: 2022-03-29 10:17:00
-->
<template>
  <div class="filters-content__item" :label="label">
    <slot></slot>
  </div>
</template>

<script lang="ts">
  export default {
    name: 'FilterPopoverItem',
  }
</script>

<script lang="ts" setup>
  defineProps<{
    label: String
  }>()
</script>

<style lang="less" scoped>
  @input-bg-color: #fff;

  .filters-content__item {
    display: flex;
    height: 36px;
    border-radius: 6px;
    background-color: #edeef2;

    &::before {
      display: flex;
      align-items: center;
      flex-shrink: 0;
      justify-content: center;
      width: 80px;
      height: 100%;
      border-radius: 6px 0 0 6px;
      background-color: #aeb7c4;
      color: #fff;
      content: attr(label);
      font-size: 12px;
    }

    & + .filters-content__item {
      margin-top: 10px;
    }

    :deep(input) {
      padding-right: 25px;
      padding-left: 25px;
      height: 100%;
      border-radius: 0 6px 6px 0;
      background-color: @input-bg-color;
    }

    :deep(.ant-picker) {
      width: 100%;
      border-radius: 0 6px 6px 0;
    }

    :deep(.ant-select) {
      width: 100%;

      .ant-select-arrow {
        top: 50%;
      }

      .ant-select-selection__clear {
        top: 50%;
      }

      .ant-select-selection-search {
        margin-inline-start: 0;
      }

      .ant-select-selector {
        padding: 0 25px;
        height: 100%;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        background-color: @input-bg-color;

        .ant-select-selection-placeholder {
          padding: 0 14px;
          line-height: 34px;
        }
      }

      .ant-select-selection-item {
        line-height: 34px;

        .ant-select-selection-item-content {
          line-height: 23px;
        }

        .ant-select-selection-item-remove {
          line-height: 23px;
        }
      }

      .ant-select-selection__rendered {
        margin-right: 25px;
        margin-left: 25px;
        height: 100%;
        line-height: 34px;
      }
    }
  }

  :deep(.ant-select.ant-select-single .ant-select-selector .ant-select-selection-placeholder) {
    padding: 0;
  }
</style>
