import Tag from './src/Tag.vue'

export { Tag }
