<!--
 * @Description: 更多popover弹框
-->
<template>
  <a-popover placement="bottom" trigger="click" overlay-class-name="filters-popover">
    <template #content>
      <div class="filters-content">
        <div class="filters-content__header">筛选过滤条件</div>
        <div class="filters-content__list">
          <slot></slot>
        </div>
        <div class="filters-content__footer">
          <a-button ghost type="primary" @click="reset"> 重置 </a-button>
        </div>
      </div>
    </template>
    <a-button class="filters-btn" ghost type="primary">
      筛选过滤
      <Icon icon="filter" size="15" />
    </a-button>
  </a-popover>
</template>

<script lang="ts">
  export default {
    name: 'FilterPopover',
  }
</script>

<script lang="ts" setup>
  import { Icon } from '/@/components/Icon'

  // 声明emits
  const emit = defineEmits<{
    (e: 'reset'): void
  }>()

  // 重置表单
  const reset = () => {
    emit('reset')
  }
</script>

<style lang="less" scoped>
  @input-bg-color: #fff;
  @border-color-base: #dbdbdb;
  /* 筛选条件-内容样式  */
  .filters-content {
    min-width: 400px;

    &__header {
      display: flex;
      align-items: center;
      padding: 25px;
      height: 40px;
      border-bottom: 1px solid @border-color-base;
      color: #44454d;
      font-weight: 400;
      font-size: 14px;
      line-height: 22px;

      &::before {
        margin-right: 12px;
        width: 3px;
        height: 14px;
        border-radius: 1px;
        background: linear-gradient(180deg, #f69c66 0%, #ffb572 100%) #f36f4e;
        content: '';
      }
    }

    &__list {
      padding: 10px 25px;

      // 聚焦输入 光标居中
      :deep(.ant-select-selection-search) {
        display: flex;
        align-items: center;
      }
    }

    &__footer {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      padding: 0 25px;
      height: 55px;
      border-top: 1px solid @border-color-base;
    }
  }

  .filters-btn {
    padding: 0 17px !important;
    height: 40px !important;
    border-radius: 6px !important;
    background-color: #ffffff !important;
    font-size: 13px !important;
  }
</style>

<style lang="less">
  /* 筛选条件弹出层 */
  .filters-popover {
    .ant-popover-arrow {
      top: 8px !important;
      background: #fff;
      box-shadow: -1px -1px 1px #f9b6a1 !important;
      transform: rotate(45deg);
    }

    .ant-popover-inner {
      border: 1px solid #f9b6a1;
      border-radius: 6px;
      box-shadow: 0px 4px 8px 0px rgb(28 41 90 / 4%);
    }

    .ant-popover-inner-content {
      padding: 0px;
    }
  }
</style>
