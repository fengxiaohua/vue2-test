import MonacoEditor from './src/index.vue'

export { MonacoEditor }
