<template>
  <a-popover
    trigger="click"
    v-model:visible="visible"
    overlayClassName="select-popover"
    :overlayStyle="{ width: selectWidth }"
  >
    <MultipleSelection
      v-if="multiple"
      ref="multipleRef"
      :placeholder="placeholder"
      :selectionList="selectionList"
      :allowClear="allowClear"
      :maxTagCount="maxTagCount"
      :fieldName="fieldNames.title"
      @on-search-change="onSearchChange"
      @on-remove-item="onRemoveItem"
      @on-blur="onBlur"
    />
    <SingleSelection
      v-else
      ref="singleRef"
      :placeholder="placeholder"
      :selection="selection"
      :allowClear="allowClear"
      :fieldName="fieldNames.title"
      @on-search-change="onSearchChange"
      @on-blur="onBlur"
    />
    <template #content>
      <Empty v-if="treeData.length === 0 || (searchValue && filterData.length === 0)" />
      <a-tree
        class="tree"
        v-else
        v-bind="$attrs"
        :expanded-keys="expandedKeys"
        :auto-expand-parent="autoExpandParent"
        :tree-data="searchValue ? filterData : treeData"
        :field-names="fieldNames"
        @expand="onExpand"
        @select="onSelect"
        :multiple="multiple"
        :selectedKeys="selectedKey"
      >
        <!-- <template #title="{ title }">
          <span v-if="title.indexOf(searchValue) > -1" class="tree-node__title">
            {{ title.substr(0, title.indexOf(searchValue)) }}
            <span class="tree-node__title" style="color: #f50">{{ searchValue }}</span>
            {{ title.substr(title.indexOf(searchValue) + searchValue.length) }}
          </span>
          <span v-else class="tree-node__title">{{ title }}</span>
        </template> -->
      </a-tree>
    </template>
  </a-popover>
</template>

<script lang="ts">
  import { TreeProps } from 'ant-design-vue'
  import SingleSelection from './SingleSelection.vue'
  import MultipleSelection from './MultipleSelection.vue'

  export default defineComponent({
    name: 'StellaSelect',
    components: { SingleSelection, MultipleSelection },
    inheritAttrs: false,
    props: {
      value: {
        type: Array,
        default: () => [],
      },
      treeData: {
        type: Object,
        default: () => {},
      },
      multiple: {
        type: Boolean,
        default: false,
      },
      placeholder: {
        type: String,
        default: '请选择',
      },
      selectWidth: {
        type: String,
        default: '180px',
      },
      allowClear: {
        type: Boolean,
        default: false,
      },
      maxTagCount: {
        type: Number,
        default: null,
      },
      fieldNames: {
        type: Object,
        default: () => {
          return {
            title: 'title',
            key: 'key',
            children: 'children',
          }
        },
      },
    },
    emits: ['update:value'],
    setup(props, context) {
      const searchValue = ref<string>('')
      const expandedKeys = ref<(string | number)[]>([])
      const autoExpandParent = ref<boolean>(true)
      const selectWidthProps = ref<string>(props.selectWidth)
      const filterData = ref<TreeProps['treeData']>()

      const selectedKey = ref<(string | number)[]>([])

      const selectionList = ref<any[]>([])
      const selection = ref<any>({})

      const singleRef = ref()
      const multipleRef = ref()

      const visible = ref<boolean>(false)

      const onExpand = (keys: string[]) => {
        expandedKeys.value = keys
        autoExpandParent.value = false
      }

      // 搜索值变化回调
      const onSearchChange = (val, clearType) => {
        searchValue.value = val
        if (clearType === 'single') {
          selectedKey.value = []
          selection.value = {}
          context.emit('update:value', [])
        } else if (clearType === 'multiple') {
          selectedKey.value = []
          selectionList.value.length = 0
          context.emit('update:value', [])
        }
      }

      // 多选模式 删除某项回调
      const onRemoveItem = (deleteType, removeData) => {
        if (deleteType === 'click') {
          const index = selectionList.value.findIndex((item) => item === removeData)
          if (index > -1) {
            selectionList.value.splice(index, 1)
            selectedKey.value.splice(index, 1)
          }
        } else if (deleteType === 'keyboard') {
          const index = selectionList.value.length - 1
          selectionList.value.splice(index, 1)
          selectedKey.value.splice(index, 1)
        }
      }

      // 失去焦点回调
      const onBlur = (val) => {
        context.emit('update:value', [`${val}`])
      }

      //  递归过滤
      const recursionFilter = (treeData, value) => {
        let data = treeData.map((item) => {
          item = Object.assign({}, item)
          if (item.children && item.children.length > 0) {
            item.children = recursionFilter(item.children, value).filter(
              (item) =>
                item[props.fieldNames.title].indexOf(value) > -1 ||
                (item.children && item.children.length > 0),
            )
          }
          return item
        })
        return data
      }

      //  递归展开
      const recursionExpand = (treeData, expandedKeys) => {
        treeData.map((item) => {
          if (item.children && item.children.length > 0) {
            recursionExpand(item.children, expandedKeys)
            expandedKeys.push(item[props.fieldNames.key])
          }
        })
      }

      // 监听搜索值并过滤
      watch(searchValue, (value) => {
        let expanded: string[] = []
        filterData.value = recursionFilter(props.treeData, value).filter(
          (item) =>
            item[props.fieldNames.title].indexOf(value) > -1 ||
            (item.children && item.children.length > 0),
        )
        recursionExpand(filterData.value, expanded)
        // filterData.value?.forEach((item) => {
        //   if (item.children && item.children.length > 0) {
        //     expanded.push(item[props.fieldNames.key] as string)
        //   }
        // })
        if (value === '') {
          expanded = []
        }
        expandedKeys.value = expanded
        searchValue.value = value
        autoExpandParent.value = true
      })

      // 点击树节点触发
      const onSelect = (selectedKeys, { node }) => {
        console.log('onselect', selectedKeys, node.dataRef)
        context.emit('update:value', selectedKeys)
        selectedKey.value = selectedKeys
        if (props.multiple) {
          const index = selectionList.value.findIndex(
            (item) => item[props.fieldNames.key] == node.dataRef.key,
          )
          if (index > -1) {
            selectionList.value.splice(index, 1)
          } else {
            selectionList.value.push(node.dataRef)
          }
        } else {
          selection.value = node.dataRef
        }
      }

      return {
        visible,
        searchValue,
        filterData,
        expandedKeys,
        selectedKey,
        autoExpandParent,
        onExpand,
        selectWidthProps,
        onSelect,
        selection,
        selectionList,
        singleRef,
        multipleRef,
        onBlur,
        onSearchChange,
        onRemoveItem,
      }
    },
  })
</script>

<style lang="less">
  .select-popover {
    padding-top: 0;
    padding-bottom: 0;

    .ant-popover-content {
      .ant-popover-arrow {
        display: none;
      }

      .ant-popover-inner {
        border-radius: 6px;

        .ant-popover-inner-content {
          overflow: auto;
          max-height: 200px;

          .tree {
            .ant-tree-list {
              .ant-tree-treenode {
                .ant-tree-switcher-icon {
                  color: #fdc380;
                  font-size: 14px;
                }
              }
            }

            .tree-node__title {
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            }
          }
        }
      }
    }
  }
</style>
<style lang="less" scoped>
  .select-input {
    width: v-bind(selectWidthProps);
  }
</style>
