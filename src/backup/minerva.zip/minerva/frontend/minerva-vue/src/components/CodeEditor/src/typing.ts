export enum MODE {
  JSON = 'application/json',
  HTML = 'htmlmixed',
  JS = 'javascript',
  SQL = 'text/x-sql',
}
