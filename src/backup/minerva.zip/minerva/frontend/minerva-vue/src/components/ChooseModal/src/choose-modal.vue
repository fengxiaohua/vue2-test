<template>
  <a-modal
    :visible="isModalShow"
    width="50%"
    :title="getProps.modalTitle"
    :maskClosable="false"
    :footer="null"
    @cancel="cancel"
  >
    <a-collapse v-if="sourceDataLength > 1" v-model:activeKey="activeKey" :bordered="false">
      <a-collapse-panel
        v-for="(item, index) in getProps.sourceData"
        :key="index"
        :showArrow="false"
        class="collapse-content"
      >
        <template #header>
          <icon :icon="item.icon" size="20" />
          {{ item.title }}
        </template>
        <div
          v-for="row in item.data"
          :key="row.icon"
          class="collapse-content-row"
          @click="onChooseModalClick(row)"
        >
          <icon :icon="row.icon" size="35" />
          <div class="collapse-content-row-text">
            <div class="collapse-content-row-text__title">{{ row.title }}</div>
            <div class="collapse-content-row-text__desc">{{ row.desc }}</div>
          </div>
        </div>
      </a-collapse-panel>
    </a-collapse>

    <div v-else-if="sourceDataLength === 1">
      <div
        v-for="row in getProps.sourceData[0].data"
        :key="row.icon"
        class="collapse-content-row"
        @click="onChooseModalClick(row)"
      >
        <icon :icon="row.icon" size="35" />
        <div class="collapse-content-row-text">
          <div class="collapse-content-row-text__title">{{ row.title }}</div>
          <div class="collapse-content-row-text__desc">{{ row.desc }}</div>
        </div>
      </div>
    </div>

    <Empty v-else />
  </a-modal>
</template>

<script lang="ts" setup>
  import { ChooseModalProps } from './props'
  import type {
    ChooseModalProps as ChooseModalPropsType,
    ChooseModalInstance,
    BaseItemModalData,
  } from './typing'
  import Empty from '../../Empty/src/Empty.vue'

  // 定义props
  const props = defineProps(ChooseModalProps)
  const propsRef = ref<Partial<ChooseModalPropsType> | null>(null)

  const activeKey = ref()

  const getProps = computed(() => {
    return {
      ...props,
      ...(unref(propsRef) as Recordable),
    } as ChooseModalPropsType
  })

  const sourceDataLength = computed(() => {
    return unref(getProps).sourceData.length
  })

  const getDefaultActiveKeys = () => {
    const length = unref(getProps).sourceData.length
    let i = 0
    let res: number[] = []
    while (i < length) {
      res.push(i)
      i++
    }
    activeKey.value = res
  }

  //设置默认展开内容
  onMounted(() => {
    getDefaultActiveKeys()
  })

  const methods: ChooseModalInstance = {
    setChooseModalProps,
  }

  // 定义emit
  const emit = defineEmits<{
    (e: 'update:isModalShow', isModalShow: Boolean): void //更新弹框
    (e: 'register', methods: ChooseModalInstance): void // 注册组件信息
    (e: 'onClick', row: BaseItemModalData): void // 点击事件
  }>()

  emit('register', methods)

  console.log('props:', props)
  console.log('getProps:', getProps.value)

  const cancel = () => {
    emit('update:isModalShow', false)
  }

  const onChooseModalClick = (row: BaseItemModalData) => {
    emit('onClick', row)
  }

  /**
   * @description:设置组件参数
   */
  function setChooseModalProps(ChooseModalProps: Partial<ChooseModalPropsType>): void {
    propsRef.value = { ...(unref(propsRef) as Recordable), ...ChooseModalProps } as Recordable
  }
</script>

<style lang="less" scoped>
  .collapse-content {
    overflow: hidden;
    border: 0;
    border-radius: 4px;
    background: #f7f7f7;

    .senses-icons {
      margin-right: 10px;
    }

    &-row {
      display: flex;
      align-items: center;
      margin: 10px 0;
      padding: 10px 30px;
      // border: 1px solid #ffe6de;
      background: #e5e7eb5e;
      cursor: pointer;

      &:hover {
        border-color: transparent;
        box-shadow: 0 1px 2px -2px #00000029, 0 3px 6px #0000001f, 0 5px 12px 4px #00000017;
      }

      &-text {
        padding-left: 15px;

        &__title {
          font-weight: 500;
        }

        // &__desc {
        // }
      }
    }
  }

  :deep(.ant-collapse-content-box) {
    background: #fff;
  }

  :deep(.ant-collapse-header) {
    background: #fff9f2;
  }
</style>
