export { default as DictSelect } from './src/dict-select.vue'
