import { withInstall } from '/@/utils'
import basicUpload from './src/BasicUpload.vue'

export const BasicUpload = withInstall(basicUpload)
