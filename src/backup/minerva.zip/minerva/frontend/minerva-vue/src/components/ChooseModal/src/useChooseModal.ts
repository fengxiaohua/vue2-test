import type { ChooseModalProps, ChooseModalInstance, useAddModelReturnType } from './typing'

export function useChooseModal(props?: Partial<ChooseModalProps>): useAddModelReturnType {
  if (!getCurrentInstance()) {
    throw new Error('useChooseModal() can only be used inside setup() or functional components!')
  }
  const chooseModal = ref<Nullable<ChooseModalInstance>>(null)
  const loaded = ref(false)

  function register(instance: ChooseModalInstance) {
    if (unref(loaded)) {
      return
    }
    chooseModal.value = instance
    props && instance.setChooseModalProps(props)
    loaded.value = true
  }

  const methods: ChooseModalInstance = {
    setChooseModalProps: (chooseModalProp: Partial<ChooseModalProps>): void => {
      unref(chooseModal)?.setChooseModalProps(chooseModalProp)
    },
  }

  return [register, methods]
}
