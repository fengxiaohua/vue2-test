<template>
  <div
    class="form-detail"
    :class="{ 'form-detail-expand ': isExpand, 'form-detail-noExpand': !isExpand }"
  >
    <div class="content" :class="{ 'content-only-read': !isEdit }">
      <slot name="content"></slot>
    </div>
    <div class="action">
      <a-button class="action-btn" v-if="isEdit" @click="handleCancel">取消</a-button>
      <a-button class="action-btn" v-if="isEdit" :loading="confirmLoading" @click="handleConfirm">
        确认
      </a-button>
      <a-button
        type="link"
        :class="{ 'hide-expand': !showExpand }"
        v-if="!isEdit"
        class="icon-btn"
        @click="expand"
      >
        <Icon
          icon="xiangxia"
          size="12"
          :class="{ 'before-rotate': !isExpand, 'after-rotate': isExpand }"
        />
      </a-button>
      <a-button class="action-btn" v-if="!isEdit && hasEditPermission" @click="onEdit"
        >编辑</a-button
      >
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue'
  export default defineComponent({
    name: 'FormDetail',
    props: {
      maxHeight: {
        type: String,
        default: '150px',
      },
      showExpand: {
        type: Boolean,
        default: true,
      },
      canEdit: {
        type: Boolean,
        default: true,
      },
      confirmLoading: {
        type: Boolean,
        default: false,
      },
      hasEditPermission: {
        type: Boolean,
        default: true,
      },
    },
    emits: ['on-confirm', 'on-cancel', 'on-edit'],
    setup(props, context) {
      // 获取props中的maxHeight，用于绑定css展开高度样式
      const maxHeightProps = ref<string>(props.maxHeight)

      // 是否为编辑状态
      const isEdit = ref<boolean>(false)

      // 是否为展开状态
      const isExpand = ref<boolean>(false)

      // 点击按钮切换展开样式
      const expand = () => {
        isExpand.value = !isExpand.value
      }

      /**
       * @description: 编辑
       */
      const onEdit = () => {
        if (props.canEdit) {
          isExpand.value = true
          // 开启修改状态
          isEdit.value = true
        }
        context.emit('on-edit')
      }

      /**
       * @description: 点击取消按钮
       */
      const handleCancel = () => {
        context.emit('on-cancel')
      }

      /**
       * @description: 点击确认按钮
       */
      const handleConfirm = () => {
        context.emit('on-confirm')
      }

      // 向父组件暴露数据
      context.expose({ isEdit, isExpand })

      return {
        maxHeightProps,
        isEdit,
        onEdit,
        isExpand,
        expand,
        handleCancel,
        handleConfirm,
      }
    },
  })
</script>

<style lang="less" scoped>
  .form-detail-expand {
    overflow-y: scroll !important;
    max-height: v-bind(maxHeightProps) !important;
  }

  .form-detail-noExpand {
    :deep(.ant-input) {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }

  .form-detail {
    display: flex;
    overflow-x: auto;
    overflow-y: hidden;
    padding: 0 25px;
    max-height: 50px;
    width: 100%;
    border-radius: 6px;
    background: #fff;
    transition: max-height 0.3s;

    .content {
      flex: 1;
      margin-top: 24px;

      :deep(.ant-form) {
        display: flex;
        flex-flow: wrap;

        .ant-form-item {
          // min-width: 400px;
          width: 93%;

          .ant-form-item-label {
            & > label {
              color: #474850;
              font-weight: bold;
            }
          }

          .ant-form-item-control-input-content {
            color: #474850;
          }

          span {
            word-break: break-all;
          }
        }
      }
    }

    .content-only-read {
      margin-top: 5px;
      margin-bottom: 10px;

      // 非编辑状态 隐藏校验信息部分
      :deep(.ant-form-item) {
        margin-bottom: 0;
      }

      ::-webkit-input-placeholder {
        color: #fff;
      }

      :deep(.ant-form-item-label > label.ant-form-item-required::before) {
        display: none;
      }

      // input只读样式
      :deep(.ant-input) {
        border-color: #fff;
        color: #474850;
        cursor: default;
        pointer-events: none;

        &:focus {
          box-shadow: none;
        }

        &[disabled] {
          background-color: #fff;
          color: #474850;
        }
      }

      // input-number只读样式
      :deep(.ant-input-number) {
        border-color: #fff;
        cursor: default;
        pointer-events: none;

        // 隐藏input-number数值调整图标
        .ant-input-number-handler-wrap {
          display: none;
        }
      }

      :deep(.ant-input-number-disabled) {
        background-color: #fff;
        color: #474850;
      }

      // select只读样式
      :deep(.ant-select) {
        cursor: default;
        pointer-events: none;

        .ant-select-selector {
          border-color: #fff;
        }

        // 隐藏select下拉图标
        .ant-select-arrow {
          display: none;
        }
      }

      :deep(.ant-select-disabled.ant-select:not(.ant-select-customize-input) .ant-select-selector) {
        background-color: #fff;
        color: #474850;
      }
    }

    .action {
      display: flex;
      justify-content: flex-end;
      margin-top: 12px;

      .action-btn {
        margin-left: 10px;
        padding: 0 15px;
        min-width: 70px;
        height: 26px !important;
        border-color: @primary-color;
        border-radius: 32px;
        color: @primary-color;
        font-weight: 400;
        font-size: 13px;
      }

      .icon-btn {
        display: flex;
        align-items: center;
        height: 26px;
      }

      :deep(.ant-btn-link) {
        color: #ababab;
      }
    }
  }

  .before-rotate {
    transition: all 0.3s;
  }

  .after-rotate {
    transition: all 0.3s;
    transform: rotate(180deg);
  }

  .hide-expand {
    visibility: hidden;
  }
</style>
