import type { App } from 'vue'
import { TableAction, BasicTable } from './Table'
import { Empty } from './Empty'
import { Icon } from './Icon'
import { DataSelect } from './DataSelect'
import { DictSelect } from './DictSelect'
import { FilterPopover, FilterPopoverItem } from './FilterPopover'
import { ActionButton } from './ActionButton'
import { BatchOperation } from './BatchOperation'
import { Resizable } from './Resizable'
import { StellaEditor, Shortcut, Function, FunctionDesc } from './StellaEditor'
import { PageTitle } from './PageTitle'
import { PageHandle } from './PageHandle'
import { StellaStep, StepNumber } from './StellaStep'
import { Tag } from './Tag'
import { FormDetail } from './FormDetail'
import { ImportModal } from './ImportModal'
import { StellaSelect } from './StellaSelect'

// const components = [Empty, Icon, DataSelect]
export function registerGlobComp(app: App) {
  app.component(TableAction.name, TableAction)
  app.component(BasicTable.name, BasicTable)
  app.component(Empty.name, Empty)
  app.component(Icon.name, Icon)
  app.component(DataSelect.name, DataSelect)
  app.component(DictSelect.name, DictSelect)
  app.component(FilterPopover.name, FilterPopover)
  app.component(FilterPopoverItem.name, FilterPopoverItem)
  app.component(ActionButton.name, ActionButton)
  app.component(BatchOperation.name, BatchOperation)
  app.component(Resizable.name, Resizable)
  app.component(StellaEditor.name, StellaEditor)
  app.component(Shortcut.name, Shortcut)
  app.component(Function.name, Function)
  app.component(FunctionDesc.name, FunctionDesc)
  app.component(PageTitle.name, PageTitle)
  app.component(PageHandle.name, PageHandle)
  app.component(StellaStep.name, StellaStep)
  app.component(StepNumber.name, StepNumber)
  app.component(FormDetail.name, FormDetail)
  app.component(Tag.name, Tag)
  app.component(ImportModal.name, ImportModal)
  app.component(StellaSelect.name, StellaSelect)
}
