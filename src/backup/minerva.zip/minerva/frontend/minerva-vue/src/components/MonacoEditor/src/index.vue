<template>
  <div class="e-box">
    <div :id="editorId" class="editor-content"></div>
  </div>
</template>
<script lang="ts" setup>
  import jsonWorker from 'monaco-editor/esm/vs/language/json/json.worker?worker'
  import cssWorker from 'monaco-editor/esm/vs/language/css/css.worker?worker'
  import htmlWorker from 'monaco-editor/esm/vs/language/html/html.worker?worker'
  import tsWorker from 'monaco-editor/esm/vs/language/typescript/ts.worker?worker'
  import EditorWorker from 'monaco-editor/esm/vs/editor/editor.worker?worker'
  import { language as sqlLanguage } from 'monaco-editor/esm/vs/basic-languages/sql/sql.js'
  import * as monaco from 'monaco-editor'
  import { nextTick, onBeforeUnmount, watch } from 'vue'
  import { IPosition, Position } from 'monaco-editor'

  // 使用缓存
  import { useDataModalLibraryWithOut } from '/@/store/modules/dataModalLibrary'

  const dataModalLibraryStore = useDataModalLibraryWithOut()
  let dataModalSourceInfo
  onMounted(() => {
    dataModalSourceInfo = dataModalLibraryStore.getDataModalSourceInfo
  })

  const props = defineProps({
    editorValue: {
      type: String,
      default: '',
    },
    editorId: {
      type: String,
      default: '',
    },
    language: {
      type: String,
      default: 'sql',
    },
  })

  const emit = defineEmits(['update:editorValue'])
  //
  // MonacoEditor start
  //
  onBeforeUnmount(() => {
    editor.dispose()
  })
  // @ts-ignore
  self.MonacoEnvironment = {
    getWorker(_: string, label: string) {
      if (label === 'json') {
        return new jsonWorker()
      }
      if (label === 'css' || label === 'scss' || label === 'less') {
        return new cssWorker()
      }
      if (label === 'html' || label === 'handlebars' || label === 'razor') {
        return new htmlWorker()
      }
      if (['typescript', 'javascript'].includes(label)) {
        return new tsWorker()
      }
      return new EditorWorker()
    },
  }

  let editor: monaco.editor.IStandaloneCodeEditor
  let position = new Position(0, 0)
  const editorInit = () => {
    nextTick(() => {
      monaco.languages.typescript.javascriptDefaults.setDiagnosticsOptions({
        noSemanticValidation: true,
        noSyntaxValidation: false,
      })
      monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
        target: monaco.languages.typescript.ScriptTarget.ES2016,
        allowNonTsExtensions: true,
      })
      // 设置sql语言自动补全，使用Monaco自带的sql
      monaco.languages.registerCompletionItemProvider('sql', {
        provideCompletionItems: function () {
          const suggestions = [] as any
          sqlLanguage.keywords.forEach((item) => {
            suggestions.push({
              label: item,
              kind: monaco.languages.CompletionItemKind.Keyword,
              insertText: item,
            })
          })
          sqlLanguage.operators.forEach((item) => {
            suggestions.push({
              label: item,
              kind: monaco.languages.CompletionItemKind.Operator,
              insertText: item,
            })
          })
          sqlLanguage.builtinFunctions.forEach((item) => {
            suggestions.push({
              label: item,
              kind: monaco.languages.CompletionItemKind.Function,
              insertText: item,
            })
          })
          sqlLanguage.builtinVariables.forEach((item) => {
            suggestions.push({
              label: item,
              kind: monaco.languages.CompletionItemKind.Variable,
              insertText: item,
            })
          })
          return {
            suggestions: suggestions,
          }
        },
      })
      // 设置自定义背景颜色
      monaco.editor.defineTheme('GreyTheme', {
        base: 'vs',
        inherit: true,
        rules: [{ background: '#fffaf9' } as any, { token: 'string.sql', foreground: 'F66438' }],
        colors: {
          // 相关颜色属性配置
          'editor.background': '#fffaf9', //背景色
          'editorLineNumber.foreground': '#F66438', // 行数字颜色
          'editor.foreground': '#F66438', // 字体颜色
        },
      })
      //设置自定义主题
      monaco.editor.setTheme('GreyTheme')
      console.log('------', props.editorId)
      !editor
        ? (editor = monaco.editor.create(document.getElementById(props.editorId) as HTMLElement, {
            value: props.editorValue, // 编辑器初始显示文字
            language: props.language, // 语言支持自行查阅demo
            lineHeight: 20, // 设置行高
            padding: { top: 10, bottom: 10 },
            automaticLayout: true, // 自适应布局
            autoIndent: 'brackets', // 控制编辑器在用户键入、粘贴、移动或缩进行时是否应自动调整缩进
            foldingStrategy: 'indentation', // 代码可分小段折叠
            lineNumbersMinChars: 3,
            theme: 'GreyTheme', // 官方自带三种主题vs, hc-black, or vs-dark
            // 注释配置
            comments: {
              ignoreEmptyLines: true, // 插入行注释时忽略空行。默认为真。
              insertSpace: true, // 在行注释标记之后和块注释标记内插入一个空格。默认为真。
            },
            selectOnLineNumbers: true, // 显示行号
            overviewRulerBorder: false, // 是否应围绕概览标尺绘制边框
            scrollBeyondLastLine: false, // 设置编辑器是否可以滚动到最后一行之后
            renderLineHighlight: 'none', // 当前行突出显示方式  "all" | "line" | "none" | "gutter"
            roundedSelection: false,
            wordWrap: 'wordWrapColumn',
            wordWrapColumn: 140,
            contextmenu: false,
            // 代码缩略图(此处设置为关闭，默认为开启状态)
            minimap: {
              enabled: true, // 是否启用预览图
            },
            scrollbar: {
              // 滚动条设置
              verticalScrollbarSize: 10, // 竖滚动条
              horizontalScrollbarSize: 8, // 横滚动条
            },
            readOnly: false, // 只读
            fontSize: 14, // 字体大小
          }))
        : editor.setValue(props.editorValue)
      editor.onDidChangeModelContent((val) => {
        console.log('position', position, val)
        editor.setPosition({
          lineNumber: position.lineNumber,
          column: position.column,
        } as IPosition)
        emit('update:editorValue', editor.getValue())
      })
    })
  }
  editorInit()

  // @ts-ignore
  watch(
    () => props.language,
    (val) => {
      monaco.editor.setModelLanguage(editor.getModel()!, val)
    },
  )
  watch(
    () => props.editorValue,
    (val) => {
      // 获取修改数据之后的光标位置
      const pos = editor?.getPosition()
      position = position.with(pos?.lineNumber, pos?.column)
      editor?.setValue(val)
      dataModalSourceInfo.sqlContent = val
    },
  )
</script>
<style scoped lang="less">
  .editor-content {
    width: 100%;
    height: 100%;
  }

  .select {
    padding: 10px 0;
  }

  .submit {
    padding: 10px 0;
    text-align: center;
  }

  .e-box {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    box-sizing: border-box;
    // width: 100%;
    height: 100%;
  }
</style>
