<template>
  <div class="function">
    <div class="function__header flex items-center justify-between p-5px pt-8px">
      <span class="ml-5px">更多函数</span>
      <a-button>
        <Icon icon="close" @click="onClose" />
      </a-button>
    </div>
    <div class="function__content p-5px">
      <!-- 搜索 -->
      <div class="pl-5px pr-5px mb-10px">
        <a-input v-model:value="searchValue" size="small" placeholder="请输入函数名称" allowClear>
          <template #suffix v-if="!searchValue">
            <Icon icon="search" class="input-icon" />
          </template>
        </a-input>
      </div>
      <!-- 函数分类 -->
      <div v-loading="isLoading" class="flex-1 overflow-auto">
        <a-tree
          class="tree"
          :expanded-keys="expandedKeys"
          :auto-expand-parent="autoExpandParent"
          :tree-data="searchValue ? filterData : functionData"
          @select="onSelect"
          @expand="onExpand"
        >
          <template #title="{ title }">
            <span v-if="title.indexOf(searchValue) > -1" class="tree-node__title">
              {{ title.substr(0, title.indexOf(searchValue)) }}
              <span class="tree-node__title" style="color: #f50">{{ searchValue }}</span>
              {{ title.substr(title.indexOf(searchValue) + searchValue.length) }}
            </span>
            <span v-else class="tree-node__title">{{ title }}</span>
          </template>
        </a-tree>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { GetFuntionsApi } from '/@/api/index/library'
  import type { TreeProps } from 'ant-design-vue'

  // const genData: TreeProps['treeData'] = []
  // const dataList: TreeProps['treeData'] = []

  const getParentKey = (
    key: string | number,
    tree: TreeProps['treeData'] = [],
  ): string | number | undefined => {
    let parentKey
    for (let i = 0; i < tree.length; i++) {
      const node = tree[i]
      if (node.children) {
        if (node.children.some((item) => item.key === key)) {
          parentKey = node.key
        } else if (getParentKey(key, node.children)) {
          parentKey = getParentKey(key, node.children)
        }
      }
    }
    return parentKey
  }
  export default defineComponent({
    name: 'Function',
    emits: ['on-close', 'on-select', 'on-dbclick'],
    setup(props, context) {
      const expandedKeys = ref<(string | number)[]>([])
      const searchValue = ref<string>('')
      const autoExpandParent = ref<boolean>(true)
      const functionData = ref<TreeProps['treeData']>()
      const filterData = ref<TreeProps['treeData']>()
      const isLoading = ref<boolean>(true)

      onMounted(() => {
        getFuntions()
      })

      // 获取函数列表
      const getFuntions = () => {
        isLoading.value = true
        GetFuntionsApi()
          .then((res) => {
            functionData.value = res.content.map((item) => {
              item.title = item.categoryCN
              item.key = item.categoryEN
              item.children = item.functionList.map((f) => {
                f.title = f.funCN
                f.key = f.funEN
                return f
              })
              delete item.categoryCN
              delete item.categoryEN
              delete item.functionList
              return item
            })
          })
          .finally(() => {
            isLoading.value = false
          })
      }

      const onExpand = (keys: string[]) => {
        expandedKeys.value = keys
        autoExpandParent.value = false
      }

      watch(searchValue, (value) => {
        // const expanded =
        //   functionData.value &&
        //   functionData.value
        //     .map((item: TreeProps['treeData'][number]) => {
        //       if (item.title.indexOf(value) > -1) {
        //         return getParentKey(item.key, functionData.value)
        //       }
        //       return null
        //     })
        //     .filter((item, i, self) => item && self.indexOf(item) === i)
        let expanded: string[] = []
        filterData.value = []
        functionData.value?.forEach((item: TreeProps['treeData'][number]) => {
          const newItem = { ...item }
          newItem.children = item.children.filter((val) => val.title.indexOf(value) > -1)
          newItem.children && newItem.children.length > 0 && expanded.push(newItem.key)
          newItem.children && newItem.children.length > 0 && filterData.value?.push(newItem)
        })
        if (value === '') {
          expanded = []
        }
        expandedKeys.value = expanded
        searchValue.value = value
        autoExpandParent.value = true
      })

      // 关闭函数组件展示
      const onClose = () => {
        context.emit('on-close')
      }

      const treeClickCount = ref(0)
      const lastSelect = ref()

      // 节点选择事件
      const onSelect = (keys, e) => {
        if (!e.node.parent) {
          return
        }
        const { dataRef } = e.node
        context.emit('on-select', dataRef)
        // 判断上次记录选中节点是否为同一节点，否则重新记录
        if (lastSelect.value?.funEN !== dataRef?.funEN) {
          treeClickCount.value = 1
          lastSelect.value = dataRef
          return
        }

        // 记录点击次数
        treeClickCount.value++

        // 单次点击次数超过2次不作处理,直接返回
        if (treeClickCount.value > 2) {
          return
        }

        // 计时器
        setTimeout(() => {
          if (treeClickCount.value > 1) {
            treeClickCount.value = 0
            context.emit('on-dbclick', dataRef.funEN)
          }
        }, 150)
      }

      // 节点双击事件
      const onDbClick = (data) => {
        console.log('onDbClick', data)
        context.emit('on-dbclick', data)
      }

      return {
        isLoading,
        expandedKeys,
        searchValue,
        autoExpandParent,
        functionData,
        filterData,
        onExpand,
        onClose,
        onSelect,
        onDbClick,
      }
    },
  })
</script>

<style lang="less" scoped>
  .function {
    display: flex;
    flex-direction: column;
    width: 100%;
    border-radius: 6px;
    background: #ffffff;

    .input-icon {
      color: rgba(0, 0, 0, 0.25);
    }

    &__header {
      & > span {
        font-weight: 400;
        font-size: 13px;
      }

      .ant-btn {
        padding: 0 5px;
        height: 20px;
        border: 0;
        line-height: 1;

        & > i {
          color: #b0b7c3;
          font-size: 12px !important;

          &:hover {
            color: @primary-color;
          }
        }
      }
    }

    &__content {
      display: flex;
      overflow: auto;
      flex: 1;
      flex-direction: column;

      :deep(.tree.ant-tree) {
        .ant-tree-list {
          .ant-tree-switcher-icon {
            color: #fdc380;
            font-size: 14px;
          }
        }

        .tree-node__title {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
    }
  }
</style>
