import PageTitle from './index.vue'

export { PageTitle }
