// 资源管理中设置的`菜单权限标识/nodeEnName`与路由页面路径数据映射（todo：后端调整）
export default {
  home: '/home/index', // 首页
  library: '/index/library/Library', // 指标管理-指标库-指标库列表
  libraryStep: '/index/library/LibraryStep', // 指标管理-指标库-新建/编辑指标
  libraryDetail: '/index/library/LibraryDetail', // 指标管理-指标库-新建/编辑指标
  assetPackage: '/index/asset-package/AssetPackage', // 指标管理-指标资产包
  newIndicatorPackage: '/index/asset-package/newIndicatorPackage', // 指标管理-指标资产包-新建/编辑资产包
  assetPackageDetail: '/index/asset-package/assetPackageDetail', // 指标管理-指标资产包详情
  class: '/index/class/Class', // 指标管理-分类管理
  dimensionManage: '/dimension-manage/index', // 模型管理 -> 维度管理
  addDimension: '/dimension-manage/AddDimension', // 模型管理 -> 维度管理 -> 新增维度
  dimensionDetail: '/dimension-manage/DimensionDetail', // 模型管理 -> 维度管理 -> 维度详情
  dispatchRunning: '/running/DispatchRunning', // 运行管理-例行运行
  handRunning: '/running/HandRunning', // 运行管理-手动运行
  dataModel: '/data-model/index', // 模型管理 -> 数据模型
  measureManage: '/measure-manage/index', // 模型管理 -> 度量管理
  addDataModal: '/data-model/add-data-modal', // 模型管理 -> 数据模型 -> 新增模型
  editDataModal: '/data-model/edit-data-modal', // 模型管理 -> 数据模型 -> 编辑模型
}
