import type { AppRouteRecordRaw, Menu } from '/@/router/types'

import { defineStore } from 'pinia'
import { store } from '/@/store'
import { useI18n } from '/@/hooks/web/useI18n'
import { useUserStore } from './user'
import { useAppStoreWithOut } from './app'
import { toRaw } from 'vue'
import { transformObjToRoute, flatMultiLevelRoutes } from '/@/router/helper/routeHelper'
import { transformRouteToMenu } from '/@/router/helper/menuHelper'

import projectSetting from '/@/settings/projectSetting'

import { PermissionModeEnum } from '/@/enums/appEnum'

import { asyncRoutes } from '/@/router/routes'
import { ERROR_LOG_ROUTE, PAGE_NOT_FOUND_ROUTE } from '/@/router/routes/basic'

import { filter } from '/@/utils/helper/treeHelper'

import { getMenuList } from '/@/api/sys/menu'
// import { getPermCode } from '/@/api/sys/user'

import { useMessage } from '/@/hooks/web/useMessage'
import { PageEnum } from '/@/enums/pageEnum'

import { useOrigin } from '/@/hooks/web/useAsset'

import routerPermission from '/@/settings/routerPermissionSettting'
interface PermissionState {
  // 当前平台名称
  platformName: string
  // Permission code list
  permCodeList: string[]
  // Permission list
  permObj: Record<string, string>
  // Whether the route has been dynamically added
  isDynamicAddedRoute: boolean
  // To trigger a menu update
  lastBuildMenuTime: number
  // Backstage menu list
  backMenuList: Menu[]
  frontMenuList: Menu[]
}
export const usePermissionStore = defineStore({
  id: 'app-permission',
  state: (): PermissionState => ({
    // 当前平台名称
    platformName: '',
    // Permission code list
    permCodeList: [],
    // Permission list
    permObj: {},
    // Whether the route has been dynamically added
    isDynamicAddedRoute: false,
    // To trigger a menu update
    lastBuildMenuTime: 0,
    // Backstage menu list
    backMenuList: [],
    // menu List
    frontMenuList: [],
  }),
  getters: {
    getPlatformName(): string {
      return this.platformName
    },
    getPermCodeList(): string[] {
      return this.permCodeList
    },
    getPermObj(): Record<string, string> {
      return this.permObj
    },
    getBackMenuList(): Menu[] {
      return this.backMenuList
    },
    getFrontMenuList(): Menu[] {
      return this.frontMenuList
    },
    getLastBuildMenuTime(): number {
      return this.lastBuildMenuTime
    },
    getIsDynamicAddedRoute(): boolean {
      return this.isDynamicAddedRoute
    },
  },
  actions: {
    setPlatformName(name: string) {
      return (this.platformName = name)
    },

    setPermCodeList(codeList: string[]) {
      this.permCodeList = codeList
    },

    setPermObj(codeList: Record<string, string>) {
      this.permObj = codeList
    },

    setBackMenuList(list: Menu[]) {
      this.backMenuList = list
      list?.length > 0 && this.setLastBuildMenuTime()
    },

    setFrontMenuList(list: Menu[]) {
      this.frontMenuList = list
    },

    setLastBuildMenuTime() {
      this.lastBuildMenuTime = new Date().getTime()
    },

    setDynamicAddedRoute(added: boolean) {
      this.isDynamicAddedRoute = added
    },
    resetState(): void {
      this.isDynamicAddedRoute = false
      this.permCodeList = []
      this.backMenuList = []
      this.lastBuildMenuTime = 0
    },
    // 获取所有权限标识
    // async changePermissionCode() {
    //   const codeList = await getPermCode()
    //   this.setPermCodeList(codeList)
    // },
    // 获取所有路由
    async buildRoutesAction(): Promise<AppRouteRecordRaw[]> {
      const { t } = useI18n()
      const userStore = useUserStore()
      const appStore = useAppStoreWithOut()

      let routes: AppRouteRecordRaw[] = []
      const roleList = toRaw(userStore.getRoleList) || []
      const { permissionMode = projectSetting.permissionMode } = appStore.getProjectConfig

      const routeFilter = (route: AppRouteRecordRaw) => {
        const { meta } = route
        const { roles } = meta || {}
        if (!roles) return true
        return roleList.some((role) => roles.includes(role))
      }

      const routeRemoveIgnoreFilter = (route: AppRouteRecordRaw) => {
        const { meta } = route
        const { ignoreRoute } = meta || {}
        return !ignoreRoute
      }

      /**
       * @description 根据设置的首页path，修正routes中的affix标记（固定首页）
       * */
      const patchHomeAffix = (routes: AppRouteRecordRaw[]) => {
        if (!routes || routes.length === 0) return
        let homePath: string = userStore.getUserInfo.homePath || PageEnum.BASE_HOME
        function patcher(routes: AppRouteRecordRaw[], parentPath = '') {
          if (parentPath) parentPath = parentPath + '/'
          routes.forEach((route: AppRouteRecordRaw) => {
            const { path, children, redirect } = route
            const currentPath = path.startsWith('/') ? path : parentPath + path
            if (currentPath === homePath) {
              if (redirect) {
                homePath = route.redirect! as string
              } else {
                route.meta = Object.assign({}, route.meta, { affix: true })
                throw new Error('end')
              }
            }
            children && children.length > 0 && patcher(children, currentPath)
          })
        }
        try {
          patcher(routes)
        } catch (e) {
          // 已处理完毕跳出循环
        }
        return
      }

      /**
       * @description 获取非菜单级别的权限code
       * */
      const getNodePermission = (array, codes: string[], permObj: Record<string, string>) => {
        for (let i = 0; i < array?.length; i++) {
          const item = array[i]
          if (item.nodeType === 'MENU') {
            getNodePermission(item.children, codes, permObj)
          } else {
            codes.push(item.nodeEnName)
            permObj[item.nodeEnName] = item.nodeName
            if (item.hasChildren) {
              getNodePermission(item.children, codes, permObj)
            }
          }
        }
      }

      /**
       * @description 获取frame地址
       * */
      const getframeSrc = (item: any) => {
        const link = `${item.link}${item.link.includes('?') ? '&' : '?'}platform=${
          import.meta.env.VITE_PLATFORM
        }`
        return item.link.includes('stella/') ? `${useOrigin()}${link}` : item.link
      }

      /**
       * @description 将后端返回数据调整转换路由格式（todo：后端调整）
       * */
      const transformRouteFromRes = (data: any) => {
        const routes: object[] = []
        data?.forEach((item) => {
          if (item.nodeType === 'MENU') {
            item.hasChildren = item?.children?.some((some) => some.nodeType === 'MENU')
            const temp = {
              path:
                item.iframe === 1
                  ? item.nodeEnName
                  : item.link || (item.hasChildren ? `/${item.nodeEnName}` : item.nodeEnName),
              name: item.nodeEnName,
              component: item.hasChildren ? 'LAYOUT' : routerPermission[item.nodeEnName],
              meta: {
                icon: item.icon,
                title: item.nodeName,
                hideMenu: item.invisible,
                // 兼容老代码iframe，如果是外链，判断获取frame地址
                frameSrc: item.iframe === 1 && getframeSrc(item),
              },
              children: [] as object[],
            }
            if (item.hasChildren) {
              temp.children = transformRouteFromRes(item.children)
            }
            routes.push(temp)
          }
        })
        return routes
      }

      switch (permissionMode) {
        case PermissionModeEnum.ROLE:
          routes = filter(asyncRoutes, routeFilter)
          routes = routes.filter(routeFilter)
          // Convert multi-level routing to level 2 routing
          routes = flatMultiLevelRoutes(routes)
          break

        case PermissionModeEnum.ROUTE_MAPPING:
          routes = filter(asyncRoutes, routeFilter)
          routes = routes.filter(routeFilter)
          const menuList = transformRouteToMenu(routes, true)
          routes = filter(routes, routeRemoveIgnoreFilter)
          routes = routes.filter(routeRemoveIgnoreFilter)
          menuList.sort((a, b) => {
            return (a.meta?.orderNo || 0) - (b.meta?.orderNo || 0)
          })

          this.setFrontMenuList(menuList)
          // Convert multi-level routing to level 2 routing
          routes = flatMultiLevelRoutes(routes)
          break

        //  If you are sure that you do not need to do background dynamic permissions, please comment the entire judgment below
        case PermissionModeEnum.BACK:
          const { createMessage } = useMessage()

          createMessage.loading({
            content: t('sys.app.menuLoading'),
            duration: 1,
          })
          // !Simulate to obtain permission codes from the background,
          // this function may only need to be executed once, and the actual project can be put at the right time by itself
          let routeList: AppRouteRecordRaw[] = []
          try {
            // 获取所有权限标识
            // this.changePermissionCode();
            // 获取所有菜单资源
            // routeList = (await getMenuList()) as AppRouteRecordRaw[];

            // 获取所有菜单资源
            const menuRes = await getMenuList()
            const platfromList = menuRes.data

            // 寻找当前平台资源
            const currentPlatform: any = platfromList?.children?.find(
              (item) => item.system === import.meta.env.VITE_PLATFORM,
            )

            // 获取所有转换格式后的菜单路由
            routeList = transformRouteFromRes(currentPlatform?.children) as AppRouteRecordRaw[]
            // demo route
            routeList.push({
              path: '/stella',
              name: 'StellaDemo',
              component: 'LAYOUT',
              redirect: '/stella/pageTable',
              meta: {
                icon: 'actions-list--boxes',
                title: 'Stella代码样例',
              },

              children: [
                {
                  path: 'table',
                  name: 'Table',
                  component: '/stella-demo/Table',
                  meta: {
                    title: '普通表格',
                  },
                },
                {
                  path: 'pageTable',
                  name: 'PageTable',
                  component: '/stella-demo/PageTable',
                  meta: {
                    title: '列表模板',
                  },
                },
                {
                  path: 'modalTable',
                  name: 'ModalTable',
                  component: '/stella-demo/ModalTable',
                  meta: {
                    title: '弹窗表格',
                  },
                },
                {
                  path: 'editRowTable',
                  name: 'EditRowTable',
                  component: '/stella-demo/EditRowTable',
                  meta: {
                    title: '可编辑行表格',
                  },
                },
                {
                  path: 'tabsTable',
                  name: 'TabsTable',
                  component: '/stella-demo/TabsTable',
                  meta: {
                    title: '标签页表格',
                  },
                },
                {
                  path: 'resizablePage',
                  name: 'ResizablePage',
                  component: '/stella-demo/ResizablePage',
                  meta: {
                    title: '可伸缩布局',
                  },
                },
                {
                  path: 'breadcrumbPage',
                  name: 'BreadcrumbPage',
                  component: '/stella-demo/BreadcrumbPage',
                  meta: {
                    title: '面包屑',
                  },
                },
                {
                  path: 'formDetailPage',
                  name: 'FormDetailPage',
                  component: '/stella-demo/FormDetailPage',
                  meta: {
                    title: '表单详情',
                  },
                },
                {
                  path: 'stellaSelectPage',
                  name: 'StellaSelectPage',
                  component: '/stella-demo/StellaSelectPage',
                  meta: {
                    title: '可输可选的select',
                  },
                },
              ],
            })
            // 设置首页path
            const userInfo = userStore.getUserInfo
            userInfo.homePath = routeList[0].path
            userStore.setUserInfo(userInfo)

            // 获取所有code
            const codes = [],
              permObj = {}
            getNodePermission(currentPlatform?.children, codes, permObj)
            this.setPermCodeList(codes)
            this.setPermObj(permObj)
            // 设置平台名称
            this.setPlatformName(currentPlatform?.nodeName)
          } catch (error) {
            console.error(error)
          }

          // Dynamically introduce components
          routeList = transformObjToRoute(routeList)

          //  Background routing to menu structure
          const backMenuList = transformRouteToMenu(routeList)
          this.setBackMenuList(backMenuList)

          // remove meta.ignoreRoute item
          routeList = filter(routeList, routeRemoveIgnoreFilter)
          routeList = routeList.filter(routeRemoveIgnoreFilter)

          routeList = flatMultiLevelRoutes(routeList)
          routes = [PAGE_NOT_FOUND_ROUTE, ...routeList]
          break
      }

      routes.push(ERROR_LOG_ROUTE)
      patchHomeAffix(routes)

      return routes
    },
  },
})

// Need to be used outside the setup
export function usePermissionStoreWithOut() {
  return usePermissionStore(store)
}
