import { defineStore } from 'pinia'
import { store } from '/@/store'
import {
  assetPackageModel,
  assetPackageBaseInfo,
  assetPackageDataStorage,
  itemListModel,
  DerivationIndexConfig,
} from '/@/api/index/model/assetPackageModel'

export const useAssetPackageStore = defineStore({
  id: 'AssetPackageState',

  persist: {
    key: 'AssetPackageState',
    storage: window.sessionStorage,
  },

  state: (): assetPackageModel => ({
    BaseInfo: {},
    DataStorage: {},
    derivationIndexConfig: {},
    IndexInfo: [],
  }),

  getters: {
    //第一步--基础信息
    getBaseInfo(): assetPackageBaseInfo {
      return this.BaseInfo || {}
    },
    //第二步--选择指标/维度
    getIndexInfo(): itemListModel[] {
      return this.IndexInfo || []
    },
    getDerivationIndexConfig(): DerivationIndexConfig {
      return this.derivationIndexConfig || {}
    },
    //第四步-配置数据存储
    getDataStorage(): assetPackageDataStorage {
      return this.DataStorage || {}
    },
  },

  actions: {
    setBaseInfo(value: assetPackageBaseInfo) {
      Object.assign(this.BaseInfo, value)
    },
    setIndexInfo(value: itemListModel[]) {
      Object.assign(this.IndexInfo, value)
    },
    setDataStorage(value: assetPackageDataStorage) {
      Object.assign(this.DataStorage, value)
    },
    setDerivationIndexConfig(value: DerivationIndexConfig) {
      Object.assign(this.derivationIndexConfig, value)
    },
    clear() {
      this.BaseInfo = {}
      this.DataStorage = {}
      this.IndexInfo = []
      this.derivationIndexConfig = {}
    },
  },
})

export function useAssetPackageWithOut() {
  return useAssetPackageStore(store)
}
