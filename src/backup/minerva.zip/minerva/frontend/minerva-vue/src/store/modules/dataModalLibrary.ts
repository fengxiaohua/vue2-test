import { defineStore } from 'pinia'
import { store } from '/@/store'

import {
  DataModel,
  DataModalBaseInfo,
  DataModalSourceInfo,
  DataModalEditFieldInfo,
  DataModalAdvanceInfo,
} from '/@/api/data-model/model/dataModalLibraryModel'

export const useDataModalLibraryStore = defineStore({
  id: 'DataModalLibraryState',

  persist: {
    key: 'DataModalLibraryState',
    storage: window.sessionStorage,
  },

  state: (): DataModel => ({
    dataModalBaseInfo: {},
    dataModalSourceInfo: {},
    dataModalEditFieldInfo: {},
    dataModalAdvanceInfo: {},
  }),

  getters: {
    getDataModalBaseInfo(): DataModalBaseInfo {
      return this.dataModalBaseInfo || {}
    },
    getDataModalSourceInfo(): DataModalSourceInfo {
      return this.dataModalSourceInfo || {}
    },
    getDataModalEditFieldInfo(): DataModalEditFieldInfo {
      return this.dataModalEditFieldInfo || {}
    },
    getDataModalAdvanceInfo(): DataModalAdvanceInfo {
      return this.dataModalAdvanceInfo || {}
    },
  },

  actions: {
    setDataModalBaseInfo(value: DataModalBaseInfo) {
      this.dataModalBaseInfo = value
    },
    setDataModalSourceInfo(value: DataModalSourceInfo) {
      this.dataModalSourceInfo = value
    },
    setDataModalEditFieldInfo(value: DataModalEditFieldInfo) {
      this.dataModalEditFieldInfo = value
    },
    setDataModalAdvanceInfo(value: DataModalAdvanceInfo) {
      this.dataModalAdvanceInfo = value
    },
    clear() {
      this.dataModalBaseInfo = undefined
      this.dataModalSourceInfo = undefined
      this.dataModalEditFieldInfo = undefined
      this.dataModalAdvanceInfo = undefined
    },
    clearDataModalEditFieldInfo() {
      this.dataModalEditFieldInfo = undefined
    },
    clearDataModalAdvanceInfo() {
      this.dataModalAdvanceInfo = undefined
    },
  },
})

export function useDataModalLibraryWithOut() {
  return useDataModalLibraryStore(store)
}
