import { defineStore } from 'pinia'
import { store } from '/@/store'
import type { Client } from '@stomp/stompjs'
interface WebSocketState {
  stompClient?: Client
}
export const useWebsocketStore = defineStore({
  id: 'websokcet',
  state: (): WebSocketState => ({
    stompClient: {} as Client,
  }),
  getters: {
    getWsClient(): Client {
      return this.stompClient as Client
    },
  },
  actions: {
    setWsClient(value: Client) {
      this.stompClient = value
    },
  },
})

export function useWebsocketStoreWithOut() {
  return useWebsocketStore(store)
}
