import { defineStore } from 'pinia'
import { store } from '/@/store'
import {
  IndexModel,
  BaseIndexConfig,
  DerivationIndexConfig,
  IndexBaseInfo,
  ScheduleConfig,
} from '/@/api/index/model/libraryModel'

export const useIndexLibraryStore = defineStore({
  id: 'IndexLibraryState',

  persist: {
    key: 'IndexLibraryState',
    storage: window.sessionStorage,
  },

  state: (): IndexModel => ({
    baseIndexConfig: {},
    derivationIndexConfig: {},
    indexBaseInfo: {},
    scheduleConfig: {},
  }),

  getters: {
    getBaseIndexConfig(): BaseIndexConfig {
      return this.baseIndexConfig || {}
    },
    getDerivationIndexConfig(): DerivationIndexConfig {
      return this.derivationIndexConfig || {}
    },
    getIndexBaseInfo(): IndexBaseInfo {
      return this.indexBaseInfo || {}
    },
    getScheduleConfig(): ScheduleConfig {
      return this.scheduleConfig || {}
    },
  },

  actions: {
    setBaseIndexConfig(value: BaseIndexConfig) {
      Object.assign(this.baseIndexConfig, value)
    },
    setDerivationIndexConfig(value: DerivationIndexConfig) {
      Object.assign(this.derivationIndexConfig, value)
    },
    setIndexBaseInfo(value: IndexBaseInfo) {
      Object.assign(this.indexBaseInfo, value)
    },
    setScheduleConfig(value: ScheduleConfig) {
      Object.assign(this.scheduleConfig, value)
    },
    clear() {
      this.baseIndexConfig = {}
      this.derivationIndexConfig = {}
      this.indexBaseInfo = {}
      this.scheduleConfig = {}
    },
  },
})

export function useIndexLibraryWithOut() {
  return useIndexLibraryStore(store)
}
