/**
 * @description: Request result set
 */
export enum ResultEnum {
  // SUCCESS = 0,
  SUCCESS = '10000',
  ERROR = 1,
  TIMEOUT = 401,
  TYPE = 'success',
}

/**
 * @description: 请求错误类型
 */
export const StellaErrorEnum = {
  10001: '服务不可用',
  10002: '内部服务不可用',
  10003: '无效的请求报文',
  10004: '表单校验错误',
  10005: 'token会话已超时',
  10006: 'token权限认证失败，没有访问权限',
  10007: '用户在别的地方登陆',
  10008: '访问过快，请稍候再试',
  10010: '业务请求信息',
  10011: '业务自定义校验信息',
  10012: '业务警告信息',
  99999: '其它业务信息',
}
/**
 * @description: request method
 */
export enum RequestEnum {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
}

/**
 * @description:  contentType
 */
export enum ContentTypeEnum {
  // json
  JSON = 'application/json;charset=UTF-8',
  // form-data qs
  FORM_URLENCODED = 'application/x-www-form-urlencoded;charset=UTF-8',
  // form-data  upload
  FORM_DATA = 'multipart/form-data;charset=UTF-8',
}
