export default function download(res, filename) {
  // res 调用接口后返回的数据
  // filename自定义文件名
  const blob = new Blob([res]) // 将返回的数据通过Blob的构造方法，创建Blob对象
  if ('msSaveOrOpenBlob' in navigator) {
    window.navigator.msSaveOrOpenBlob(blob, filename) // 针对浏览器
  } else {
    const elink = document.createElement('a') // 创建a标签
    elink.download = filename
    elink.style.display = 'none'
    // 创建一个指向blob的url，这里就是点击可以下载文件的根结
    elink.href = URL.createObjectURL(blob)
    document.body.appendChild(elink)
    elink.click()
    URL.revokeObjectURL(elink.href) //移除链接
    document.body.removeChild(elink) //移除a标签
  }
}
