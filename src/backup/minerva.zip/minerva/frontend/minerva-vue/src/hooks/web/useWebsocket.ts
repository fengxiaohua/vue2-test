/**
 * @description: 链接websocket
 */
import { computed, unref } from 'vue'
import Stomp from '@stomp/stompjs'
import { useUserStore } from '/@/store/modules/user'
import { useWebsocketStore } from '/@/store/modules/websocket'

export function useWebsocket() {
  const userStore = useUserStore()
  const getUserInfo = computed(() => {
    const { access_token = '' } = userStore.getUserInfo || {}
    return { access_token }
  })
  if (unref(getUserInfo).access_token) {
    const stompClient = Stomp.client(
      'ws://192.168.10.241:18180/ws/escat-de-run-management-provider/websocket?access_token=' +
        getUserInfo.value.access_token,
    )
    stompClient.heartbeat.incoming = 10000
    stompClient.heartbeat.outgoing = 10000
    stompClient.reconnect_delay = 5000
    stompClient.connect({}, function (frame) {
      console.log('frame', frame)
      // 保存客户端对象
      useWebsocketStore().setWsClient(stompClient)
    })
  }
}
