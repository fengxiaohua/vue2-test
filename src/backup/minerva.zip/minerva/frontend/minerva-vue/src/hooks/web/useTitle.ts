import { watch } from 'vue'
// import { useI18n } from '/@/hooks/web/useI18n'
import { useTitle as usePageTitle } from '@vueuse/core'
// import { useGlobSetting } from '/@/hooks/setting'
import { useRouter } from 'vue-router'
// import { useLocaleStore } from '/@/store/modules/locale'
// import { REDIRECT_NAME } from '/@/router/constant'

import { usePermissionStore } from '/@/store/modules/permission'

/**
 * Listening to page changes and dynamically changing site titles
 */
export function useTitle() {
  // const { title } = useGlobSetting()
  const permissionStore = usePermissionStore()

  // const { t } = useI18n()
  const { currentRoute } = useRouter()
  // const localeStore = useLocaleStore()

  const pageTitle = usePageTitle()

  watch(
    [
      () => currentRoute.value.path,
      // () => localeStore.getLocale,
      () => permissionStore.getPlatformName,
    ],
    () => {
      const route = unref(currentRoute)
      if (route.path === '/login') {
        pageTitle.value = '登录'
        return
      }
      // const tTitle = t(route?.meta?.title as string)
      // pageTitle.value = tTitle ? ` ${tTitle} - ${title} ` : `${title}`
      pageTitle.value = permissionStore.getPlatformName || '加载中...'
    },
    { immediate: true },
  )
}
