/**
 * @description: 获取远程静态资源地址
 * @param {string} src
 * @return {string}
 */
export function useAssetPath(src: string): string {
  return `${useOrigin()}/static/${src}`
}

/**
 * @description: 区分环境获取当前服务源
 * @return {string}
 */
export function useOrigin(): string {
  return import.meta.env.DEV ? import.meta.env.VITE_GLOB_DEV_URL : window.origin
}
