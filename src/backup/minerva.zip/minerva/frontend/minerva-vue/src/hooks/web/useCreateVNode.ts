// 自定义VNode hook (批量提示)

import { VNode, h } from 'vue'

export function useCreateVNode() {
  // 批量提示
  function batchPrompt(content: string | string[]): VNode {
    const data: string[] = Array.isArray(content) ? content : [content]
    return h(
      'ul',
      {
        style: {
          margin: 0,
          paddingLeft: '20px',
          listStyle: 'disc',
          maxHeight: '30vh',
          overflow: 'auto',
        },
      },
      data.map((item) =>
        h(
          'li',
          {
            style: {
              margin: 0,
              color: 'rgba(0,0,0,.65)',
            },
          },
          item,
        ),
      ),
    )
  }
  return { batchPrompt }
}
