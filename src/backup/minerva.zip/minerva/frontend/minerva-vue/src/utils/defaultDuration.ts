//校验名称、编码防抖时长
export const validateDebouncePeriod = 200
