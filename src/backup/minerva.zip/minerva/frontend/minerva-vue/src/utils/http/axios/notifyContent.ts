import { h, unref } from 'vue'
import { Button } from 'ant-design-vue'
import { useMessage } from '/@/hooks/web/useMessage'
import { useCopyToClipboard } from '/@/hooks/web/useCopyToClipboard'

/**
 * @description: notification自定义异常信息提醒（带错误详情复制功能）
 * @param msg 提示信息
 * @param title 提示标题
 * @param copyContent 需要复制的内容
 */
export function notify(msg, title, copyContent: any) {
  msg = msg.replace(/[\r\n]/g, ' ')

  const byteLength = function (str) {
    //获取字符串的字节数，扩展string类型方法
    let b = 0
    const i = str.length //初始化字节数递加变量并获取字符串参数的字符个数
    if (i) {
      //如果存在字符串，则执行计划
      for (let k = 0; k < i; k += 1) {
        //遍历字符串，枚举每个字符
        if (str.charCodeAt(i) > 255) {
          //字符编码大于255，说明是双字节字符
          b += 2 //则累加2个
        } else {
          b += 1 //否则递加一次
        }
      }
      return b //返回字节数
    } else {
      return 0 //如果参数为空，则返回0个
    }
  }

  if (byteLength(msg) > 300) {
    msg = msg.slice(0, 300) + '...'
  }

  return {
    message: title ?? '状态异常',
    description: () => {
      return h(
        'div',
        {
          class: ['flex', 'flex-col'],
        },
        [
          h(
            'div',
            {
              style: {
                textOverflow: 'ellipsis',
                overflowWrap: 'break-word',
                display: 'inline-block',
                color: '#666',
              },
            },
            msg,
          ),
          h(
            'div',
            {
              style: {
                height: '0px',
                overflowWrap: 'break-word',
                overflow: 'hidden',
              },
            },
            [
              h('p', copyContent?.headers),
              h('p', copyContent?.msg),
              h('p', copyContent?.errorStackTrace),
            ],
          ),
        ],
      )
    },
    btn: () => {
      return h(
        Button,
        {
          type: 'link',
          size: 'small',
          onClick: () => {
            const { clipboardRef, copiedRef } = useCopyToClipboard()
            const { createMessage } = useMessage()
            clipboardRef.value = `${copyContent?.headers}\n\n${copyContent?.msg}\n\n${copyContent?.errorStackTrace}`
            if (unref(copiedRef)) {
              createMessage.success('复制成功')
            }
          },
        },
        '拷贝详细信息',
      )
    },
  }
}
