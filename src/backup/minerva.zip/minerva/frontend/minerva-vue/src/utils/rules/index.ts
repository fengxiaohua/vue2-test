/*
 * @Description: 正则验证
 */
import type { Rule } from 'ant-design-vue/es/form'

/**
 * @description: 统一校验
 * @param {RegExp} reg 校验结果
 * @param {string｜number} value 被校验的值
 * @param {string} tips 提示语
 */

export function validate(reg: boolean, value: string, tips: any) {
  if (reg) {
    return Promise.resolve()
  } else {
    return Promise.reject(tips)
  }
}

export const rules = {
  /**
   * @description: 只包含英文、数字、下划线
   * @param {*} rule
   * @param {*} value
   */
  regEngNumLine(rule: Rule, value: string) {
    const reg = /^[_a-zA-Z0-9]+$/.test(value) || !value
    const tips = rule.message || '请输入英文、数字、下划线'
    return validate(reg, value, tips)
  },

  /**
   * @description: 以英文开头，只包含英文、数字、下划线
   * @param {*} rule
   * @param {*} value
   */
  regEngStartNumLine(rule: Rule, value: string) {
    const reg = /^[a-zA-Z][a-zA-Z0-9_]*$/.test(value) || !value
    const tips = rule.message || '以英文开始，可包含英文、数字、下划线'
    return validate(reg, value, tips)
  },

  /**
   * @description: 只能输入中文
   * @param {*} rule
   * @param {*} value
   */
  regIsChinese(rule: Rule, value: string) {
    const reg = /^[\u4e00-\u9fa5]+$/.test(value) || !value
    const tips = rule.message || '请输入中文'
    return validate(reg, value, tips)
  },

  /**
   * @description: 只能输入英文
   * @param {*} rule
   * @param {*} value
   */
  regIsEnglish(rule: Rule, value: string) {
    const reg = /^[a-zA-Z]+$/.test(value) || !value
    const tips = rule.message || '请输入英文'
    return validate(reg, value, tips)
  },

  /**
   * @description: 整数校验
   * @param {*} rule
   * @param {*} value
   */
  regIsInteger(rule: Rule, value: string) {
    const reg = /^[+]{0,1}(\d+)$/.test(value) || !value
    const tips = rule.message || '请输入整数'
    return validate(reg, value, tips)
  },

  /**
   * @description: 只能输入正整数
   * @param {*} rule
   * @param {*} value
   */
  regIsPositiveInteger(rule: Rule, value: string) {
    const reg = /^\+?[1-9]\d*$/.test(value) || !value
    const tips = rule.message || '请输入正整数'
    return validate(reg, value, tips)
  },

  /**
   * @description: 只能输入数字,允许负数、小数
   * @param {*} rule
   * @param {*} value
   */
  regIsNumber(rule: Rule, value: string) {
    const reg = /^\-?[0-9]+(.[0-9]+)?$/.test(value) || !value
    const tips = rule.message || '请输入数字'
    return validate(reg, value, tips)
  },

  /**
   * @description: 非零开头的正整数
   * @param {*} rule
   * @param {*} value
   */
  regNonZeroDigit(rule: Rule, value: string) {
    const reg = /^(0|[1-9][0-9]*)$/.test(value) || !value
    const tips = rule.message || '请输入非零开头的正整数'
    return validate(reg, value, tips)
  },

  /**
   * @description: 校验字符长度,默认0-50
   * @param {*} rule
   * @param {*} value
   */
  regLength(rule: Rule, value: string) {
    const min = rule.min ? rule.min : 0
    const max = rule.max
    let reg = true
    let tips
    if (value) {
      if (min && !max) {
        reg = new RegExp('^.{' + min + ',}$').test(value)
        tips = `长度不小于${min}个字符`
      }
      if (!min && max) {
        reg = new RegExp('^.{' + min + ',' + max + '}$').test(value)
        tips = `长度不超过${max}个字符`
      }
      if (min && max) {
        reg = new RegExp('^.{' + min + ',' + max + '}$').test(value)
        tips = `长度在${min}~${max}个字符`
      }
    }

    tips = rule.message || tips
    return validate(reg, value, tips)
  },

  /**
   * @description: 普通输入框长度校验,默认0-50
   * @param {*} rule
   * @param {*} value
   */
  regTextLength(rule: Rule, value: string) {
    const min = 0
    const max = 50
    const reg = new RegExp('^.{' + min + ',' + max + '}$').test(value)
    const tips = rule.message || `长度不超过${max}个字符`
    return validate(reg, value, tips)
  },

  /**
   * @description: 邮箱校验
   * @param {*} rule
   * @param {*} value
   * @return {*}
   */
  regMailbox(rule: Rule, value: string) {
    const reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/.test(value) || !value
    const tips = rule.message || `请输入正确的邮箱地址`
    return validate(reg, value, tips)
  },

  /**
   * @description: 校验备注长度,默认0-200
   * @param {*} rule
   * @param {*} value
   */
  regDesc(rule: Rule, value: string) {
    const min = 0
    const max = 200
    const reg = new RegExp('^.{' + min + ',' + max + '}$').test(value)
    const tips = rule.message || `长度不超过${max}个字符`
    return validate(reg, value, tips)
  },

  /**
   * @description: 不能包含特殊字符
   * @param {*} rule
   * @param {*} value
   */
  regSpecialCharacter(rule: Rule, value: string) {
    const reg =
      !new RegExp(
        "[`~!@#$^&*()=|{}':;',\\[\\].<>《》/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]",
      ).test(value) || !value
    const tips = rule.message || `不能包含特殊字符`
    return validate(reg, value, tips)
  },

  /**
   * @description: 只支持输入英文、数字、_、-、/
   * @param {*} rule
   * @param {*} value
   */
  regEngNumSpecial(rule: Rule, value: string) {
    const reg = /^[a-zA-Z0-9_\-\/]{1,}$/.test(value) || !value
    const tips = rule.message || `请输入英文、数字、_、-、/`
    return validate(reg, value, tips)
  },

  /**
   * @description: 只支持输入汉字、英文、数字、下划线，且只能以英文和汉字开头
   * @param {*} rule
   * @param {*} value
   */
  regChineseEngStartNumline(rule: Rule, value: string) {
    const reg = /^[\u4E00-\u9FA5a-z][\u4E00-\u9FA5a-z0-9_]*$/.test(value) || !value
    const tips = rule.message || `请输入中文、英文、数字、下划线，且只能以英文和中文开头`
    return validate(reg, value, tips)
  },

  /**
   * @description: 校验是否是手机号码
   * @param {*} rule
   * @param {*} value
   */
  regIsPhoneNumber(rule: Rule, value: string) {
    const reg =
      /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/.test(value) ||
      !value
    const tips = rule.message || `请输入正确手机号码`
    return validate(reg, value, tips)
  },
}

export type FormRule = Rule
