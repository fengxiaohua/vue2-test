// 每隔n个字符，插入一个字符
export const strInsert = (str, length, joinStr) => {
  if (!str) return ''
  const reg = new RegExp('\\w{1,' + length + '}', 'g')
  const ma = str.match(reg)
  return ma?.join(joinStr)
}
