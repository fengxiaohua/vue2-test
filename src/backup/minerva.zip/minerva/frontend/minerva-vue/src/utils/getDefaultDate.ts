/**
 * @description: 默认一年
 * @return {*}
 */
export const defaultOneYear = (): { start: string; end: string } => {
  const nowDate = new Date()
  const year = nowDate.getFullYear()
  const endYear = nowDate.getFullYear() + 1
  const month =
    nowDate.getMonth() + 1 < 10 ? '0' + (nowDate.getMonth() + 1) : nowDate.getMonth() + 1
  const day = nowDate.getDate() < 10 ? '0' + nowDate.getDate() : nowDate.getDate()
  const start = year + '-' + month + '-' + day
  const end = endYear + '-' + month + '-' + day
  return {
    start,
    end,
  }
}
