import { defHttp } from '/@/utils/http/axios'
import qs from 'qs'
import {
  GetClassParams,
  ClassInstance,
  MoveClassParams,
  ClassKey,
  ClassKeys,
} from './model/classModel'
import { BasicResult } from '/@/api/model/baseModel'
enum Api {
  GetClassList = '/minerva-index-management-provider/minervaIndexCategory/queryPage',
  GetClassDtail = '/minerva-index-management-provider/minervaIndexCategory',
  AddClass = '/minerva-index-management-provider/minervaIndexCategory',
  UpdateClass = '/minerva-index-management-provider/minervaIndexCategory',
  BatchExport = '/minerva-index-management-provider/minervaIndexCategory/export',
  BatchImport = '/minerva-index-management-provider/minervaIndexCategory/import?',
  MoveClass = '/minerva-index-management-provider/minervaIndexCategory/move',
  DeleteClass = '/minerva-index-management-provider/minervaIndexCategory',
  BatchDeleteClass = '/minerva-index-management-provider/minervaIndexCategory/delete/batch?',
  QueryTree = '/minerva-index-management-provider/minervaIndexCategory/queryTree',
  ClassIsUsed = '/minerva-index-management-provider/minervaIndexCategory/isBeingUsed',
  ClassAreUsed = '/minerva-index-management-provider/minervaIndexCategory/isBeingUsedBatch?',
  CheckCode = '/minerva-index-management-provider/minervaIndexCategory/checkCode',
  CheckName = '/minerva-index-management-provider/minervaIndexCategory/checkName',
  Download = '/minerva-index-management-provider/minervaIndexCategory/template/download',
}
/**
 * @description: 分类分页查询
 */
export function getClassListApi(params: GetClassParams) {
  return defHttp.get<BasicResult>({ url: Api.GetClassList, params: params })
}
/**
 * @description: 分类详情查询
 */
export function getClassDetailApi(params: ClassKey) {
  return defHttp.get<BasicResult>({ url: Api.GetClassDtail + `/${params.categoryCode}` })
}
/**
 * @description: 新增分类
 */
export function addClassApi(params: ClassInstance) {
  return defHttp.post<BasicResult>({ url: Api.AddClass, params: params })
}
/**
 * @description: 修改分类
 */
export function updateClassApi(params: ClassInstance) {
  return defHttp.put<BasicResult>({ url: Api.UpdateClass, params: params })
}
/**
 * @description: 批量导入
 */
export function batchImportApi(file, isCover) {
  return defHttp.post<BasicResult>({ url: Api.BatchImport + qs.stringify(isCover), params: file })
}
/**
 * @description: 批量导出
 */
export function batcheExportApi(params: ClassKeys) {
  const token = localStorage.getItem('Authorization')
  return defHttp.get<BasicResult>({
    url: `${Api.BatchExport}?codes=${params.codes}&access_token=${token}`,
    responseType: 'blob',
  })
}
/**
 * @description: 模版下载
 */
export function downloadApi() {
  const token = localStorage.getItem('Authorization')
  return defHttp.get<BasicResult>({
    url: `${Api.Download}?access_token=${token}`,
    responseType: 'blob',
  })
}
/**
 * @description: 移动分类
 */
export function moveClassApi(params: MoveClassParams) {
  return defHttp.put<BasicResult>({
    url: Api.MoveClass + `/${params.sourceCode}/${params.targetCode}`,
  })
}
/**
 * @description: 删除分类
 */
export function deleteClassApi(params: ClassKey) {
  return defHttp.delete<BasicResult>({ url: Api.DeleteClass + `/${params.categoryCode}` })
}
/**
 * @description: 批量删除分类
 */
export function batchDeleteClassApi(params: ClassKeys) {
  return defHttp.delete<BasicResult>({ url: Api.BatchDeleteClass + qs.stringify(params) })
}
/**
 * @description: 分类名称唯一性
 */
export function checkNameApi(params: ClassKey) {
  return defHttp.get<BasicResult>({ url: Api.CheckName + `/${params.categoryName}` })
}
/**
 * @description: 分类编号唯一性
 */
export function checkCodeApi(params: ClassKey) {
  return defHttp.get<BasicResult>({ url: Api.CheckCode + `/${params.categoryCode}` })
}
/**
 * @description: 查询分类树
 */
export function queryTreeApi() {
  return defHttp.get<BasicResult>({ url: Api.QueryTree })
}
/**
 * @description: 验证分类是否被指标应用
 */
export function classIsUsedApi(params: ClassKey) {
  return defHttp.get<BasicResult>({ url: Api.ClassIsUsed + `/${params.categoryCode}` })
}
/**
 * @description: 批量验证分类是否被指标应用
 */
export function classAreUsedApi(params: ClassKeys) {
  return defHttp.get<BasicResult>({ url: Api.ClassAreUsed + qs.stringify(params) })
}
