import { UserInfo } from './../../../types/store.d'
import { defHttp } from '/@/utils/http/axios'
// import { LoginParams, LoginResultModel, GetUserInfoModel } from './model/userModel';
import { LoginParams, GetUserInfoModel } from './model/userModel'

import { ErrorMessageMode } from '/#/axios'

// todo 将所有api模块定义
// enum Module {
//   UserServer = '/rbac-user-server',
// }

enum Api {
  // Login = '/login',
  // Logout = '/logout',
  Login = '/rbac-user-server/oauth/token',
  Logout = '/rbac-user-server/oauth/logout',
  GetUserInfo = '/getUserInfo',
  GetPermCode = '/getPermCode',
  TestRetry = '/testRetry',
}

/**
 * @description: user login api
 */
export function loginApi(params: LoginParams, mode: ErrorMessageMode = 'none') {
  // return defHttp.post<LoginResultModel>(
  return defHttp.post<UserInfo>(
    {
      url: Api.Login,
      params,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      },
      transformRequest: [
        function (data) {
          let ret = ''
          for (const i in data) {
            ret += encodeURIComponent(i) + '=' + encodeURIComponent(data[i]) + '&'
          }
          return ret.substring(0, ret.lastIndexOf('&'))
        },
      ],
    },
    {
      errorMessageMode: mode,
    },
  )
}

/**
 * @description: getUserInfo
 */
export function getUserInfo() {
  return defHttp.get<GetUserInfoModel>({ url: Api.GetUserInfo }, { errorMessageMode: 'none' })
}

export function getPermCode() {
  return defHttp.get<string[]>({ url: Api.GetPermCode })
}

export function doLogout() {
  return defHttp.get({ url: Api.Logout })
}

export function testRetry() {
  return defHttp.get(
    { url: Api.TestRetry },
    {
      retryRequest: {
        isOpenRetry: true,
        count: 5,
        waitTime: 1000,
      },
    },
  )
}
