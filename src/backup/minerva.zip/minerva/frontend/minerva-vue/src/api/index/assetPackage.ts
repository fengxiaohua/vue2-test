import { defHttp } from '/@/utils/http/axios'
import {
  GetAssetPackagePageParams,
  AssetPackageInstance,
  AddAssetPackageModel,
  Calcluate,
} from './model/assetPackageModel'
import { Result, BasicResult } from '/@/api/model/baseModel'

enum Api {
  GetAssetPackageList = '/minerva-index-management-provider/minervaIndexAssetPackage',
  GetAssetPackage = '/minerva-index-management-provider/minervaIndexAssetPackage',
  AddAssetPackage = '/minerva-index-management-provider/minervaIndexAssetPackage',
  TryDo = '/minerva-index-management-provider/minervaIndexAssetPackage//try/do',
  Online = '/minerva-index-management-provider/minervaIndexAssetPackage/online',
  Cancel = '/minerva-index-management-provider/minervaIndexAssetPackage/online/cancel',
  Release = '/minerva-index-management-provider/minervaIndexAssetPackage/release',
  CancelRelease = '/minerva-index-management-provider/minervaIndexAssetPackage/release/cancel',
  GetIndexList = '/minerva-index-management-provider/minervaIndexBaseInfo/query',
  AbleDataPreview = '/minerva-index-management-provider/minervaIndexAssetPackage/canPreview',
  DataPreview = '/minerva-index-management-provider/minervaIndexAssetPackage/preview',
  DataPreviewCount = '/minerva-index-management-provider/minervaIndexAssetPackage/previewCount',
  DeleteAssetPackage = '/minerva-index-management-provider/minervaIndexAssetPackage/delete',
  CheckCode = '/minerva-index-management-provider/minervaIndexAssetPackage/checkCode',
  CheckName = '/minerva-index-management-provider/minervaIndexAssetPackage/checkName',
  TryCalculate = '/minerva-index-management-provider/minervaIndexAssetPackage/try/do',
  TryCalculateCount = '/minerva-index-management-provider/minervaIndexAssetPackage/try/do/count',
}

/**
 * @description: 分页查询
 */
export function GetAssetPackageList(params: GetAssetPackagePageParams) {
  return defHttp.get<Result<AssetPackageInstance>>({ url: Api.GetAssetPackageList, params })
}

/**
 * @description: 新增指标包
 */
export function AddAssetPackageApi(params: AddAssetPackageModel) {
  return defHttp.post<BasicResult>({ url: Api.AddAssetPackage, params })
}

/**
 * @description: 更新指标包
 */
export function UpdateAssetPackageApi(params: AddAssetPackageModel) {
  return defHttp.put<BasicResult>({ url: Api.AddAssetPackage, params: params })
}

/**
 * @description: 根据指标资产包编号获取资产包详情
 */
export function GetAssetPackageDetailApi(apCode: string) {
  return defHttp.get<BasicResult>({ url: `${Api.AddAssetPackage}/${apCode}` })
}

/**
 * @description: 试计算
 */
export function TryDoApi(params: AddAssetPackageModel) {
  return defHttp.post<BasicResult>({ url: Api.TryDo, params })
}

/**
 * @description: 删除
 */
export function DeleteAssetPackageApi(codes: string) {
  return defHttp.delete<BasicResult>({ url: `${Api.DeleteAssetPackage}?codes=${codes}` })
}

/**
 * @description: 上线
 */
export function OnlineApi(codes: string[], remark: string) {
  return defHttp.put<BasicResult>({
    url: `${Api.Online}`,
    params: { codes, onlineRemark: remark },
  })
}

/**
 * @description: 下线
 */
export function CancelApi(codes: string[], remark: string) {
  return defHttp.put<BasicResult>({ url: `${Api.Cancel}`, params: { codes, onlineRemark: remark } })
}

/**
 * @description: 发布
 */
export function ReleaseApi(codes: string) {
  return defHttp.put<BasicResult>({ url: `${Api.Release}?codes=${codes}` })
}

/**
 * @description: 取消发布
 */
export function CancelReleaseApi(codes: string) {
  return defHttp.put<BasicResult>({ url: `${Api.CancelRelease}?codes=${codes}` })
}

/**
 * @description: 查询所有指标
 */
export function GetIndexListApi() {
  return defHttp.get<BasicResult>({ url: Api.GetIndexList })
}

/**
 * @description: 判断是否可以数据预览
 */
export function AbleDataPreviewApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.AbleDataPreview}/${code}` })
}

/**
 * @description: 数据预览
 */
export function DataPreviewApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.DataPreview}/${code}` })
}

/**
 * @description: 数据预览总数统计
 */
export function DataPreviewCountApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.DataPreviewCount}/${code}` })
}

/**
 * @description: 校验编码唯一性
 */
export function CheckCodeApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.CheckCode}/${code}` })
}

/**
 * @description: 校验资产包名称唯一性
 */
export function CheckNameApi(name: String) {
  return defHttp.get<BasicResult>({ url: `${Api.CheckName}/${name}` })
}

/**
 * @description: 试计算
 */
export function TryCalculateApi(params: Calcluate) {
  return defHttp.post<BasicResult>({ url: `${Api.TryCalculate}?page=1&pageSize=50`, params })
}

/**
 * @description: 试计算总数
 */
export function TryCalculateCountApi(params: Calcluate) {
  return defHttp.post<BasicResult>({ url: `${Api.TryCalculateCount}?page=1&pageSize=50`, params })
}

/**
 * @description: 指标资产包详情
 */
export function GetAssetPackageApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.GetAssetPackage}/${code}` })
}
