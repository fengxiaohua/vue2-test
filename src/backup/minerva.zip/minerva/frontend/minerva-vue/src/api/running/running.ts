import { defHttp } from '/@/utils/http/axios'
import { GetRunnningParams, Key } from './model/running'
import { BasicResult } from '../model/baseModel'

enum Api {
  GetHistoryList = '/minerva-index-execute-provider/run/listManualHistory',
  GetRunningList = '/minerva-index-execute-provider/run/listManualRunning',
  GetDispatchList = '/minerva-index-execute-provider/run/listAutoHistory',
  Rerun = '/minerva-index-execute-provider/run/rerun',
  Stop = '/minerva-index-execute-provider/run/stop',
  GetRunlog = '/minerva-index-execute-provider/run/getRunLog/',
}
/**
 * @description: 获取运行历史列表
 */
export function getHistoryListApi(params: GetRunnningParams) {
  return defHttp.get<BasicResult>({ url: Api.GetHistoryList, params: params })
}
/**
 * @description: 获取运行中列表
 */
export function getRunningListApi() {
  return defHttp.get<BasicResult>({ url: `${Api.GetRunningList}?bizType=all` })
}
/**
 * @description: 获取例行运行列表
 */
export function getDispatchListApi(params: GetRunnningParams) {
  return defHttp.get<BasicResult>({ url: Api.GetDispatchList, params: params })
}
/**
 * @description: 重新运行
 */
export function rerunApi(params: Key) {
  return defHttp.post<BasicResult>({
    url: `${Api.Rerun}?enableGatewayConnHold=true&gatewayConnHoldId=${params.id}`,
    params: params,
  })
}
/**
 * @description: 停止
 */
export function stopApi(params: Key) {
  return defHttp.post<BasicResult>({
    url: `${Api.Stop}?enableGatewayConnHold=true&gatewayConnHoldId=${params.id}`,
    params: params,
  })
}
/**
 * @description: 日志
 */
export function getRunlogApi(params: Key) {
  return defHttp.get<BasicResult>({ url: Api.GetRunlog + `${params.id}` })
}
