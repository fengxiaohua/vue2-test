import { defHttp } from '/@/utils/http/axios'
import { BasicResult } from '../model/baseModel'
interface DataSourceParams {
  sourcePlatform?: string
}

enum Api {
  engineClickHouse = '/escat-portal-model-management-provider/datasource/getEngIneClinkHouse',
  dataSourceList = '/escat-portal-model-management-provider/datasource/selectAllNoPage',
  schemaList = '/escat-portal-model-management-provider/basicModel/getSchema',
  tableInfoViews = '/escat-portal-model-management-provider/basicModel/getTablesInfoViews',
  tableQuerySqlAndColumns = '/escat-portal-model-management-provider/basicModel/getTableQuerySqlAndColumns',
  columnsInfo = '/escat-portal-model-management-provider/basicModel/getColumnsBySql',
  previewData = '/escat-de-run-management-provider/preview/previewDataPage',
  dataSourceInfo = '/escat-portal-model-management-provider/datasource/datasourceId',
}
/**
 * @description: 获取默认引擎信息
 * @return {*}
 */
export function getEngineInfo() {
  return defHttp.get<BasicResult>(
    {
      url: Api.engineClickHouse,
    },
    {
      errorMessageMode: 'none',
    },
  )
}
/**
 * @description: 获取数据源信息
 * @param {*} params
 * @return {*}
 */
export function getDataSources(params: DataSourceParams) {
  return defHttp.get<BasicResult>(
    {
      url: Api.dataSourceList,
      params: params,
    },
    {
      errorMessageMode: 'none',
    },
  )
}

/**
 * @description: 获取schema
 * @param {*} params
 * @return {*}
 */
export function getSchemas(params) {
  return defHttp.get<BasicResult>(
    {
      url: Api.schemaList,
      params: params,
    },
    {
      errorMessageMode: 'none',
    },
  )
}

/**
 * @description: 获取表格视图列表
 * @param {*} params
 * @return {*}
 */
export function getTableViewList(params) {
  return defHttp.get<BasicResult>({
    url: Api.tableInfoViews,
    params: params,
  })
}

/**
 * @description: 获取表格字段信息
 * @param params
 * @returns
 */
export function getTableColumns(params) {
  return defHttp.get<BasicResult>({
    url: Api.tableQuerySqlAndColumns,
    params: params,
  })
}

/**
 * @description: 根据sql获取字段信息
 * @param {*} params
 * @return {*}
 */
export function getColumnsList(params) {
  return defHttp.post<BasicResult>(
    {
      url: Api.columnsInfo,
      params: params,
    },
    {
      errorMessageMode: 'none',
    },
  )
}
/**
 * @description: 数据预览
 * @param {*} params
 * @return {*}
 */
export function preview(params) {
  return defHttp.post(
    {
      url: Api.previewData,
      params,
    },
    {
      errorMessageMode: 'none',
    },
  )
}

export function getDataSourceInfo(params) {
  return defHttp.get(
    {
      url: Api.dataSourceInfo + '/' + params,
    },
    {
      errorMessageMode: 'none',
    },
  )
}
