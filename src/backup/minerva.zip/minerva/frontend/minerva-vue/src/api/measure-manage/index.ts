import { defHttp } from '/@/utils/http/axios'
import { BasicResult } from '../model/baseModel'
import { GetMeasureListParams, MeasureInstance, Key, ValidField } from './model/measure'

enum Api {
  GetMeasureByPage = '/minerva-index-management-provider/minervaMeasuringInfo/page', // 分页查询度量信息
  GetMeasureList = '/minerva-index-management-provider/minervaMeasuringInfo/getList', // 度量信息集合
  AddMeasure = '/minerva-index-management-provider/minervaMeasuringInfo/add', // 新增度量信息
  UpdateMeasure = '/minerva-index-management-provider/minervaMeasuringInfo/update', // 修改度量信息
  DeleteMeasure = '/minerva-index-management-provider/minervaMeasuringInfo/', // 根据度量信息主键删除数据
  BatchDeleteMeasure = '/minerva-index-management-provider/minervaMeasuringInfo/batchDel/', // 根据度量信息主键批量删除数据
  GetMeasureDetail = '/minerva-index-management-provider/minervaMeasuringInfo/', // 根据code主键查看数据
  CheckFieldIsValid = '/minerva-index-management-provider/minervaMeasuringInfo/check', // 校验度量的名称、编号或排序是否存在
  Export = '/minerva-index-management-provider/minervaMeasuringInfo/export', // 导出
  ExportTemplate = '/minerva-index-management-provider/minervaMeasuringInfo/exportTemplate', // 导出模板
  ImportExcel = '/minerva-index-management-provider/minervaMeasuringInfo/importExcel', // 导入度量
}

/**
 * @description: 分页查询度量信息
 */
export function GetMeasureByPageApi(params: GetMeasureListParams) {
  return defHttp.get<BasicResult>({ url: Api.GetMeasureByPage, params: params })
}

/**
 * @description: 度量信息集合
 */
export function GetMeasureApi(params: GetMeasureListParams) {
  return defHttp.get<BasicResult>({ url: Api.GetMeasureList, params: params })
}

/**
 * @description: 新增度量信息
 */
export function AddMeasureApi(params: MeasureInstance) {
  return defHttp.post<BasicResult>({ url: Api.AddMeasure, params: params })
}

/**
 * @description: 修改度量信息
 */
export function UpdateMeasureApi(params: MeasureInstance) {
  return defHttp.put<BasicResult>({ url: Api.UpdateMeasure, params: params })
}

/**
 * @description: 根据度量信息主键删除数据
 */
export function DeleteMeasureApi(params: Key) {
  return defHttp.delete<BasicResult>({ url: `${Api.DeleteMeasure}${params.code}` })
}

/**
 * @description: 根据度量信息主键批量删除数据
 */
export function BatchDeleteMeasureApi(params: Key) {
  return defHttp.delete<BasicResult>({ url: `${Api.BatchDeleteMeasure}${params.code}` })
}

/**
 * @description: 根据code主键查看数据
 */
export function GetMeasureDetailApi(params: Key) {
  return defHttp.get<BasicResult>({ url: `${Api.GetMeasureDetail}${params.code}` })
}

/**
 * @description: 校验度量的名称、编号或排序是否存在
 */
export function CheckFieldIsValidApi(params: ValidField) {
  return defHttp.get<BasicResult>({ url: Api.CheckFieldIsValid, params: params })
}

/**
 * @description: 导出
 */
export function ExportApi(params: Key) {
  const token = localStorage.getItem('Authorization')
  return defHttp.get<BasicResult>({
    url: `${Api.Export}?codes=${params.codes}&access_token=${token}`,
    responseType: 'blob',
  })
}

/**
 * @description: 导出模板
 */
export function ExportTemplateApi() {
  const token = localStorage.getItem('Authorization')
  return defHttp.get<BasicResult>({
    url: `${Api.ExportTemplate}?access_token=${token}`,
    responseType: 'blob',
  })
}

/**
 * @description: 导入
 */
export function ImportExcelApi(params) {
  return defHttp.post<BasicResult>({ url: Api.ImportExcel, params })
}
