import { defHttp } from '/@/utils/http/axios'
import { Calcluate, GetIndexPageParams, IndexInstance, IndexModel } from './model/libraryModel'
import { BasicResult, Result } from '/@/api/model/baseModel'

enum Api {
  GetIndexPage = '/minerva-index-management-provider/minervaIndexBaseInfo/queryPage',
  DeleteIndex = '/minerva-index-management-provider/minervaIndexBaseInfo/delete',
  GetIndexType = '/minerva-index-management-provider/minervaIndexBaseInfo/indexType',
  GetReleaseStatus = '/minerva-index-management-provider/minervaIndexBaseInfo/releaseStatus',
  Release = '/minerva-index-management-provider/minervaIndexBaseInfo/release',
  CancelRelease = '/minerva-index-management-provider/minervaIndexBaseInfo/release/cancel',
  GetModels = '/minerva-index-model-provider/minervaModelInfo/list',
  GetQueryModelDimension = '/minerva-index-management-provider/minervaIndexBaseInfo/queryModelDimension',
  GetIndexQuery = '/minerva-index-management-provider/minervaIndexBaseInfo/query',
  GetFunctionGroupInfo = '/ceres-sql-server-provider/database/getFunctionGroupInfo',
  GetPortalFrequency = '/ceres-schedule-online-audit-provider/dpPortalFrequency',
  GetMeasuringList = '/minerva-index-management-provider/minervaMeasuringInfo/getList',
  GetCategoryTree = '/minerva-index-management-provider/minervaIndexCategory/queryTree',
  GetCreateType = '/minerva-index-management-provider/minervaIndexBaseInfo/createType',
  CheckCode = '/minerva-index-management-provider/minervaIndexBaseInfo/checkCode',
  CheckName = '/minerva-index-management-provider/minervaIndexBaseInfo/checkName',
  CheckExpression = '/minerva-index-management-provider/minervaIndexBaseInfo/check/expression',
  GetDimensionByCodes = '/minerva-index-management-provider/minervaIndexBaseInfo/queryDimension',
  AddIndex = '/minerva-index-management-provider/minervaIndexBaseInfo',
  UpdateIndex = '/minerva-index-management-provider/minervaIndexBaseInfo',
  GetIndex = '/minerva-index-management-provider/minervaIndexBaseInfo',
  GetFuntions = '/ceres-sql-server-provider/database/getFunctionInfo',
  TryCalculate = '/minerva-index-management-provider/minervaIndexBaseInfo/try/do',
  TryCalculateCount = '/minerva-index-management-provider/minervaIndexBaseInfo/try/do/count',
  AbleDataPreview = '/minerva-index-management-provider/minervaIndexBaseInfo/canPreview',
  DataPreview = '/minerva-index-management-provider/minervaIndexBaseInfo/preview',
  DataPreviewCount = '/minerva-index-management-provider/minervaIndexBaseInfo/previewCount',
  Online = '/minerva-index-management-provider/minervaIndexBaseInfo/online',
  Offline = '/minerva-index-management-provider/minervaIndexBaseInfo/online/cancel',
  GetSql = '/minerva-index-management-provider/minervaIndexBaseInfo/getSql',
  Export = '/minerva-index-management-provider/minervaIndexBaseInfo/export',
}

/**
 * @description: 分页查询
 */
export function GetIndexPageApi(params: GetIndexPageParams) {
  return defHttp.get<Result<IndexInstance>>({ url: Api.GetIndexPage, params })
}

/**
 * @description: 删除
 */
export function DeleteIndexApi(codes: string) {
  return defHttp.delete<BasicResult>({ url: `${Api.DeleteIndex}?codes=${codes}` })
}

/**
 * @description: 指标类型
 */
export function GetIndexTypeApi() {
  return defHttp.get<BasicResult>({ url: Api.GetIndexType })
}

/**
 * @description: 发布状态
 */
export function GetReleaseStatusApi() {
  return defHttp.get<BasicResult>({ url: Api.GetReleaseStatus })
}

/**
 * @description: 发布
 */
export function ReleaseApi(codes: string) {
  return defHttp.put<BasicResult>({ url: `${Api.Release}/?codes=${codes}` })
}

/**
 * @description: 取消发布
 */
export function CancelReleaseApi(codes: string) {
  return defHttp.put<BasicResult>({ url: `${Api.CancelRelease}?codes=${codes}` })
}

/**
 * @description: 获取模型列表
 */
export function GetModelsApi() {
  return defHttp.get<BasicResult>({ url: Api.GetModels })
}

/**
 * @description: 根据模型编码获取字段列表
 */
export function GetQueryModelDimensionApi(modelCode: string) {
  return defHttp.get<BasicResult>({ url: `${Api.GetQueryModelDimension}/${modelCode}` })
}

/**
 * @description: 获取基础指标/衍生指标
 */
export function GetIndexQueryApi(params) {
  return defHttp.get<BasicResult>({ url: Api.GetIndexQuery, params })
}

/**
 * @description: 获取统计函数
 */
export function GetFunctionGroupInfoApi() {
  return defHttp.get<BasicResult>({ url: Api.GetFunctionGroupInfo })
}

/**
 * @description: 获取门户上线频率列表
 */
export function GetPortalFrequencyApi() {
  return defHttp.get<BasicResult>({ url: Api.GetPortalFrequency })
}

/**
 * @description: 获取度量列表
 */
export function GetMeasuringListApi() {
  return defHttp.get<BasicResult>({ url: Api.GetMeasuringList })
}

/**
 * @description: 获取指标分类树形列表
 */
export function GetCategoryTreeApi() {
  return defHttp.get<BasicResult>({ url: Api.GetCategoryTree })
}

/**
 * @description: 获取指标创建方式
 */
export function GetCreateTypeApi() {
  return defHttp.get<BasicResult>({ url: Api.GetCreateType })
}

/**
 * @description: 验证指标编码是否唯一
 */
export function CheckCodeApi(indexCode: string) {
  return defHttp.get<BasicResult>({ url: `${Api.CheckCode}/${indexCode}` })
}

/**
 * @description: 验证指标名称是否唯一
 */
export function CheckNameApi(indexCode: string) {
  return defHttp.get<BasicResult>({ url: `${Api.CheckName}/${indexCode}` })
}

/**
 * @description: 验证表达式
 */
export function CheckExpressionApi(params) {
  return defHttp.post<BasicResult>({ url: Api.CheckExpression, params })
}

/**
 * @description: 根据codes获取维度数据，多个code：获取公共维度数据，单个code获取维度数据
 */
export function GetDimensionByCodesApi(codes: string) {
  return defHttp.get<BasicResult>({ url: `${Api.GetDimensionByCodes}?codes=${codes}` })
}

/**
 * @description: 添加指标
 */
export function AddIndexApi(params: IndexModel) {
  return defHttp.post<BasicResult>({ url: Api.AddIndex, params })
}

/**
 * @description: 编辑指标
 */
export function UpdateIndexApi(params: IndexModel) {
  return defHttp.put<BasicResult>({ url: Api.UpdateIndex, params })
}

/**
 * @description: 获取指标详情
 */
export function GetIndexApi(indexCode: string) {
  return defHttp.get<BasicResult>({ url: `${Api.GetIndex}/${indexCode}` })
}

/**
 * @description: 获取函数列表
 */
export function GetFuntionsApi() {
  return defHttp.get<BasicResult>({ url: Api.GetFuntions })
}

/**
 * @description: 试计算
 */
export function TryCalculateApi(params: Calcluate) {
  return defHttp.post<BasicResult>({ url: `${Api.TryCalculate}?page=1&pageSize=50`, params })
}

/**
 * @description: 试计算总数
 */
export function TryCalculateCountApi(params: Calcluate) {
  return defHttp.post<BasicResult>({ url: `${Api.TryCalculateCount}?page=1&pageSize=50`, params })
}

/**
 * @description: 判断是否可以数据预览
 */
export function AbleDataPreviewApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.AbleDataPreview}/${code}` })
}

/**
 * @description: 数据预览
 */
export function DataPreviewApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.DataPreview}/${code}` })
}

/**
 * @description: 数据预览总数统计
 */
export function DataPreviewCountApi(code: String) {
  return defHttp.get<BasicResult>({ url: `${Api.DataPreviewCount}/${code}` })
}

/**
 * @description: 上线
 */
export function OnlineApi(params) {
  return defHttp.put<BasicResult>({ url: Api.Online, params })
}

/**
 * @description: 撤回
 */
export function OfflineApi(params) {
  return defHttp.put<BasicResult>({ url: Api.Offline, params })
}

/**
 * @description: 查看逻辑
 */
export function GetSqlApi(params: Calcluate) {
  return defHttp.post<BasicResult>({ url: Api.GetSql, params })
}

/**
 * @description: 导出
 */
export function ExportApi(codes: string) {
  const token = localStorage.getItem('Authorization')
  return defHttp.get<BasicResult>({
    url: `${Api.Export}?codes=${codes}&access_token=${token}`,
    responseType: 'blob',
  })
}
