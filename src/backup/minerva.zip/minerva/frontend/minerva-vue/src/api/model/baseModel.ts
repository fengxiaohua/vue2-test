export interface BasicPageParams {
  page?: number
  pageSize?: number
}

export interface BasicFetchResult<T> {
  items: T[]
  total: number
}

export interface BasicResult {
  code: string | number
  msg: string
  data?: any
  content?: any
}

// 返回Result 换成泛型，自定义数据类型
export interface Result<T> {
  code: string | number
  msg: string
  data?: T
  content?: T
}
