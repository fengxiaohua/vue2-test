import { defHttp } from '/@/utils/http/axios'
import { BasicResult } from '../model/baseModel'
import {
  GetDimensionValueParams,
  DimensionValueInstance,
  Key,
  ValidField,
} from './model/dimensionValueModel'

enum Api {
  GetDimensionValueList = '/minerva-index-management-provider/minervaDimensionsValue/list', // 查询维度值列表
  GetDimensionValueTreeList = '/minerva-index-management-provider/minervaDimensionsValue/getTrees', // 查询维度值树级列表
  GetDimensionBaseInfoList = '/minerva-index-management-provider/minervaDimensionsBaseInfo/list', // 不分页查询维度值列表
  GetDimensionValueByPage = '/minerva-index-management-provider/minervaDimensionsValue/page', // 分页查询维度值
  AddDimensionValue = '/minerva-index-management-provider/minervaDimensionsValue/add', // 新增维度值
  BatchAddDimensionValue = '/minerva-index-management-provider/minervaDimensionsValue/batchAdd', // 批量新增维度值
  UpdateDimensionValue = '/minerva-index-management-provider/minervaDimensionsValue/update', // 修改维度值
  BatchDeleteDimensionValue = '/minerva-index-management-provider/minervaDimensionsValue/batchDel/', // 根据维度值主键批量删除数据
  GetDimensionValueDetail = '/minerva-index-management-provider/minervaDimensionsValue/', // 根据dimensionsBaseCode主键查看数据
  CheckFieldIsValid = '/minerva-index-management-provider/minervaDimensionsValue/check', // 校验维度值的名称、编号或排序是否存在
}

/**
 * @description: 查询维度值列表
 */
export function GetDimensionValueListApi(params: GetDimensionValueParams) {
  return defHttp.get<BasicResult>({ url: Api.GetDimensionValueList, params: params })
}

/**
 * @description: 查询维度值树级列表
 */
export function GetDimensionValueTreeListApi(params: GetDimensionValueParams) {
  return defHttp.get<BasicResult>({ url: Api.GetDimensionValueTreeList, params: params })
}

/**
 * @description: 分页查询维度值
 */
export function GetDimensionValueByPageApi(params: GetDimensionValueParams) {
  return defHttp.get<BasicResult>({ url: Api.GetDimensionValueByPage, params: params })
}

/**
 * @description: 查询维度值（不分页）
 */
export function GetDimensionValueWithoutPageApi() {
  return defHttp.get<BasicResult>({ url: Api.GetDimensionBaseInfoList })
}

/**
 * @description: 新增维度值
 */
export function AddDimensionValueApi(params: DimensionValueInstance) {
  return defHttp.post<BasicResult>({ url: Api.AddDimensionValue, params: params })
}

/**
 * @description: 批量新增维度值
 */
export function BatchAddDimensionValueApi(params: DimensionValueInstance) {
  return defHttp.post<BasicResult>({ url: Api.BatchAddDimensionValue, params: params })
}

/**
 * @description: 修改维度值
 */
export function UpdateDimensionValueApi(params: DimensionValueInstance) {
  return defHttp.put<BasicResult>({ url: Api.UpdateDimensionValue, params: params })
}

/**
 * @description: 根据维度值主键批量删除数据
 */
export function BatchDeleteDimensionValueApi(params: Key) {
  return defHttp.delete<BasicResult>({
    url: `${Api.BatchDeleteDimensionValue}${params.dimensionsBaseCode}/${params.code}`,
  })
}

/**
 * @description: 根据dimensionsBaseCode主键查看数据
 */
export function GetDimensionValueDetailApi(params: Key) {
  return defHttp.get<BasicResult>({
    url: `${Api.GetDimensionValueDetail}${params.dimensionsBaseCode}/${params.code}`,
  })
}

/**
 * @description: 校验维度值的名称、编号或排序是否存在
 */
export function CheckFieldIsValidApi(params: ValidField) {
  return defHttp.get<BasicResult>({ url: Api.CheckFieldIsValid, params: params })
}
