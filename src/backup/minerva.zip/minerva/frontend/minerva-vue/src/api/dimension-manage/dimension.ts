import { defHttp } from '/@/utils/http/axios'
import { BasicResult } from '../model/baseModel'
import {
  GetDimensionParams,
  DimensionInstance,
  Key,
  ValidField,
  ExportKey,
} from './model/dimensionModel'

enum Api {
  GetDimensionByPage = '/minerva-index-management-provider/minervaDimensionsBaseInfo/page', // 分页查询维度基本信息
  AddDimension = '/minerva-index-management-provider/minervaDimensionsBaseInfo/add', // 新增维度信息
  UpdateDimension = '/minerva-index-management-provider/minervaDimensionsBaseInfo/update', // 修改维度信息
  DeleteDimension = '/minerva-index-management-provider/minervaDimensionsBaseInfo/', // 根据维度基本信息主键删除数据
  BatchDeleteDimension = '/minerva-index-management-provider/minervaDimensionsBaseInfo/batchDel/', // 根据维度基本信息主键批量删除数据
  GetDimensionDetail = '/minerva-index-management-provider/minervaDimensionsBaseInfo/', // 根据code主键查看数据
  CheckFieldIsValid = '/minerva-index-management-provider/minervaDimensionsBaseInfo/check', // 校验维度的名称、编号或排序是否存在
  Export = '/minerva-index-management-provider/minervaDimensionsBaseInfo/export', // 导出
  ExportTemplate = '/minerva-index-management-provider/minervaDimensionsBaseInfo/exportTemplate', // 导出模板
  ImportExcel = '/minerva-index-management-provider/minervaDimensionsBaseInfo/importExcel', // 导入Excel
}

/**
 * @description: 分页查询维度基本信息
 */
export function GetDimensionByPageApi(params: GetDimensionParams) {
  return defHttp.get<BasicResult>({ url: Api.GetDimensionByPage, params: params })
}

/**
 * @description: 新增维度信息
 */
export function AddDimensionApi(params: DimensionInstance) {
  return defHttp.post<BasicResult>({ url: Api.AddDimension, params: params })
}

/**
 * @description: 修改维度信息
 */
export function UpdateDimensionApi(params: DimensionInstance) {
  return defHttp.put<BasicResult>({ url: Api.UpdateDimension, params: params })
}

/**
 * @description: 根据维度基本信息主键删除数据
 */
export function DeleteDimensionApi(params: Key) {
  return defHttp.delete<BasicResult>({ url: `${Api.DeleteDimension}${params.code}` })
}

/**
 * @description: 根据维度基本信息主键批量删除数据
 */
export function BatchDeleteDimensionApi(params: Key) {
  return defHttp.delete<BasicResult>({ url: `${Api.BatchDeleteDimension}${params.code}` })
}

/**
 * @description: 根据code主键查看数据
 */
export function GetDimensionDetailApi(params: Key) {
  return defHttp.get<BasicResult>({ url: `${Api.GetDimensionDetail}${params.code}` })
}

/**
 * @description: 校验维度的名称、编号或排序是否存在
 */
export function CheckFieldIsValidApi(params: ValidField) {
  return defHttp.get<BasicResult>({ url: Api.CheckFieldIsValid, params: params })
}

/**
 * @description: 导出
 */
export function ExportApi(params: ExportKey) {
  const token = localStorage.getItem('Authorization')
  return defHttp.get<BasicResult>({
    url: `${Api.Export}?type=${params.type}&modelCodes=${params.modelCodes}&valueCodes=${params.valueCodes}&access_token=${token}`,
    responseType: 'blob',
  })
}

/**
 * @description: 导出模板
 */
export function ExportTemplateApi() {
  const token = localStorage.getItem('Authorization')
  return defHttp.get<BasicResult>({
    url: `${Api.ExportTemplate}?access_token=${token}`,
    responseType: 'blob',
  })
}

/**
 * @description: 导入
 */
export function ImportExcelApi(params) {
  return defHttp.post<BasicResult>({ url: Api.ImportExcel, params })
}
