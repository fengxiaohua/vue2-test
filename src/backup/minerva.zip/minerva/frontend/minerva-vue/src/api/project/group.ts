import { defHttp } from '/@/utils/http/axios'
import { GetGroupParams } from './model/group'
import { BasicResult } from '../model/baseModel'

enum Api {
  getGroup = '/escat-common-group-provider/group/selectLikeBy/TSJB',
  updateGroup = '/escat-common-group-provider/group/update',
  deleteGroup = '/escat-common-group-provider/group/delete/',
  deleteGroups = '/escat-common-group-provider/group/deleteBatch',
  queryExistsGroup = '/escat-common-group-provider/group/queryGroupExists',
  getGroups = '/escat-common-group-provider/group/selectBy/',
  getConnection = '/escat-portal-model-management-provider/datasource/getDatasourceNoPageBySourcePlat',
  getEngineInfo = '/escat-portal-model-management-provider/datasource/getEngIneClinkHouse',
  addGroup = '/escat-common-group-provider/group/add',
  checkGroupName = '/escat-common-group-provider/group/checkGroupName',
  selectLikeByProjectName = '/escat-common-project-provider/project/selectLikeByProjectName/',
  getGroupListByType = '/escat-common-group-provider/group/selectBy/TSJB',
}
/**
 * @description: 获取分组列表
 */
export function getGroup(params: GetGroupParams) {
  return defHttp.get<BasicResult>({ url: Api.getGroup, params: params })
}

/**
 * @description: 查询分组名称是否可用
 */
export function checkGroupName(params) {
  return defHttp.get<BasicResult>({ url: Api.checkGroupName, params: params })
}

/**
 * @description: 新增分组
 */
export function addGroup(data) {
  return defHttp.post<BasicResult>({ url: Api.addGroup, data }, { errorMessageMode: 'none' })
}

/**
 * @description: 更新分组
 */
export function updateGroup(data) {
  return defHttp.put<BasicResult>({ url: Api.updateGroup, data }, { errorMessageMode: 'none' })
}

/**
 * @description: 更新分组
 */
export function selectLikeByProjectName(params) {
  return defHttp.get<BasicResult>({ url: Api.selectLikeByProjectName + params.groupId, params })
}

/**
 * @description: 删除分组
 */
export function deleteGroup(groupId) {
  return defHttp.delete<BasicResult>({ url: Api.deleteGroup + groupId })
}

/**
 * @description: 批量删除分组
 */
export function deleteGroups(params) {
  return defHttp.delete<BasicResult>({
    url: `${Api.deleteGroups}?groupIds=${params.groupIds}`,
  })
}

/**
 * @description: 根据类型查询分组
 */
export function getGroupsByType(params) {
  return defHttp.get<BasicResult>({
    url: `${Api.getGroupListByType}`,
    params: params,
  })
}
