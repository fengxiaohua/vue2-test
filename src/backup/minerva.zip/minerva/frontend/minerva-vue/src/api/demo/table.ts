import { defHttp } from '/@/utils/http/axios'
// DemoListGetResultModel
import { DemoParams } from './model/tableModel'
import { BasicResult } from '../model/baseModel'

enum Api {
  DEMO_LIST = '/table/getDemoList',
}

/**
 * @description: Get sample list value
 */

export const demoListApi = (params: DemoParams) =>
  // defHttp.get<DemoListGetResultModel>({
  defHttp.get<BasicResult>({
    url: Api.DEMO_LIST,
    params,
    headers: {
      // @ts-ignore
      ignoreCancelToken: true,
    },
  })
