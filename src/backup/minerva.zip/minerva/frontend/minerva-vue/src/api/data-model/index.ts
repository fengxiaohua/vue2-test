import { defHttp } from '/@/utils/http/axios'
import { Result, BasicResult } from '../model/baseModel'
import { DataModelTable } from './model/dataModel'
import {
  AssetPackDir,
  FieldInfo,
  AddAssetPackModalParams,
  UpdateAssetPackModalParams,
} from './model/addAssetPackModel'
// import type { DataModalFieldInfo } from './model/dataModalField'

enum Api {
  GetModelTable = '/minerva-index-model-provider/minervaModelInfo/page',
  GetAssetPackModelDir = '/ceres-asset-management-provider/dmAssetGroupUserRelation/getTreesWithPackages',
  GetFieldInfo = '/minerva-index-model-provider/minervaModelInfo/parseFields',
  DataModalByCode = '/minerva-index-model-provider/minervaModelInfo',
  DataModalBatchDelete = '/minerva-index-model-provider/minervaModelInfo/batchDel',
  // UpdateDataModalFieldInfo = '/minerva-index-model-provider/minervaModelInfo/update',
  PostAddDataModal = '/minerva-index-model-provider/minervaModelInfo/add',
  PostEditDataModal = '/minerva-index-model-provider/minervaModelInfo/update',
  asyncDataModal = '/minerva-index-model-provider/minervaModelInfo/syncData',
  CreateTable = '/minerva-index-model-provider/minervaModelInfo/createTable',
  GetDataModalInfo = '/minerva-index-model-provider/minervaModelInfo/getDetail',
  GetFieldsWithCode = '/minerva-index-management-provider/minervaModelFieldInfo/getFields',
  GetFieldsWithRelCode = '/minerva-index-management-provider/minervaModelFieldInfo/getFieldsWithRelCode',
  ValidateDataModalName = '/minerva-index-model-provider/minervaModelInfo/check',
  ValidateFieldInfo = '/minerva-index-management-provider/minervaModelFieldInfo/check',
  DataPreview = '/minerva-index-model-provider/minervaModelInfo/preview',
  DataPreviewCount = '/minerva-index-model-provider/minervaModelInfo/count',
  ValidateSQL = '/minerva-index-model-provider/minervaModelInfo/checkSql',
  GetDataSourceSQl = '/minerva-index-model-provider/minervaModelInfo/getDataSource',
  VerificationOfRule = '/minerva-index-management-provider/minervaModelFieldInfo/verificationOfRule',
  PrivewSQL = '/minerva-index-model-provider/minervaModelInfo/previewForSql',
  UpdateModelFieldInfo = '/minerva-index-management-provider/minervaModelFieldInfo/update',
  BatchDeleteModelFieldInfo = '/minerva-index-management-provider/minervaModelFieldInfo/batchDel',
  BatchBatchAddModelFieldInfo = '/minerva-index-management-provider/minervaModelFieldInfo/batchAdd',
}

/**
 * @description: 修改模型字段
 */
export function UpdateModalFieldInfo(params) {
  return defHttp.put<BasicResult>({ url: Api.UpdateModelFieldInfo, params })
}

/**
 * @description: 批量删除模型字段 /{pks}
 */
export function BatchDeleteModelFieldInfo(params, code) {
  return defHttp.delete<BasicResult>({
    url: Api.BatchDeleteModelFieldInfo + '/' + params + '?modelCode=' + code,
  })
}

/**
 * @description: 批量新增模型字段
 */
export function BatchBatchAddModelFieldInfo(params, code) {
  return defHttp.post<BasicResult>({
    url: Api.BatchBatchAddModelFieldInfo + '?modelCode=' + code,
    params,
  })
}

/**
 * @description: PrivewSQL 预览SQL
 */
export function privewSQL(params) {
  return defHttp.post({ url: Api.PrivewSQL + '?' + `sql=${params.sql}&dsName=${params.dsName}` })
}

/**
 * @description: ​/minervaModelFieldInfo​/verificationOfRule 校验落地表
 */
export function GetverificationOfRule(params) {
  return defHttp.get<BasicResult>({ url: Api.VerificationOfRule, params })
}

/**
 * @description： ​/{modelCode} 通过模型编码获取数据源
 */
export function getDataSourceSQLInfo(code) {
  return defHttp.get<BasicResult>({ url: Api.GetDataSourceSQl + '/' + code })
}

/**
 * @description: 校验SQL
 */
export function validateSQL(params) {
  return defHttp.post<BasicResult>({ url: Api.ValidateSQL, params })
}

/**
 * @description:  校验名称
 */
export function validateDataModal(params) {
  return defHttp.get<BasicResult>({ url: Api.ValidateDataModalName, params })
}

/**
 * @description: 校验模型编码，字段中文名，字段英文名
 */
export function ValidateFieldInfo(params) {
  return defHttp.get<BasicResult>({ url: Api.ValidateFieldInfo, params })
}

/**
 * @description: 根据模型编码获取字段
 */
export function getFieldsWithCode(code) {
  return defHttp.get<BasicResult>({ url: Api.GetFieldsWithCode + '/' + code })
}

/**
 * @description: 根据模型编码获取字段(带relCode,relName,relType)
 */
export function getFieldsWithRelCode(code) {
  return defHttp.get<BasicResult>({ url: Api.GetFieldsWithRelCode + '/' + code })
}

/**
 * @description: 获取分组列表
 */
export function getDataModel(params: DataModelTable) {
  return defHttp.get<Result<DataModelTable>>({ url: Api.GetModelTable, params: params })
}

/**
 * @description: /{code} 查看模型信息，带资产包信息
 */
export function GetDataModalInfo(code, type) {
  return defHttp.get<BasicResult>({ url: Api.GetDataModalInfo + '/' + code + '?type=' + type })
}

/**
 * @description: 根据模型编码获取模型信息
 */
export function getModelDataInfoByCode(code) {
  return defHttp.get<BasicResult>({ url: Api.DataModalByCode + '/' + code })
}

/**
 * @description:  落地建表
 */
export function createTable(params) {
  return defHttp.post<BasicResult>({
    url: Api.CreateTable + '?modelCode=' + params.modelCode,
    params: params.minervaModelFieldInfoVos,
  })
}

/**
 * @description: 获取新增模型-根据资产包引入-资产包数据
 */
export function getAssetPackModelDir() {
  return defHttp.get<Result<Array<AssetPackDir>>>({ url: Api.GetAssetPackModelDir })
}

/**
 * @description: 数据同步
 */
export function asyncDataModal(params) {
  return defHttp.post<BasicResult>({
    url:
      Api.asyncDataModal +
      `?dateTime=${params.dataTime}&modelCode=${params.modelCode}&type=${params.type}`,
  })
}

/**
 * @description: 获取配置字段信息
 */
export function getParseField(params) {
  return defHttp.post<Result<FieldInfo>>({
    url: Api.GetFieldInfo + '?type=' + params.type,
    params: params,
  })
}

/**
 * @description: 根据模型信息主键删除数据
 */
export function deleteDataModalByCode(code) {
  return defHttp.delete<BasicResult>({ url: Api.DataModalByCode + '/' + code })
}

/**
 * @description: 批量删除模型
 */
export function deleteDataModalBatch(params) {
  return defHttp.delete<BasicResult>({ url: Api.DataModalBatchDelete + '/' + params })
}

/**
 * @description: 修改模型字段
 */
// export function updateDataModalFieldInfo(params: DataModalFieldInfo) {
//   return defHttp.put<BasicResult>({ url: Api.UpdateDataModalFieldInfo, params })
// }

/**
 * @description: 新增模型（根据资产包引入）
 */
export function PostAddDataModal(params: AddAssetPackModalParams) {
  return defHttp.post<BasicResult>({ url: Api.PostAddDataModal, params })
}

/**
 * @description: 新增模型（根据资产包引入）
 */
export function PutEditDataModal(params: UpdateAssetPackModalParams) {
  return defHttp.put<BasicResult>({ url: Api.PostEditDataModal, params })
}

/**
 * @description: 数据预览
 */
export function DataPreviewApi(code) {
  return defHttp.get<BasicResult>({ url: `${Api.DataPreview}/${code}` })
}

/**
 * @description: 数据预览总数统计
 */
export function DataPreviewCountApi(code) {
  return defHttp.get<BasicResult>({ url: `${Api.DataPreviewCount}/${code}` })
}
