import { defHttp } from '/@/utils/http/axios'
import { Result } from '../model/baseModel'
import type { GetDictParams, BasicDictResult } from './model/dictModel'

enum API {
  GetDictOption = '/escat-portal-system-management-provider/dict/query',
}

export function getDictOptions(params: GetDictParams) {
  return defHttp.get<Result<Array<BasicDictResult>>>({ url: API.GetDictOption, params })
}
