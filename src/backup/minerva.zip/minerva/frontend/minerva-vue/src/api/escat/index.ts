import { defHttp } from '/@/utils/http/axios'
import { BasicResult } from '../model/baseModel'

enum Api {
  GetpreviewDataPage = '/escat-de-run-management-provider/preview/previewDataPage',
}

/**
 * @description: 获取数据预览数据
 */
export function getpreviewDataPage(params) {
  return defHttp.post<BasicResult>({ url: Api.GetpreviewDataPage, params })
}
