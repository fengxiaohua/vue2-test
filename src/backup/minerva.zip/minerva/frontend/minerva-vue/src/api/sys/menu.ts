import { defHttp } from '/@/utils/http/axios'
// import { getMenuListResultModel } from './model/menuModel';
import { BasicResult } from '/@/api/model/baseModel'
enum Api {
  // GetMenuList = '/getMenuList',
  GetMenuList = '/rbac-user-server/permission/myListTree/',
}

/**
 * @description: Get user menu based on id
 */

export const getMenuList = () => {
  // return defHttp.get<getMenuListResultModel>({ url: Api.GetMenuList });
  return defHttp.get<BasicResult>({ url: Api.GetMenuList })
}
