import { MockMethod } from 'vite-plugin-mock'
import {
  resultError,
  loginResultSuccess,
  resultSuccess,
  getRequestToken,
  requestParams,
} from '../_util'

export function createFakeUserList() {
  return [
    {
      username: 'admin',
      password: 'admin',
      access_token:
        'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX3R5cGUiOm51bGwsInVzZXJfY25hbWUiOiLmoYjkvotf5pWw6YeR6YOoX-aVsOaNrueuoeeQhuWRmCIsInVzZXJfaWQiOjg5LCJ1c2VyX25hbWUiOiJkZW1vX2dsIiwic2NvcGUiOlsiZGVmYXVsdC1zY29wZSJdLCJyb2xlcyI6W3siaWQiOjIsImNvZGUiOiJvcmRpbmFyeV91c2VyIiwicm9sZUxldmVsIjoxfSx7ImlkIjozLCJjb2RlIjoiYWRtaW4iLCJyb2xlTGV2ZWwiOjF9LHsiaWQiOjM5LCJjb2RlIjoibWFzc3JlbGF5LWFwaSIsInJvbGVMZXZlbCI6MX0seyJpZCI6NDUsImNvZGUiOiJkYXRhX2dsIiwicm9sZUxldmVsIjoxfSx7ImlkIjo0NiwiY29kZSI6ImRhdGFfeXciLCJyb2xlTGV2ZWwiOjF9XSwiZXhwIjoxNjUzODM2MjA5LCJhdXRob3JpdGllcyI6WyJhZG1pbiIsIm1hc3NyZWxheS1hcGkiLCJvcmRpbmFyeV91c2VyIiwiZGF0YV95dyIsImRhdGFfZ2wiXSwianRpIjoiMDkwYWIzNWEtZjE1ZS00OWRmLThhNjctZmEyZGMyZDQ3MTk3IiwiYWNjb3VudCI6ImRlbW9fZ2wiLCJjbGllbnRfaWQiOiJzdGVsbGEtY2xpZW50In0.N6sCjctn3Dtn_hD1-dDTGbvzTAY4JMYxhG5f-b4V8vwO8RWKN5L_fKoWAUirMckh8A4XtAHxXVYUUDoUL2Trndx0fhAy8r6HyvK8wp-cipiWeb_D5ty7rquJIQYJgHJg_TQPuswRayogL4X_Rx5EaJuPbrlMStIbtF4Cue7OE3A',
      token_type: 'bearer',
      refresh_token:
        'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX3R5cGUiOm51bGwsInVzZXJfY25hbWUiOiLmoYjkvotf5pWw6YeR6YOoX-aVsOaNrueuoeeQhuWRmCIsInVzZXJfaWQiOjg5LCJ1c2VyX25hbWUiOiJkZW1vX2dsIiwic2NvcGUiOlsiZGVmYXVsdC1zY29wZSJdLCJyb2xlcyI6W3siaWQiOjIsImNvZGUiOiJvcmRpbmFyeV91c2VyIiwicm9sZUxldmVsIjoxfSx7ImlkIjozLCJjb2RlIjoiYWRtaW4iLCJyb2xlTGV2ZWwiOjF9LHsiaWQiOjM5LCJjb2RlIjoibWFzc3JlbGF5LWFwaSIsInJvbGVMZXZlbCI6MX0seyJpZCI6NDUsImNvZGUiOiJkYXRhX2dsIiwicm9sZUxldmVsIjoxfSx7ImlkIjo0NiwiY29kZSI6ImRhdGFfeXciLCJyb2xlTGV2ZWwiOjF9XSwiYXRpIjoiMDkwYWIzNWEtZjE1ZS00OWRmLThhNjctZmEyZGMyZDQ3MTk3IiwiZXhwIjoxNjUzODM2MjA5LCJhdXRob3JpdGllcyI6WyJhZG1pbiIsIm1hc3NyZWxheS1hcGkiLCJvcmRpbmFyeV91c2VyIiwiZGF0YV95dyIsImRhdGFfZ2wiXSwianRpIjoiMGE1MDRiNDMtNDY4MS00YmYwLTg3ZjMtNzhlZWY4ZTU0M2EyIiwiYWNjb3VudCI6ImRlbW9fZ2wiLCJjbGllbnRfaWQiOiJzdGVsbGEtY2xpZW50In0.L-HWxY2yONtqpnNOFxY-NkTp1qUyB1tQl4Z0Q_VkozUm-AorWSWl79sN0YCgNwEptG8Q7ZZWYIb3zz_sjZ-DP4UUCE2hT7uOh66b8MoPLG8X3HYmGo74ELvb1gskhGFlJoiBaTttv04TADhNzouJ7--9wIW6BTAdaaDN6BUe9sU',
      expires_in: 863999,
      scope: 'default-scope',
      user_type: null,
      user_cname: '案例_数金部_数据管理员',
      user_id: 89,
      account: 'demo_gl',
      user_name: 'demo_gl',
      roles: [
        { id: 2, code: 'ordinary_user', roleLevel: 1 },
        { id: 3, code: 'admin', roleLevel: 1 },
        { id: 39, code: 'massrelay-api', roleLevel: 1 },
        { id: 45, code: 'data_gl', roleLevel: 1 },
        { id: 46, code: 'data_yw', roleLevel: 1 },
      ],
      jti: '090ab35a-f15e-49df-8a67-fa2dc2d47197',
    },
    {
      userId: '1',
      username: 'vadmin',
      realName: '超级管理员',
      avatar: 'https://q1.qlogo.cn/g?b=qq&nk=190848757&s=640',
      desc: 'manager',
      password: 'admin',
      token: 'fakeToken1',
      // homePath: '/dashboard/analysis',
      homePath: '/home',
      roles: [
        {
          roleName: 'Super Admin',
          value: 'super',
        },
      ],
    },
    {
      userId: '2',
      username: 'test',
      password: '123456',
      realName: 'test user',
      avatar: 'https://q1.qlogo.cn/g?b=qq&nk=339449197&s=640',
      desc: 'tester',
      token: 'fakeToken2',
      homePath: '/dashboard/workbench',
      roles: [
        {
          roleName: 'Tester',
          value: 'test',
        },
      ],
    },
  ]
}

const fakeCodeList: any = {
  '1': ['1000', '3000', '5000'],

  '2': ['2000', '4000', '6000'],
}
export default [
  // mock user login
  {
    // url: '/api/login',
    url: '/api/rbac-user-server/oauth/token',
    timeout: 200,
    method: 'post',
    response: ({ body }) => {
      console.log('response body', body)
      // const { username, password } = body;
      // const checkUser = createFakeUserList().find(
      //   (item) => item.username === username && password === item.password,
      // );
      const checkUser = {
        access_token:
          'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX3R5cGUiOm51bGwsInVzZXJfY25hbWUiOiLmoYjkvotf5pWw6YeR6YOoX-aVsOaNrueuoeeQhuWRmCIsInVzZXJfaWQiOjg5LCJ1c2VyX25hbWUiOiJkZW1vX2dsIiwic2NvcGUiOlsiZGVmYXVsdC1zY29wZSJdLCJyb2xlcyI6W3siaWQiOjIsImNvZGUiOiJvcmRpbmFyeV91c2VyIiwicm9sZUxldmVsIjoxfSx7ImlkIjozLCJjb2RlIjoiYWRtaW4iLCJyb2xlTGV2ZWwiOjF9LHsiaWQiOjM5LCJjb2RlIjoibWFzc3JlbGF5LWFwaSIsInJvbGVMZXZlbCI6MX0seyJpZCI6NDUsImNvZGUiOiJkYXRhX2dsIiwicm9sZUxldmVsIjoxfSx7ImlkIjo0NiwiY29kZSI6ImRhdGFfeXciLCJyb2xlTGV2ZWwiOjF9XSwiZXhwIjoxNjUzODM2MjA5LCJhdXRob3JpdGllcyI6WyJhZG1pbiIsIm1hc3NyZWxheS1hcGkiLCJvcmRpbmFyeV91c2VyIiwiZGF0YV95dyIsImRhdGFfZ2wiXSwianRpIjoiMDkwYWIzNWEtZjE1ZS00OWRmLThhNjctZmEyZGMyZDQ3MTk3IiwiYWNjb3VudCI6ImRlbW9fZ2wiLCJjbGllbnRfaWQiOiJzdGVsbGEtY2xpZW50In0.N6sCjctn3Dtn_hD1-dDTGbvzTAY4JMYxhG5f-b4V8vwO8RWKN5L_fKoWAUirMckh8A4XtAHxXVYUUDoUL2Trndx0fhAy8r6HyvK8wp-cipiWeb_D5ty7rquJIQYJgHJg_TQPuswRayogL4X_Rx5EaJuPbrlMStIbtF4Cue7OE3A',
        token_type: 'bearer',
        refresh_token:
          'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX3R5cGUiOm51bGwsInVzZXJfY25hbWUiOiLmoYjkvotf5pWw6YeR6YOoX-aVsOaNrueuoeeQhuWRmCIsInVzZXJfaWQiOjg5LCJ1c2VyX25hbWUiOiJkZW1vX2dsIiwic2NvcGUiOlsiZGVmYXVsdC1zY29wZSJdLCJyb2xlcyI6W3siaWQiOjIsImNvZGUiOiJvcmRpbmFyeV91c2VyIiwicm9sZUxldmVsIjoxfSx7ImlkIjozLCJjb2RlIjoiYWRtaW4iLCJyb2xlTGV2ZWwiOjF9LHsiaWQiOjM5LCJjb2RlIjoibWFzc3JlbGF5LWFwaSIsInJvbGVMZXZlbCI6MX0seyJpZCI6NDUsImNvZGUiOiJkYXRhX2dsIiwicm9sZUxldmVsIjoxfSx7ImlkIjo0NiwiY29kZSI6ImRhdGFfeXciLCJyb2xlTGV2ZWwiOjF9XSwiYXRpIjoiMDkwYWIzNWEtZjE1ZS00OWRmLThhNjctZmEyZGMyZDQ3MTk3IiwiZXhwIjoxNjUzODM2MjA5LCJhdXRob3JpdGllcyI6WyJhZG1pbiIsIm1hc3NyZWxheS1hcGkiLCJvcmRpbmFyeV91c2VyIiwiZGF0YV95dyIsImRhdGFfZ2wiXSwianRpIjoiMGE1MDRiNDMtNDY4MS00YmYwLTg3ZjMtNzhlZWY4ZTU0M2EyIiwiYWNjb3VudCI6ImRlbW9fZ2wiLCJjbGllbnRfaWQiOiJzdGVsbGEtY2xpZW50In0.L-HWxY2yONtqpnNOFxY-NkTp1qUyB1tQl4Z0Q_VkozUm-AorWSWl79sN0YCgNwEptG8Q7ZZWYIb3zz_sjZ-DP4UUCE2hT7uOh66b8MoPLG8X3HYmGo74ELvb1gskhGFlJoiBaTttv04TADhNzouJ7--9wIW6BTAdaaDN6BUe9sU',
        expires_in: 863999,
        scope: 'default-scope',
        user_type: null,
        user_cname: '案例_数金部_数据管理员',
        user_id: 89,
        account: 'demo_gl',
        user_name: 'demo_gl',
        roles: [
          { id: 2, code: 'ordinary_user', roleLevel: 1 },
          { id: 3, code: 'admin', roleLevel: 1 },
          { id: 39, code: 'massrelay-api', roleLevel: 1 },
          { id: 45, code: 'data_gl', roleLevel: 1 },
          { id: 46, code: 'data_yw', roleLevel: 1 },
        ],
        jti: '090ab35a-f15e-49df-8a67-fa2dc2d47197',
      }
      if (!checkUser) {
        return resultError('账号或密码错误！')
      }
      // const { user_id, user_cname, access_token, user_name, roles } = checkUser;
      return loginResultSuccess(checkUser)
    },
  },
  {
    url: '/api/getUserInfo',
    method: 'get',
    response: (request: requestParams) => {
      const token = getRequestToken(request)
      if (!token) return resultError('Invalid token')
      const checkUser = createFakeUserList().find((item) => item.token === token)
      if (!checkUser) {
        return resultError('The corresponding user information was not obtained!')
      }
      return resultSuccess(checkUser)
    },
  },
  {
    url: '/api/getPermCode',
    timeout: 200,
    method: 'get',
    response: (request: requestParams) => {
      const token = getRequestToken(request)
      if (!token) return resultError('Invalid token')
      const checkUser = createFakeUserList().find((item) => item.token === token)
      if (!checkUser) {
        return resultError('Invalid token!')
      }
      const codeList = fakeCodeList[checkUser.user_id || '']

      return resultSuccess(codeList)
    },
  },
  {
    // url: '/api/logout',
    url: '/api/rbac-user-server/oauth/logout',
    timeout: 200,
    method: 'get',
    response: (request: requestParams) => {
      const token = getRequestToken(request)
      if (!token) return resultError('Invalid token')
      const checkUser = createFakeUserList().find((item) => item.token === token)
      if (!checkUser) {
        return resultError('Invalid token!')
      }
      return resultSuccess(undefined, { msg: 'Token has been destroyed' })
    },
  },
  {
    url: '/api/testRetry',
    statusCode: 405,
    method: 'get',
    response: () => {
      return resultError('Error!')
    },
  },
] as MockMethod[]
