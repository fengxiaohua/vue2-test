import { resultSuccess, resultError, getRequestToken, requestParams } from '../_util'
import { MockMethod } from 'vite-plugin-mock'
import { createFakeUserList } from './user'

// single
// const dashboardRoute = {
//   path: '/dashboard',
//   name: 'Dashboard',
//   component: 'LAYOUT',
//   redirect: '/dashboard/analysis',
//   meta: {
//     title: 'routes.dashboard.dashboard',
//     hideChildrenInMenu: true,
//     icon: 'bx:bx-home',
//   },
//   children: [
//     {
//       path: 'analysis',
//       name: 'Analysis',
//       component: '/dashboard/analysis/index',
//       meta: {
//         hideMenu: true,
//         hideBreadcrumb: true,
//         title: 'routes.dashboard.analysis',
//         currentActiveMenu: '/dashboard',
//         icon: 'bx:bx-home',
//       },
//     },
//     {
//       path: 'workbench',
//       name: 'Workbench',
//       component: '/dashboard/workbench/index',
//       meta: {
//         hideMenu: true,
//         hideBreadcrumb: true,
//         title: 'routes.dashboard.workbench',
//         currentActiveMenu: '/dashboard',
//         icon: 'bx:bx-home',
//       },
//     },
//   ],
// };
const dashboardRoute = {
  path: '/home',
  name: 'Home',
  component: 'LAYOUT',
  meta: {
    title: '首页',
    hideChildrenInMenu: true,
    icon: 'bx:bx-home',
  },
  children: [
    {
      path: '',
      name: 'Home',
      component: '/home/index',
      meta: {
        hideMenu: true,
        hideBreadcrumb: true,
        title: '首页',
        currentActiveMenu: '/home',
        icon: 'bx:bx-home',
      },
    },
  ],
}

const backRoute = {
  path: 'back',
  name: 'PermissionBackDemo',
  meta: {
    title: 'routes.demo.permission.back',
  },

  children: [
    {
      path: 'page',
      name: 'BackAuthPage',
      component: '/demo/permission/back/index',
      meta: {
        title: 'routes.demo.permission.backPage',
      },
    },
    {
      path: 'btn',
      name: 'BackAuthBtn',
      component: '/demo/permission/back/Btn',
      meta: {
        title: 'routes.demo.permission.backBtn',
      },
    },
  ],
}

const authRoute = {
  path: '/permission',
  name: 'Permission',
  component: 'LAYOUT',
  redirect: '/permission/front/page',
  meta: {
    icon: 'carbon:user-role',
    title: 'routes.demo.permission.permission',
  },
  children: [backRoute],
}

const levelRoute = {
  path: '/level',
  name: 'Level',
  component: 'LAYOUT',
  redirect: '/level/menu1/menu1-1',
  meta: {
    icon: 'carbon:user-role',
    title: 'routes.demo.level.level',
  },

  children: [
    {
      path: 'menu1',
      name: 'Menu1Demo',
      meta: {
        title: 'Menu1',
      },
      children: [
        {
          path: 'menu1-1',
          name: 'Menu11Demo',
          meta: {
            title: 'Menu1-1',
          },
          children: [
            {
              path: 'menu1-1-1',
              name: 'Menu111Demo',
              component: '/demo/level/Menu111',
              meta: {
                title: 'Menu111',
              },
            },
          ],
        },
        {
          path: 'menu1-2',
          name: 'Menu12Demo',
          component: '/demo/level/Menu12',
          meta: {
            title: 'Menu1-2',
          },
        },
      ],
    },
    {
      path: 'menu2',
      name: 'Menu2Demo',
      component: '/demo/level/Menu2',
      meta: {
        title: 'Menu2',
      },
    },
  ],
}
const projectRoute = {
  path: '/project',
  name: 'ProjectMange',
  component: 'LAYOUT',
  redirect: '/project/list',
  meta: {
    title: '项目管理',
    icon: 'carbon:user-role',
  },

  children: [
    {
      path: 'list',
      name: 'ProjectList',
      component: '/project/index',
      meta: {
        ignoreKeepAlive: true,
        title: '项目列表',
      },
    },
  ],
}
const sysRoute = {
  path: '/system',
  name: 'System',
  component: 'LAYOUT',
  redirect: '/system/account',
  meta: {
    icon: 'ion:settings-outline',
    title: 'routes.demo.system.moduleName',
  },
  children: [
    {
      path: 'account',
      name: 'AccountManagement',
      meta: {
        title: 'routes.demo.system.account',
        ignoreKeepAlive: true,
      },
      component: '/demo/system/account/index',
    },
    {
      path: 'account_detail/:id',
      name: 'AccountDetail',
      meta: {
        hideMenu: true,
        title: 'routes.demo.system.account_detail',
        ignoreKeepAlive: true,
        showMenu: false,
        currentActiveMenu: '/system/account',
      },
      component: '/demo/system/account/AccountDetail',
    },
    {
      path: 'role',
      name: 'RoleManagement',
      meta: {
        title: 'routes.demo.system.role',
        ignoreKeepAlive: true,
      },
      component: '/demo/system/role/index',
    },

    {
      path: 'menu',
      name: 'MenuManagement',
      meta: {
        title: 'routes.demo.system.menu',
        ignoreKeepAlive: true,
      },
      component: '/demo/system/menu/index',
    },
    {
      path: 'dept',
      name: 'DeptManagement',
      meta: {
        title: 'routes.demo.system.dept',
        ignoreKeepAlive: true,
      },
      component: '/demo/system/dept/index',
    },
    {
      path: 'changePassword',
      name: 'ChangePassword',
      meta: {
        title: 'routes.demo.system.password',
        ignoreKeepAlive: true,
      },
      component: '/demo/system/password/index',
    },
  ],
}

const linkRoute = {
  path: '/link',
  name: 'Link',
  component: 'LAYOUT',
  meta: {
    icon: 'ion:tv-outline',
    title: 'routes.demo.iframe.frame',
  },
  children: [
    {
      path: 'doc',
      name: 'Doc',
      meta: {
        title: 'routes.demo.iframe.doc',
        frameSrc: 'https://vvbin.cn/doc-next/',
      },
    },
    {
      path: 'https://vvbin.cn/doc-next/',
      name: 'DocExternal',
      component: 'LAYOUT',
      meta: {
        title: 'routes.demo.iframe.docExternal',
      },
    },
  ],
}

const tableRoute = {
  path: '/table',
  name: 'TableDemo',
  component: 'LAYOUT',
  redirect: '/table/basic',
  meta: {
    icon: 'carbon:table-split',
    title: 'routes.demo.table.table',
  },

  children: [
    {
      path: 'basic',
      name: 'TableBasicDemo',
      component: '/demo/table/Basic',
      meta: {
        title: 'routes.demo.table.basic',
      },
    },
    {
      path: 'treeTable',
      name: 'TreeTableDemo',
      component: '/demo/table/TreeTable',
      meta: {
        title: 'routes.demo.table.treeTable',
      },
    },
    {
      path: 'fetchTable',
      name: 'FetchTableDemo',
      component: '/demo/table/FetchTable',
      meta: {
        title: 'routes.demo.table.fetchTable',
      },
    },
    {
      path: 'fixedColumn',
      name: 'FixedColumnDemo',
      component: '/demo/table/FixedColumn',
      meta: {
        title: 'routes.demo.table.fixedColumn',
      },
    },
    {
      path: 'customerCell',
      name: 'CustomerCellDemo',
      component: '/demo/table/CustomerCell',
      meta: {
        title: 'routes.demo.table.customerCell',
      },
    },
    {
      path: 'formTable',
      name: 'FormTableDemo',
      component: '/demo/table/FormTable',
      meta: {
        title: 'routes.demo.table.formTable',
      },
    },
    {
      path: 'useTable',
      name: 'UseTableDemo',
      component: '/demo/table/UseTable',
      meta: {
        title: 'routes.demo.table.useTable',
      },
    },
    {
      path: 'refTable',
      name: 'RefTableDemo',
      component: '/demo/table/RefTable',
      meta: {
        title: 'routes.demo.table.refTable',
      },
    },
    {
      path: 'multipleHeader',
      name: 'MultipleHeaderDemo',
      component: '/demo/table/MultipleHeader',
      meta: {
        title: 'routes.demo.table.multipleHeader',
      },
    },
    {
      path: 'mergeHeader',
      name: 'MergeHeaderDemo',
      component: '/demo/table/MergeHeader',
      meta: {
        title: 'routes.demo.table.mergeHeader',
      },
    },
    {
      path: 'expandTable',
      name: 'ExpandTableDemo',
      component: '/demo/table/ExpandTable',
      meta: {
        title: 'routes.demo.table.expandTable',
      },
    },
    {
      path: 'fixedHeight',
      name: 'FixedHeightDemo',
      component: '/demo/table/FixedHeight',
      meta: {
        title: 'routes.demo.table.fixedHeight',
      },
    },
    {
      path: 'footerTable',
      name: 'FooterTableDemo',
      component: '/demo/table/FooterTable',
      meta: {
        title: 'routes.demo.table.footerTable',
      },
    },
    {
      path: 'editCellTable',
      name: 'EditCellTableDemo',
      component: '/demo/table/EditCellTable',
      meta: {
        title: 'routes.demo.table.editCellTable',
      },
    },
    {
      path: 'editRowTable',
      name: 'EditRowTableDemo',
      component: '/demo/table/EditRowTable',
      meta: {
        title: 'routes.demo.table.editRowTable',
      },
    },
    {
      path: 'authColumn',
      name: 'AuthColumnDemo',
      component: '/demo/table/AuthColumn',
      meta: {
        title: 'routes.demo.table.authColumn',
      },
    },
    {
      path: 'resizeParentHeightTable',
      name: 'ResizeParentHeightTable',
      component: '/demo/table/ResizeParentHeightTable',
      meta: {
        title: 'routes.demo.table.resizeParentHeightTable',
      },
    },
  ],
}

export default [
  {
    // url: '/api/getMenuList',
    url: '/api/rbac-user-server/permission/myListTree/',
    timeout: 1000,
    method: 'get',
    response: (request: requestParams) => {
      const token = getRequestToken(request)
      if (!token) {
        return resultError('Invalid token!')
      }
      const checkUser = createFakeUserList().find((item) => item.access_token === token)
      if (!checkUser) {
        return resultError('Invalid user token!')
      }
      const id = checkUser.userId || '1'
      let menu: Object[]
      switch (id) {
        case '1':
          dashboardRoute.redirect = dashboardRoute.path + '/' + dashboardRoute.children[0].path
          menu = [
            dashboardRoute,
            authRoute,
            levelRoute,
            projectRoute,
            sysRoute,
            linkRoute,
            tableRoute,
          ]
          break
        case '2':
          dashboardRoute.redirect = dashboardRoute.path + '/' + dashboardRoute.children[1].path
          menu = [dashboardRoute, authRoute, levelRoute, linkRoute, tableRoute]
          break
        default:
          menu = []
      }
      console.log('menu', menu)
      return resultSuccess(menu)
    },
  },
] as MockMethod[]
