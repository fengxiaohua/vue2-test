# Test Server

It is used to start the test interface service, which can test the upload, websocket, login and other interfaces.

## Usage

```bash

cd ./test/server

pnpm install

pnpm run start

```
